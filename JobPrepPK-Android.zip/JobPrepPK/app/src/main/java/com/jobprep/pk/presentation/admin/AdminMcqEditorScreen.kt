package com.jobprep.pk.presentation.admin

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.jobprep.pk.domain.model.OptionKey
import com.jobprep.pk.domain.model.QuestionDifficulty
import com.jobprep.pk.presentation.components.AppTextField
import com.jobprep.pk.presentation.components.AppTopBar
import com.jobprep.pk.presentation.components.PrimaryButton
import com.jobprep.pk.presentation.theme.Spacing

@Composable
fun AdminMcqEditorScreen(
    onBack: () -> Unit,
    onSaved: () -> Unit,
    viewModel: AdminMcqEditorViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsState()

    LaunchedEffect(state.isSaved) { if (state.isSaved) onSaved() }

    Scaffold(topBar = { AppTopBar(title = if (state.isNew) "Add Question" else "Edit Question", onBack = onBack) }) { padding ->
        if (state.isLoading) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            return@Scaffold
        }

        Column(
            modifier = Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(Spacing.lg)
        ) {
            AppTextField(
                value = state.questionText, onValueChange = { v -> viewModel.update { it.copy(questionText = v) } },
                label = "Question", minLines = 2, singleLine = false
            )
            Spacer(Modifier.height(Spacing.lg))
            Text("Options", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(Spacing.sm))

            OptionEditRow("A", state.optionA, { v -> viewModel.update { it.copy(optionA = v) } }, state.correctOption == OptionKey.A) {
                viewModel.update { it.copy(correctOption = OptionKey.A) }
            }
            OptionEditRow("B", state.optionB, { v -> viewModel.update { it.copy(optionB = v) } }, state.correctOption == OptionKey.B) {
                viewModel.update { it.copy(correctOption = OptionKey.B) }
            }
            OptionEditRow("C", state.optionC, { v -> viewModel.update { it.copy(optionC = v) } }, state.correctOption == OptionKey.C) {
                viewModel.update { it.copy(correctOption = OptionKey.C) }
            }
            OptionEditRow("D", state.optionD, { v -> viewModel.update { it.copy(optionD = v) } }, state.correctOption == OptionKey.D) {
                viewModel.update { it.copy(correctOption = OptionKey.D) }
            }
            Text(
                "Tap the radio button next to the correct answer",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(Modifier.height(Spacing.lg))
            AppTextField(
                value = state.explanation, onValueChange = { v -> viewModel.update { it.copy(explanation = v) } },
                label = "Explanation", minLines = 2, singleLine = false
            )

            Spacer(Modifier.height(Spacing.lg))
            Text("Difficulty", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(Spacing.xs))
            Row(horizontalArrangement = Arrangement.spacedBy(Spacing.sm)) {
                QuestionDifficulty.entries.forEach { level ->
                    FilterChip(
                        selected = state.difficulty == level,
                        onClick = { viewModel.update { it.copy(difficulty = level) } },
                        label = { Text(level.name.lowercase().replaceFirstChar { c -> c.uppercase() }) }
                    )
                }
            }

            if (state.errors.isNotEmpty()) {
                Spacer(Modifier.height(Spacing.md))
                Surface(color = MaterialTheme.colorScheme.errorContainer, shape = MaterialTheme.shapes.small) {
                    Column(modifier = Modifier.padding(Spacing.md)) {
                        state.errors.forEach { error ->
                            Text("• $error", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onErrorContainer)
                        }
                    }
                }
            }

            Spacer(Modifier.height(Spacing.xl))
            PrimaryButton(text = "Save Question", onClick = viewModel::save, loading = state.isSaving, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(Spacing.xxl))
        }
    }
}

@Composable
private fun OptionEditRow(label: String, value: String, onValueChange: (String) -> Unit, isCorrect: Boolean, onMarkCorrect: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 4.dp)) {
        RadioButton(selected = isCorrect, onClick = onMarkCorrect)
        AppTextField(value = value, onValueChange = onValueChange, label = "Option $label", modifier = Modifier.weight(1f))
    }
}
