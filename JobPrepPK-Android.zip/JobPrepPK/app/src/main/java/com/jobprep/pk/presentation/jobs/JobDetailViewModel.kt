package com.jobprep.pk.presentation.jobs

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jobprep.pk.domain.model.Job
import com.jobprep.pk.domain.repository.JobRepository
import com.jobprep.pk.presentation.common.UiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class JobDetailViewModel @Inject constructor(
    private val jobRepository: JobRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val jobId: String = checkNotNull(savedStateHandle["jobId"])

    private val _uiState = MutableStateFlow<UiState<Job>>(UiState.Loading)
    val uiState: StateFlow<UiState<Job>> = _uiState

    init { load() }

    fun load() {
        viewModelScope.launch {
            _uiState.value = UiState.Loading
            runCatching { jobRepository.getJobById(jobId) }
                .onSuccess { job ->
                    _uiState.value = if (job == null) UiState.Error("This job listing is no longer available.")
                                      else UiState.Success(job)
                }
                .onFailure { _uiState.value = UiState.Error(it.message ?: "Failed to load job details") }
        }
    }
}
