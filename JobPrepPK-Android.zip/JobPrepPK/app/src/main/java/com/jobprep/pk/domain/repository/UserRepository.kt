package com.jobprep.pk.domain.repository

import com.jobprep.pk.domain.model.User
import com.jobprep.pk.domain.model.UserProgress
import kotlinx.coroutines.flow.Flow

sealed class AuthResult {
    data class Success(val user: User) : AuthResult()
    data class Error(val message: String) : AuthResult()
}

interface UserRepository {
    val currentUser: Flow<User?>
    suspend fun register(name: String, email: String, password: String): AuthResult
    suspend fun login(email: String, password: String): AuthResult
    suspend fun logout()
    suspend fun updateProfile(name: String, email: String): AuthResult
    suspend fun getProgress(userId: String): UserProgress
}
