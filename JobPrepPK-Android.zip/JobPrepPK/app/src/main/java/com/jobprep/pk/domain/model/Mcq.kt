package com.jobprep.pk.domain.model

data class McqOption(val key: OptionKey, val text: String)

data class Mcq(
    val id: String,
    val subjectId: String,
    val subjectName: String,
    val jobCategory: OrgType?,
    val questionText: String,
    val options: List<McqOption>,
    val correctOption: OptionKey,
    val explanation: String,
    val difficulty: QuestionDifficulty,
    val isBookmarked: Boolean = false
)
