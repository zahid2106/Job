package com.jobprep.pk.data.repository

import com.jobprep.pk.data.local.entity.*
import com.jobprep.pk.domain.model.*

fun JobEntity.toDomain(): Job = Job(
    id = id,
    organization = runCatching { OrgType.valueOf(organization) }.getOrDefault(OrgType.OTHER),
    title = title,
    bpsOrGrade = bpsOrGrade,
    qualification = qualification,
    ageLimitMin = ageLimitMin,
    ageLimitMax = ageLimitMax,
    vacancies = vacancies,
    experienceRequired = experienceRequired,
    province = province,
    postedDate = postedDate,
    deadline = deadline,
    advertisementNumber = advertisementNumber,
    details = details,
    applyLink = applyLink,
    isFeatured = isFeatured,
    isActive = isActive
)

fun Job.toEntity(): JobEntity = JobEntity(
    id = id, organization = organization.name, title = title, bpsOrGrade = bpsOrGrade,
    qualification = qualification, ageLimitMin = ageLimitMin, ageLimitMax = ageLimitMax,
    vacancies = vacancies, experienceRequired = experienceRequired, province = province,
    postedDate = postedDate, deadline = deadline, advertisementNumber = advertisementNumber,
    details = details, applyLink = applyLink, isFeatured = isFeatured, isActive = isActive
)

fun SubjectEntity.toDomain(questionCount: Int): Subject = Subject(
    id = id, name = name, iconKey = iconKey, colorHex = colorHex,
    questionCount = questionCount,
    jobCategory = jobCategory?.let { runCatching { OrgType.valueOf(it) }.getOrNull() }
)

fun Subject.toEntity(): SubjectEntity = SubjectEntity(
    id = id, name = name, iconKey = iconKey, colorHex = colorHex, jobCategory = jobCategory?.name
)

fun McqEntity.toDomain(subjectName: String, isBookmarked: Boolean = false): Mcq = Mcq(
    id = id,
    subjectId = subjectId,
    subjectName = subjectName,
    jobCategory = jobCategory?.let { runCatching { OrgType.valueOf(it) }.getOrNull() },
    questionText = questionText,
    options = listOf(
        McqOption(OptionKey.A, optionA),
        McqOption(OptionKey.B, optionB),
        McqOption(OptionKey.C, optionC),
        McqOption(OptionKey.D, optionD)
    ),
    correctOption = runCatching { OptionKey.valueOf(correctOption) }.getOrDefault(OptionKey.A),
    explanation = explanation,
    difficulty = runCatching { QuestionDifficulty.valueOf(difficulty) }.getOrDefault(QuestionDifficulty.MEDIUM),
    isBookmarked = isBookmarked
)

fun Mcq.toEntity(): McqEntity {
    val opt = options.associateBy { it.key }
    return McqEntity(
        id = id, subjectId = subjectId, jobCategory = jobCategory?.name, questionText = questionText,
        optionA = opt[OptionKey.A]?.text.orEmpty(), optionB = opt[OptionKey.B]?.text.orEmpty(),
        optionC = opt[OptionKey.C]?.text.orEmpty(), optionD = opt[OptionKey.D]?.text.orEmpty(),
        correctOption = correctOption.name, explanation = explanation, difficulty = difficulty.name
    )
}

fun TestBlueprintEntity.toDomain(): TestBlueprint = TestBlueprint(
    id = id, title = title, description = description,
    subjectIds = subjectIds.split(",").filter { it.isNotBlank() },
    jobCategory = jobCategory?.let { runCatching { OrgType.valueOf(it) }.getOrNull() },
    questionCount = questionCount, durationMinutes = durationMinutes,
    attemptsCount = attemptsCount, isPopular = isPopular
)

fun TestBlueprint.toEntity(): TestBlueprintEntity = TestBlueprintEntity(
    id = id, title = title, description = description, subjectIds = subjectIds.joinToString(","),
    jobCategory = jobCategory?.name, questionCount = questionCount, durationMinutes = durationMinutes,
    attemptsCount = attemptsCount, isPopular = isPopular
)

fun TestAttemptEntity.toSummary(): TestAttemptSummary = TestAttemptSummary(
    id = id, title = title, mode = runCatching { TestMode.valueOf(mode) }.getOrDefault(TestMode.PRACTICE),
    submittedAt = submittedAt, totalQuestions = totalQuestions, correctCount = correctCount,
    wrongCount = wrongCount, skippedCount = skippedCount, durationSeconds = durationSeconds,
    score = score, percentage = percentage
)

fun UserEntity.toDomain(): User = User(id = id, name = name, email = email, isAdmin = isAdmin, createdAt = createdAt)

fun NotificationEntity.toDomain(): AppNotification = AppNotification(
    id = id, title = title, body = body,
    type = runCatching { NotificationType.valueOf(type) }.getOrDefault(NotificationType.ANNOUNCEMENT),
    relatedId = relatedId, createdAt = createdAt, isRead = isRead
)

fun AppNotification.toEntity(): NotificationEntity = NotificationEntity(
    id = id, title = title, body = body, type = type.name, relatedId = relatedId,
    createdAt = createdAt, isRead = isRead
)
