package com.jobprep.pk.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "mcqs")
data class McqEntity(
    @PrimaryKey val id: String,
    val subjectId: String,
    val jobCategory: String?,
    val questionText: String,
    val optionA: String,
    val optionB: String,
    val optionC: String,
    val optionD: String,
    val correctOption: String, // A/B/C/D
    val explanation: String,
    val difficulty: String,
    val reportCount: Int = 0
)
