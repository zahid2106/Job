package com.jobprep.pk.data.repository

import com.jobprep.pk.data.local.dao.BookmarkDao
import com.jobprep.pk.data.local.dao.McqDao
import com.jobprep.pk.data.local.dao.ReportDao
import com.jobprep.pk.data.local.dao.SubjectDao
import com.jobprep.pk.data.local.entity.BookmarkEntity
import com.jobprep.pk.data.local.entity.ReportEntity
import com.jobprep.pk.domain.model.Mcq
import com.jobprep.pk.domain.model.OrgType
import com.jobprep.pk.domain.model.Subject
import com.jobprep.pk.domain.repository.McqRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class McqRepositoryImpl @Inject constructor(
    private val mcqDao: McqDao,
    private val subjectDao: SubjectDao,
    private val bookmarkDao: BookmarkDao,
    private val reportDao: ReportDao
) : McqRepository {

    override fun observeSubjects(): Flow<List<Subject>> =
        subjectDao.observeAll().map { subjects ->
            subjects.map { subject -> subject.toDomain(mcqDao.countForSubject(subject.id)) }
        }

    override suspend fun getSubjectById(id: String): Subject? {
        val entity = subjectDao.getById(id) ?: return null
        return entity.toDomain(mcqDao.countForSubject(id))
    }

    override suspend fun getRandomQuestions(subjectIds: List<String>, jobCategory: OrgType?, count: Int): List<Mcq> {
        val ids = subjectIds.ifEmpty {
            subjectDao.observeAll().first().map { it.id }
        }
        val subjectNames = subjectDao.observeAll().first().associate { it.id to it.name }
        val entities = mcqDao.getRandom(ids, jobCategory?.name, count)
        return entities.map { it.toDomain(subjectNames[it.subjectId] ?: "General") }
    }

    override fun observeBookmarked(userId: String): Flow<List<Mcq>> {
        val subjectNames = mutableMapOf<String, String>()
        return bookmarkDao.observeBookmarkedMcqs(userId).map { entities ->
            entities.map { entity ->
                val name = subjectNames.getOrPut(entity.subjectId) {
                    subjectDao.getById(entity.subjectId)?.name ?: "General"
                }
                entity.toDomain(name, isBookmarked = true)
            }
        }
    }

    override suspend fun toggleBookmark(userId: String, mcqId: String): Boolean {
        val isCurrentlyBookmarked = bookmarkDao.isBookmarked(userId, mcqId)
        return if (isCurrentlyBookmarked) {
            bookmarkDao.delete(userId, mcqId)
            false
        } else {
            bookmarkDao.insert(BookmarkEntity(userId, mcqId, System.currentTimeMillis()))
            true
        }
    }

    override suspend fun isBookmarked(userId: String, mcqId: String): Boolean =
        bookmarkDao.isBookmarked(userId, mcqId)

    override suspend fun reportQuestion(mcqId: String, userId: String, reason: String) {
        reportDao.insert(
            ReportEntity(
                id = UUID.randomUUID().toString(),
                mcqId = mcqId,
                userId = userId,
                reason = reason,
                status = "PENDING",
                createdAt = System.currentTimeMillis()
            )
        )
        mcqDao.incrementReportCount(mcqId)
    }

    override suspend fun refreshFromRemote(): Result<Unit> = Result.success(Unit)

    override suspend fun upsertSubject(subject: Subject) = subjectDao.upsert(subject.toEntity())

    override suspend fun deleteSubject(id: String) = subjectDao.delete(id)

    override suspend fun upsertMcq(mcq: Mcq) = mcqDao.upsert(mcq.toEntity())

    override suspend fun deleteMcq(id: String) = mcqDao.delete(id)

    override suspend fun bulkImportMcqs(mcqs: List<Mcq>): Int {
        mcqDao.upsertAll(mcqs.map { it.toEntity() })
        return mcqs.size
    }

    override suspend fun getAllMcqsForSubject(subjectId: String): List<Mcq> {
        val subjectName = subjectDao.getById(subjectId)?.name ?: "General"
        return mcqDao.getAllForSubject(subjectId).map { it.toDomain(subjectName) }
    }

    override fun observeReportedQuestions(): Flow<List<Mcq>> {
        val subjectNames = mutableMapOf<String, String>()
        return mcqDao.observeReported().map { entities ->
            entities.map { entity ->
                val name = subjectNames.getOrPut(entity.subjectId) {
                    subjectDao.getById(entity.subjectId)?.name ?: "General"
                }
                entity.toDomain(name)
            }
        }
    }

    override suspend fun dismissReports(mcqId: String) {
        mcqDao.clearReportCount(mcqId)
    }
}
