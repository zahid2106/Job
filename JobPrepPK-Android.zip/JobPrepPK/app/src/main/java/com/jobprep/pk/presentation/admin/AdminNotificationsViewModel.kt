package com.jobprep.pk.presentation.admin

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jobprep.pk.domain.model.AppNotification
import com.jobprep.pk.domain.model.NotificationType
import com.jobprep.pk.domain.repository.NotificationRepository
import com.jobprep.pk.presentation.common.UiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID
import javax.inject.Inject

@HiltViewModel
class AdminNotificationsViewModel @Inject constructor(
    private val notificationRepository: NotificationRepository
) : ViewModel() {

    val uiState: StateFlow<UiState<List<AppNotification>>> = notificationRepository.observeAll()
        .map { list -> if (list.isEmpty()) UiState.Empty else UiState.Success(list) }
        .catch { emit(UiState.Error(it.message ?: "Failed to load notifications")) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UiState.Loading)

    fun sendNotification(title: String, body: String, type: NotificationType) {
        if (title.isBlank() || body.isBlank()) return
        viewModelScope.launch {
            notificationRepository.send(
                AppNotification(
                    id = UUID.randomUUID().toString(),
                    title = title.trim(),
                    body = body.trim(),
                    type = type,
                    relatedId = null,
                    createdAt = System.currentTimeMillis(),
                    isRead = false
                )
            )
        }
    }

    fun deleteNotification(id: String) {
        viewModelScope.launch { notificationRepository.delete(id) }
    }
}
