package com.jobprep.pk.data.remote.api

import com.jobprep.pk.data.remote.dto.ContentSyncResponseDto
import com.jobprep.pk.data.remote.dto.JobDto
import com.jobprep.pk.data.remote.dto.McqDto
import retrofit2.http.GET
import retrofit2.http.Query

/**
 * Remote content API contract. This is the seam that lets jobs, MCQs, tests and
 * notifications be updated on the backend and pulled into the app WITHOUT a new
 * APK/AAB release — [com.jobprep.pk.util.SyncWorker] polls this periodically and
 * the repositories upsert results into Room, which remains the single source of
 * truth for the UI (offline-first).
 *
 * Point [com.jobprep.pk.BuildConfig.CONTENT_API_BASE_URL] at a real deployment
 * (Node/Express, Firebase Functions, Supabase Edge Functions, etc.) implementing
 * these endpoints to go live; until then the app runs entirely on the bundled
 * sample dataset seeded by SeedDataProvider.
 */
interface ContentApiService {

    @GET("sync")
    suspend fun getFullSync(@Query("since") sinceTimestamp: Long = 0L): ContentSyncResponseDto

    @GET("jobs")
    suspend fun getJobs(@Query("since") sinceTimestamp: Long = 0L): List<JobDto>

    @GET("mcqs")
    suspend fun getMcqs(
        @Query("subjectId") subjectId: String? = null,
        @Query("since") sinceTimestamp: Long = 0L
    ): List<McqDto>
}
