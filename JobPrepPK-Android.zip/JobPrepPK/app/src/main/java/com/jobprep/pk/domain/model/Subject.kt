package com.jobprep.pk.domain.model

data class Subject(
    val id: String,
    val name: String,
    val iconKey: String,
    val colorHex: String,
    val questionCount: Int,
    val jobCategory: OrgType? = null
)
