package com.jobprep.pk.presentation.common

/** Generic screen-level state: every list/detail screen renders one of these four. */
sealed class UiState<out T> {
    data object Loading : UiState<Nothing>()
    data class Success<T>(val data: T) : UiState<T>()
    data class Error(val message: String) : UiState<Nothing>()
    data object Empty : UiState<Nothing>()
}

/** One-shot UI events (snackbars, navigation) that shouldn't survive recomposition/rotation replay. */
sealed class UiEvent {
    data class ShowMessage(val message: String) : UiEvent()
    data class Navigate(val route: String) : UiEvent()
    data object NavigateBack : UiEvent()
}
