package com.jobprep.pk.presentation.profile

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.hilt.navigation.compose.hiltViewModel
import com.jobprep.pk.presentation.components.AppTextField
import com.jobprep.pk.presentation.components.AppTopBar
import com.jobprep.pk.presentation.components.PrimaryButton
import com.jobprep.pk.presentation.theme.Spacing

@Composable
fun EditProfileScreen(
    onBack: () -> Unit,
    viewModel: EditProfileViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(state.isSaved) {
        if (state.isSaved) snackbarHostState.showSnackbar("Profile updated successfully")
    }

    Scaffold(
        topBar = { AppTopBar(title = "Edit Profile", onBack = onBack) },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(Spacing.lg)) {
            AppTextField(value = state.name, onValueChange = viewModel::onNameChange, label = "Full Name")
            Spacer(Modifier.height(Spacing.md))
            AppTextField(value = state.email, onValueChange = viewModel::onEmailChange, label = "Email", keyboardType = KeyboardType.Email)

            if (state.errorMessage != null) {
                Spacer(Modifier.height(Spacing.sm))
                androidx.compose.material3.Text(
                    state.errorMessage!!,
                    color = androidx.compose.material3.MaterialTheme.colorScheme.error,
                    style = androidx.compose.material3.MaterialTheme.typography.bodySmall
                )
            }

            Spacer(Modifier.height(Spacing.xl))
            PrimaryButton(text = "Save Changes", onClick = viewModel::save, loading = state.isSubmitting, modifier = Modifier.fillMaxWidth())
        }
    }
}
