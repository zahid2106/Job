package com.jobprep.pk.presentation.test

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.jobprep.pk.domain.model.OptionKey
import com.jobprep.pk.domain.model.QuestionNavStatus
import com.jobprep.pk.presentation.common.UiState
import com.jobprep.pk.presentation.components.*
import com.jobprep.pk.presentation.theme.Spacing
import com.jobprep.pk.util.toSecondsClock

@Composable
fun TestTakingScreen(
    onSubmitted: (attemptId: String) -> Unit,
    onExit: () -> Unit,
    viewModel: TestTakingViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()
    var showNavigator by remember { mutableStateOf(false) }
    var showExitConfirm by remember { mutableStateOf(false) }

    BackHandlerCompat { showExitConfirm = true }

    when (val s = state) {
        is UiState.Loading -> LoadingState()
        is UiState.Error -> ErrorState(message = s.message, onRetry = null)
        is UiState.Empty -> EmptyState(title = "No questions available", message = "Couldn't build this test — please choose different subjects.")
        is UiState.Success -> {
            val test = s.data

            LaunchedEffect(test.submittedAttemptId) {
                test.submittedAttemptId?.let { onSubmitted(it) }
            }

            Scaffold(
                topBar = {
                    TopAppBar(
                        title = {
                            Text(
                                test.remainingSeconds.toSecondsClock(),
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.SemiBold,
                                color = if (test.remainingSeconds < 60) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                            )
                        },
                        navigationIcon = {
                            IconButton(onClick = { showExitConfirm = true }) {
                                Icon(Icons.Filled.Close, contentDescription = "Exit test")
                            }
                        },
                        actions = {
                            IconButton(onClick = { showNavigator = true }) {
                                Icon(Icons.Filled.Menu, contentDescription = "Question navigator")
                            }
                        }
                    )
                }
            ) { padding ->
                test.currentAnswer?.let { answer ->
                    Column(modifier = Modifier.padding(padding).fillMaxSize()) {
                        LinearProgressIndicator(
                            progress = { (test.currentIndex + 1).toFloat() / test.answers.size },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = Spacing.lg, vertical = Spacing.sm),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                "Question ${test.currentIndex + 1} / ${test.answers.size}",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                "${test.answeredCount} answered",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Column(
                            modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = Spacing.lg).verticalScroll(rememberScrollState())
                        ) {
                            Text(answer.mcq.questionText, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Medium)
                            Spacer(Modifier.height(Spacing.lg))
                            answer.shuffledOptions.forEach { option ->
                                TestOptionRow(
                                    label = option.text,
                                    isSelected = answer.selectedOption == option.key,
                                    onClick = { viewModel.selectOption(option.key) }
                                )
                                Spacer(Modifier.height(Spacing.sm))
                            }
                            Spacer(Modifier.height(Spacing.xl))
                        }

                        Surface(shadowElevation = 4.dp) {
                            Column(modifier = Modifier.padding(Spacing.lg)) {
                                Row(horizontalArrangement = Arrangement.spacedBy(Spacing.sm)) {
                                    OutlinedButton(onClick = { viewModel.clearAnswer() }, modifier = Modifier.weight(1f)) {
                                        Text("Clear")
                                    }
                                    OutlinedButton(
                                        onClick = { viewModel.toggleMarkForReview() },
                                        modifier = Modifier.weight(1f),
                                        colors = ButtonDefaults.outlinedButtonColors(
                                            contentColor = if (answer.isMarkedForReview) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.primary
                                        )
                                    ) {
                                        Icon(Icons.Filled.Bookmark, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text(if (answer.isMarkedForReview) "Marked" else "Mark")
                                    }
                                }
                                Spacer(Modifier.height(Spacing.sm))
                                Row(horizontalArrangement = Arrangement.spacedBy(Spacing.sm)) {
                                    SecondaryButton(
                                        text = "Previous", onClick = viewModel::previousQuestion,
                                        enabled = test.currentIndex > 0, modifier = Modifier.weight(1f)
                                    )
                                    if (test.currentIndex + 1 == test.answers.size) {
                                        PrimaryButton(text = "Submit", onClick = viewModel::requestSubmit, modifier = Modifier.weight(1f))
                                    } else {
                                        PrimaryButton(text = "Next", onClick = viewModel::nextQuestion, modifier = Modifier.weight(1f))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (showNavigator) {
                QuestionNavigatorSheet(
                    total = test.answers.size,
                    statusFor = test::statusFor,
                    onSelect = { index -> viewModel.goToQuestion(index); showNavigator = false },
                    onSubmit = { showNavigator = false; viewModel.requestSubmit() },
                    onDismiss = { showNavigator = false }
                )
            }

            if (test.showSubmitConfirm) {
                ConfirmDialog(
                    title = "Submit test?",
                    message = "You've answered ${test.answeredCount} of ${test.answers.size} questions. " +
                        "Once submitted you cannot change your answers.",
                    confirmLabel = "Submit",
                    onConfirm = viewModel::confirmSubmit,
                    onDismiss = viewModel::dismissSubmitConfirm
                )
            }

            if (test.showTimeUpDialog) {
                AlertDialog(
                    onDismissRequest = {},
                    title = { Text("Time's up!") },
                    text = { Text("Your test is being submitted automatically.") },
                    confirmButton = {
                        TextButton(onClick = viewModel::confirmSubmit) { Text("OK") }
                    }
                )
            }

            if (showExitConfirm) {
                ConfirmDialog(
                    title = "Exit test?",
                    message = "Your progress will be lost if you exit now without submitting.",
                    confirmLabel = "Exit",
                    isDestructive = true,
                    onConfirm = { showExitConfirm = false; onExit() },
                    onDismiss = { showExitConfirm = false }
                )
            }
        }
    }
}

@Composable
private fun TestOptionRow(label: String, isSelected: Boolean, onClick: () -> Unit) {
    val borderColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
    val backgroundColor = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f) else Color.Transparent

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .border(1.dp, borderColor, RoundedCornerShape(10.dp))
            .background(backgroundColor)
            .clickable(onClick = onClick)
            .padding(Spacing.md),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = isSelected, onClick = onClick)
        Spacer(Modifier.width(Spacing.xs))
        Text(label, style = MaterialTheme.typography.bodyMedium)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun QuestionNavigatorSheet(
    total: Int,
    statusFor: (Int) -> QuestionNavStatus,
    onSelect: (Int) -> Unit,
    onSubmit: () -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(modifier = Modifier.padding(Spacing.lg)) {
            Text("Question Navigator", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(Spacing.md))
            LegendRow()
            Spacer(Modifier.height(Spacing.md))
            LazyVerticalGrid(
                columns = GridCells.Fixed(5),
                verticalArrangement = Arrangement.spacedBy(Spacing.sm),
                horizontalArrangement = Arrangement.spacedBy(Spacing.sm),
                modifier = Modifier.heightIn(max = 320.dp)
            ) {
                items(total) { index ->
                    NavigatorCell(index = index, status = statusFor(index), onClick = { onSelect(index) })
                }
            }
            Spacer(Modifier.height(Spacing.lg))
            PrimaryButton(text = "Submit Test", onClick = onSubmit, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(Spacing.md))
        }
    }
}

@Composable
private fun LegendRow() {
    Row(horizontalArrangement = Arrangement.spacedBy(Spacing.sm)) {
        LegendDot(MaterialTheme.colorScheme.primary, "Answered")
        LegendDot(MaterialTheme.colorScheme.tertiary, "Marked")
        LegendDot(MaterialTheme.colorScheme.outline, "Skipped")
    }
}

@Composable
private fun LegendDot(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(4.dp))
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun NavigatorCell(index: Int, status: QuestionNavStatus, onClick: () -> Unit) {
    val (bg, fg) = when (status) {
        QuestionNavStatus.ANSWERED -> MaterialTheme.colorScheme.primary to MaterialTheme.colorScheme.onPrimary
        QuestionNavStatus.ANSWERED_MARKED -> MaterialTheme.colorScheme.tertiary to MaterialTheme.colorScheme.onTertiary
        QuestionNavStatus.MARKED_FOR_REVIEW -> MaterialTheme.colorScheme.tertiaryContainer to MaterialTheme.colorScheme.onTertiaryContainer
        QuestionNavStatus.NOT_ANSWERED, QuestionNavStatus.NOT_VISITED ->
            MaterialTheme.colorScheme.surfaceVariant to MaterialTheme.colorScheme.onSurfaceVariant
    }
    Box(
        modifier = Modifier
            .size(44.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(bg)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text((index + 1).toString(), color = fg, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun BackHandlerCompat(onBack: () -> Unit) {
    androidx.activity.compose.BackHandler(onBack = onBack)
}
