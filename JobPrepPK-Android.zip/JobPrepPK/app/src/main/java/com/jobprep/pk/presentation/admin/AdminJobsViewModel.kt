package com.jobprep.pk.presentation.admin

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jobprep.pk.domain.model.Job
import com.jobprep.pk.domain.repository.JobFilter
import com.jobprep.pk.domain.repository.JobRepository
import com.jobprep.pk.presentation.common.UiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AdminJobsViewModel @Inject constructor(
    private val jobRepository: JobRepository
) : ViewModel() {

    val uiState: StateFlow<UiState<List<Job>>> = jobRepository.observeJobs(JobFilter(activeOnly = false))
        .map { jobs -> if (jobs.isEmpty()) UiState.Empty else UiState.Success(jobs) }
        .catch { emit(UiState.Error(it.message ?: "Failed to load jobs")) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UiState.Loading)

    fun deleteJob(id: String) {
        viewModelScope.launch { jobRepository.deleteJob(id) }
    }
}
