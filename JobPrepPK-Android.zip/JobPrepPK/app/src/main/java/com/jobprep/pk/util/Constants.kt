package com.jobprep.pk.util

object Constants {
    const val SEED_ADMIN_EMAIL = "admin@jobprep.pk"
    const val SEED_ADMIN_PASSWORD = "Admin@123"
    const val SEED_DEMO_EMAIL = "demo@jobprep.pk"
    const val SEED_DEMO_PASSWORD = "Demo@123"

    const val PRACTICE_SESSION_SIZE = 20
    const val MIN_MOCK_QUESTIONS = 10
    const val MAX_MOCK_QUESTIONS = 100
    const val DEFAULT_MOCK_DURATION_MIN = 30

    const val NOTIFICATION_CHANNEL_ID = "jobprep_general"
    const val NOTIFICATION_CHANNEL_NAME = "JobPrep Alerts"

    const val SYNC_WORK_NAME = "jobprep_content_sync"
}
