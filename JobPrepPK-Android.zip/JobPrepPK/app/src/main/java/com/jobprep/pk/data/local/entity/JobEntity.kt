package com.jobprep.pk.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "jobs")
data class JobEntity(
    @PrimaryKey val id: String,
    val organization: String,
    val title: String,
    val bpsOrGrade: String,
    val qualification: String,
    val ageLimitMin: Int,
    val ageLimitMax: Int,
    val vacancies: Int,
    val experienceRequired: String,
    val province: String,
    val postedDate: Long,
    val deadline: Long,
    val advertisementNumber: String,
    val details: String,
    val applyLink: String,
    val isFeatured: Boolean,
    val isActive: Boolean
)
