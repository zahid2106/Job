package com.jobprep.pk.presentation.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jobprep.pk.domain.repository.AuthResult
import com.jobprep.pk.domain.repository.UserRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

data class EditProfileState(
    val name: String = "",
    val email: String = "",
    val isSubmitting: Boolean = false,
    val errorMessage: String? = null,
    val isSaved: Boolean = false
)

@HiltViewModel
class EditProfileViewModel @Inject constructor(
    private val userRepository: UserRepository
) : ViewModel() {

    private val _state = MutableStateFlow(EditProfileState())
    val state: StateFlow<EditProfileState> = _state

    init {
        viewModelScope.launch {
            val user = userRepository.currentUser.first()
            if (user != null) {
                _state.value = _state.value.copy(name = user.name, email = user.email)
            }
        }
    }

    fun onNameChange(value: String) { _state.value = _state.value.copy(name = value, errorMessage = null, isSaved = false) }
    fun onEmailChange(value: String) { _state.value = _state.value.copy(email = value, errorMessage = null, isSaved = false) }

    fun save() {
        viewModelScope.launch {
            _state.value = _state.value.copy(isSubmitting = true, errorMessage = null)
            when (val result = userRepository.updateProfile(_state.value.name, _state.value.email)) {
                is AuthResult.Success -> _state.value = _state.value.copy(isSubmitting = false, isSaved = true)
                is AuthResult.Error -> _state.value = _state.value.copy(isSubmitting = false, errorMessage = result.message)
            }
        }
    }
}
