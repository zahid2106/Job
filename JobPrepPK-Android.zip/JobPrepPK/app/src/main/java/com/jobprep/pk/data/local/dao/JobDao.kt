package com.jobprep.pk.data.local.dao

import androidx.room.*
import com.jobprep.pk.data.local.entity.JobEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface JobDao {
    @Query("SELECT * FROM jobs WHERE isActive = 1 ORDER BY isFeatured DESC, postedDate DESC")
    fun observeAll(): Flow<List<JobEntity>>

    @Query("SELECT * FROM jobs WHERE isActive = 1 AND isFeatured = 1 ORDER BY postedDate DESC LIMIT 10")
    fun observeFeatured(): Flow<List<JobEntity>>

    @Query("SELECT * FROM jobs WHERE isActive = 1 AND deadline >= :now ORDER BY deadline ASC LIMIT :limit")
    fun observeUpcomingDeadlines(now: Long, limit: Int): Flow<List<JobEntity>>

    @Query("SELECT * FROM jobs WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): JobEntity?

    @Query("""
        SELECT * FROM jobs WHERE isActive = 1 AND
        (:query = '' OR title LIKE '%' || :query || '%' OR organization LIKE '%' || :query || '%')
        ORDER BY isFeatured DESC, postedDate DESC
    """)
    fun searchAll(query: String): Flow<List<JobEntity>>

    @Upsert
    suspend fun upsert(job: JobEntity)

    @Upsert
    suspend fun upsertAll(jobs: List<JobEntity>)

    @Query("DELETE FROM jobs WHERE id = :id")
    suspend fun delete(id: String)

    @Query("SELECT COUNT(*) FROM jobs")
    suspend fun count(): Int
}
