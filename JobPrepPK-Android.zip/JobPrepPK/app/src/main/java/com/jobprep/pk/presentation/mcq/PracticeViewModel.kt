package com.jobprep.pk.presentation.mcq

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jobprep.pk.domain.model.Mcq
import com.jobprep.pk.domain.model.OptionKey
import com.jobprep.pk.domain.repository.McqRepository
import com.jobprep.pk.domain.repository.UserRepository
import com.jobprep.pk.presentation.common.UiState
import com.jobprep.pk.util.Constants
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

data class PracticeSessionState(
    val questions: List<Mcq> = emptyList(),
    val currentIndex: Int = 0,
    val selectedOption: OptionKey? = null,
    val isChecked: Boolean = false,
    val bookmarkedIds: Set<String> = emptySet(),
    val correctCount: Int = 0,
    val attemptedCount: Int = 0,
    val isSessionComplete: Boolean = false,
    val reportSubmittedFor: String? = null
) {
    val currentQuestion: Mcq? get() = questions.getOrNull(currentIndex)
    val progress: Float get() = if (questions.isEmpty()) 0f else (currentIndex.toFloat() / questions.size)
}

@HiltViewModel
class PracticeViewModel @Inject constructor(
    private val mcqRepository: McqRepository,
    private val userRepository: UserRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val subjectId: String = checkNotNull(savedStateHandle["subjectId"])

    private val _uiState = MutableStateFlow<UiState<PracticeSessionState>>(UiState.Loading)
    val uiState: StateFlow<UiState<PracticeSessionState>> = _uiState

    private var sessionState = PracticeSessionState()
    private var currentUserId: String? = null

    init { loadSession() }

    fun loadSession() {
        viewModelScope.launch {
            _uiState.value = UiState.Loading
            currentUserId = userRepository.currentUser.first()?.id
            val subjectIds = if (subjectId == "all") emptyList() else listOf(subjectId)
            runCatching {
                mcqRepository.getRandomQuestions(subjectIds, null, Constants.PRACTICE_SESSION_SIZE)
            }.onSuccess { questions ->
                if (questions.isEmpty()) {
                    _uiState.value = UiState.Empty
                } else {
                    sessionState = PracticeSessionState(questions = questions)
                    _uiState.value = UiState.Success(sessionState)
                }
            }.onFailure {
                _uiState.value = UiState.Error(it.message ?: "Failed to load practice questions")
            }
        }
    }

    fun selectOption(option: OptionKey) {
        if (sessionState.isChecked) return
        sessionState = sessionState.copy(selectedOption = option)
        _uiState.value = UiState.Success(sessionState)
    }

    fun checkAnswer() {
        val question = sessionState.currentQuestion ?: return
        if (sessionState.selectedOption == null || sessionState.isChecked) return
        val isCorrect = sessionState.selectedOption == question.correctOption
        sessionState = sessionState.copy(
            isChecked = true,
            correctCount = sessionState.correctCount + if (isCorrect) 1 else 0,
            attemptedCount = sessionState.attemptedCount + 1
        )
        _uiState.value = UiState.Success(sessionState)
    }

    fun nextQuestion() {
        val nextIndex = sessionState.currentIndex + 1
        sessionState = if (nextIndex >= sessionState.questions.size) {
            sessionState.copy(isSessionComplete = true)
        } else {
            sessionState.copy(currentIndex = nextIndex, selectedOption = null, isChecked = false, reportSubmittedFor = null)
        }
        _uiState.value = UiState.Success(sessionState)
    }

    fun toggleBookmark() {
        val question = sessionState.currentQuestion ?: return
        val userId = currentUserId ?: return
        viewModelScope.launch {
            val nowBookmarked = mcqRepository.toggleBookmark(userId, question.id)
            val updated = sessionState.bookmarkedIds.toMutableSet()
            if (nowBookmarked) updated.add(question.id) else updated.remove(question.id)
            sessionState = sessionState.copy(bookmarkedIds = updated)
            _uiState.value = UiState.Success(sessionState)
        }
    }

    fun reportQuestion(reason: String) {
        val question = sessionState.currentQuestion ?: return
        val userId = currentUserId ?: return
        viewModelScope.launch {
            mcqRepository.reportQuestion(question.id, userId, reason)
            sessionState = sessionState.copy(reportSubmittedFor = question.id)
            _uiState.value = UiState.Success(sessionState)
        }
    }

    fun restartSession() = loadSession()
}
