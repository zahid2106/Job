package com.jobprep.pk.presentation.admin

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jobprep.pk.domain.model.Job
import com.jobprep.pk.domain.model.OrgType
import com.jobprep.pk.domain.repository.JobRepository
import com.jobprep.pk.presentation.navigation.Screen
import com.jobprep.pk.util.Validators
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.UUID
import javax.inject.Inject

data class JobEditorFormState(
    val isNew: Boolean = true,
    val organization: OrgType = OrgType.FPSC,
    val title: String = "",
    val bpsOrGrade: String = "",
    val qualification: String = "",
    val ageLimitMin: String = "18",
    val ageLimitMax: String = "30",
    val vacancies: String = "",
    val experienceRequired: String = "Not required",
    val province: String = "All Pakistan",
    val deadlineText: String = "",
    val advertisementNumber: String = "",
    val details: String = "",
    val applyLink: String = "",
    val isFeatured: Boolean = false,
    val isLoading: Boolean = true,
    val isSaving: Boolean = false,
    val errors: List<String> = emptyList(),
    val isSaved: Boolean = false
)

private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)

@HiltViewModel
class AdminJobEditorViewModel @Inject constructor(
    private val jobRepository: JobRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val jobId: String = checkNotNull(savedStateHandle["jobId"])
    private val existingJobId: String? = jobId.takeIf { it != Screen.AdminJobEditor.NEW }

    private val _state = MutableStateFlow(JobEditorFormState(isNew = existingJobId == null))
    val state: StateFlow<JobEditorFormState> = _state

    init {
        viewModelScope.launch {
            if (existingJobId != null) {
                val job = jobRepository.getJobById(existingJobId)
                if (job != null) {
                    _state.value = _state.value.copy(
                        isNew = false,
                        organization = job.organization,
                        title = job.title,
                        bpsOrGrade = job.bpsOrGrade,
                        qualification = job.qualification,
                        ageLimitMin = job.ageLimitMin.toString(),
                        ageLimitMax = job.ageLimitMax.toString(),
                        vacancies = job.vacancies.toString(),
                        experienceRequired = job.experienceRequired,
                        province = job.province,
                        deadlineText = dateFormat.format(java.util.Date(job.deadline)),
                        advertisementNumber = job.advertisementNumber,
                        details = job.details,
                        applyLink = job.applyLink,
                        isFeatured = job.isFeatured,
                        isLoading = false
                    )
                } else {
                    _state.value = _state.value.copy(isLoading = false, errors = listOf("Job not found."))
                }
            } else {
                _state.value = _state.value.copy(isLoading = false)
            }
        }
    }

    fun update(transform: (JobEditorFormState) -> JobEditorFormState) {
        _state.value = transform(_state.value).copy(errors = emptyList(), isSaved = false)
    }

    fun save() {
        val form = _state.value
        val deadlineMillis = runCatching { dateFormat.parse(form.deadlineText)?.time }.getOrNull()

        val errors = Validators.validateJobForm(
            title = form.title, organization = form.organization.name, bps = form.bpsOrGrade,
            qualification = form.qualification, vacancies = form.vacancies, deadlineMillis = deadlineMillis
        ).toMutableList()

        if (deadlineMillis == null) errors.add("Deadline must be a valid date (YYYY-MM-DD).")
        if (form.applyLink.isNotBlank() && !form.applyLink.startsWith("http")) {
            errors.add("Apply link should start with http:// or https://")
        }

        if (errors.isNotEmpty()) {
            _state.value = form.copy(errors = errors)
            return
        }

        viewModelScope.launch {
            _state.value = form.copy(isSaving = true)
            val job = Job(
                id = existingJobId ?: UUID.randomUUID().toString(),
                organization = form.organization,
                title = form.title.trim(),
                bpsOrGrade = form.bpsOrGrade.trim(),
                qualification = form.qualification.trim(),
                ageLimitMin = form.ageLimitMin.toIntOrNull() ?: 18,
                ageLimitMax = form.ageLimitMax.toIntOrNull() ?: 30,
                vacancies = form.vacancies.toIntOrNull() ?: 1,
                experienceRequired = form.experienceRequired.trim().ifBlank { "Not required" },
                province = form.province.trim().ifBlank { "All Pakistan" },
                postedDate = System.currentTimeMillis(),
                deadline = deadlineMillis!!,
                advertisementNumber = form.advertisementNumber.trim(),
                details = form.details.trim(),
                applyLink = form.applyLink.trim(),
                isFeatured = form.isFeatured,
                isActive = true
            )
            jobRepository.upsertJob(job)
            _state.value = form.copy(isSaving = false, isSaved = true)
        }
    }
}
