package com.jobprep.pk.presentation.admin

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jobprep.pk.domain.model.Mcq
import com.jobprep.pk.domain.repository.McqRepository
import com.jobprep.pk.presentation.common.UiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AdminMcqListViewModel @Inject constructor(
    private val mcqRepository: McqRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    val subjectId: String = checkNotNull(savedStateHandle["subjectId"])

    private val _uiState = MutableStateFlow<UiState<List<Mcq>>>(UiState.Loading)
    val uiState: StateFlow<UiState<List<Mcq>>> = _uiState

    private val _subjectName = MutableStateFlow("Questions")
    val subjectName: StateFlow<String> = _subjectName

    init { load() }

    fun load() {
        viewModelScope.launch {
            _uiState.value = UiState.Loading
            _subjectName.value = mcqRepository.getSubjectById(subjectId)?.name ?: "Questions"
            val mcqs = mcqRepository.getAllMcqsForSubject(subjectId)
            _uiState.value = if (mcqs.isEmpty()) UiState.Empty else UiState.Success(mcqs)
        }
    }

    fun deleteMcq(id: String) {
        viewModelScope.launch {
            mcqRepository.deleteMcq(id)
            load()
        }
    }
}
