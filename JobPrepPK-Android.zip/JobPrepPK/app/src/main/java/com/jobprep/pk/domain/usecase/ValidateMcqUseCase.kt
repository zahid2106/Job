package com.jobprep.pk.domain.usecase

import com.jobprep.pk.domain.model.Mcq

data class ValidationResult(val isValid: Boolean, val errors: List<String>)

/** Shared validation for admin MCQ create/edit and bulk import, keeps the DB clean. */
class ValidateMcqUseCase {
    operator fun invoke(mcq: Mcq): ValidationResult {
        val errors = mutableListOf<String>()
        if (mcq.questionText.isBlank() || mcq.questionText.length < 8) {
            errors += "Question text must be at least 8 characters."
        }
        if (mcq.options.size != 4) {
            errors += "Exactly 4 options (A-D) are required."
        }
        if (mcq.options.any { it.text.isBlank() }) {
            errors += "No option may be empty."
        }
        val distinctOptionTexts = mcq.options.map { it.text.trim().lowercase() }.distinct()
        if (distinctOptionTexts.size != mcq.options.size) {
            errors += "Options must not be duplicated."
        }
        if (mcq.explanation.isBlank()) {
            errors += "An explanation is required so learners understand the correct answer."
        }
        if (mcq.subjectId.isBlank()) {
            errors += "A subject must be selected."
        }
        return ValidationResult(errors.isEmpty(), errors)
    }
}
