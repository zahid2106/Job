package com.jobprep.pk.domain.model

data class User(
    val id: String,
    val name: String,
    val email: String,
    val isAdmin: Boolean,
    val createdAt: Long
)

data class UserProgress(
    val testsAttempted: Int,
    val averageScore: Float,
    val highestScore: Float,
    val totalQuestionsAnswered: Int,
    val totalCorrect: Int,
    val subjectPerformance: List<SubjectPerformance>,
    val weakSubjects: List<SubjectPerformance>,
    val bookmarkedCount: Int
)
