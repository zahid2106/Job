package com.jobprep.pk.presentation.navigation

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.jobprep.pk.domain.model.NotificationType
import com.jobprep.pk.presentation.admin.*
import com.jobprep.pk.presentation.auth.AuthViewModel
import com.jobprep.pk.presentation.auth.LoginScreen
import com.jobprep.pk.presentation.auth.RegisterScreen
import com.jobprep.pk.presentation.auth.SplashScreen
import com.jobprep.pk.presentation.home.HomeScreen
import com.jobprep.pk.presentation.jobs.JobDetailScreen
import com.jobprep.pk.presentation.jobs.JobListScreen
import com.jobprep.pk.presentation.jobs.JobSearchScreen
import com.jobprep.pk.presentation.mcq.BookmarksScreen
import com.jobprep.pk.presentation.mcq.PracticeScreen
import com.jobprep.pk.presentation.mcq.SubjectListScreen
import com.jobprep.pk.presentation.notifications.NotificationsScreen
import com.jobprep.pk.presentation.profile.EditProfileScreen
import com.jobprep.pk.presentation.profile.ProfileScreen
import com.jobprep.pk.presentation.profile.SettingsScreen
import com.jobprep.pk.presentation.profile.TestHistoryScreen
import com.jobprep.pk.presentation.test.AnswerReviewScreen
import com.jobprep.pk.presentation.test.CustomTestSetupScreen
import com.jobprep.pk.presentation.test.ResultScreen
import com.jobprep.pk.presentation.test.TestSetupScreen
import com.jobprep.pk.presentation.test.TestTakingScreen
import com.jobprep.pk.presentation.test.TestsHomeScreen

@Composable
fun JobPrepNavHost() {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    Scaffold(
        bottomBar = {
            if (currentRoute in bottomBarRoutes) {
                JobPrepBottomBar(navController)
            }
        }
    ) { outerPadding ->
        val bottomPadding = if (currentRoute in bottomBarRoutes) outerPadding else PaddingValues()

        NavHost(
            navController = navController,
            startDestination = Screen.Splash.route,
            modifier = Modifier.padding(bottom = bottomPadding.calculateBottomPadding())
        ) {
            // ---------------- Auth ----------------
            composable(Screen.Splash.route) {
                SplashScreen(
                    onNavigateToHome = {
                        navController.navigate(Screen.Home.route) { popUpTo(Screen.Splash.route) { inclusive = true } }
                    },
                    onNavigateToLogin = {
                        navController.navigate(Screen.Login.route) { popUpTo(Screen.Splash.route) { inclusive = true } }
                    }
                )
            }
            composable(Screen.Login.route) {
                LoginScreen(
                    onLoginSuccess = {
                        navController.navigate(Screen.Home.route) { popUpTo(Screen.Login.route) { inclusive = true } }
                    },
                    onNavigateToRegister = { navController.navigate(Screen.Register.route) }
                )
            }
            composable(Screen.Register.route) {
                RegisterScreen(
                    onRegisterSuccess = {
                        navController.navigate(Screen.Home.route) { popUpTo(Screen.Splash.route) { inclusive = true } }
                    },
                    onBack = { navController.popBackStack() }
                )
            }

            // ---------------- Bottom tabs ----------------
            composable(Screen.Home.route) {
                HomeScreen(
                    onJobClick = { id -> navController.navigate(Screen.JobDetail.createRoute(id)) },
                    onSearchClick = { navController.navigate(Screen.JobSearch.route) },
                    onNotificationsClick = { navController.navigate(Screen.Notifications.route) },
                    onTestClick = { id -> navController.navigate(Screen.TestSetup.createRoute(id)) },
                    onSeeAllJobs = { navController.navigate(Screen.Jobs.route) },
                    onSeeAllTests = { navController.navigate(Screen.Tests.route) }
                )
            }
            composable(Screen.Jobs.route) {
                JobListScreen(onJobClick = { id -> navController.navigate(Screen.JobDetail.createRoute(id)) })
            }
            composable(Screen.McqBank.route) {
                SubjectListScreen(
                    onSubjectClick = { id -> navController.navigate(Screen.Practice.createRoute(id)) },
                    onBookmarksClick = { navController.navigate(Screen.Bookmarks.route) },
                    onRandomPracticeClick = { navController.navigate(Screen.Practice.createRoute("all")) }
                )
            }
            composable(Screen.Tests.route) {
                TestsHomeScreen(
                    onTestClick = { id -> navController.navigate(Screen.TestSetup.createRoute(id)) },
                    onCustomTestClick = { navController.navigate(Screen.CustomTestSetup.route) },
                    onHistoryClick = { navController.navigate(Screen.TestHistory.route) }
                )
            }
            composable(Screen.Profile.route) {
                val authViewModel: AuthViewModel = hiltViewModel()
                val currentUser by authViewModel.currentUser.collectAsState()
                ProfileScreen(
                    isAdmin = currentUser?.isAdmin == true,
                    onEditProfile = { navController.navigate(Screen.EditProfile.route) },
                    onHistory = { navController.navigate(Screen.TestHistory.route) },
                    onBookmarks = { navController.navigate(Screen.Bookmarks.route) },
                    onSettings = { navController.navigate(Screen.Settings.route) },
                    onAdmin = { navController.navigate(Screen.AdminDashboard.route) },
                    onLoggedOut = {
                        navController.navigate(Screen.Login.route) { popUpTo(0) { inclusive = true } }
                    }
                )
            }

            // ---------------- Jobs ----------------
            composable(
                Screen.JobDetail.route,
                arguments = listOf(navArgument("jobId") { type = NavType.StringType })
            ) {
                JobDetailScreen(onBack = { navController.popBackStack() })
            }
            composable(Screen.JobSearch.route) {
                JobSearchScreen(
                    onBack = { navController.popBackStack() },
                    onJobClick = { id -> navController.navigate(Screen.JobDetail.createRoute(id)) }
                )
            }

            // ---------------- MCQ ----------------
            composable(
                Screen.Practice.route,
                arguments = listOf(navArgument("subjectId") { type = NavType.StringType })
            ) {
                PracticeScreen(onBack = { navController.popBackStack() })
            }
            composable(Screen.Bookmarks.route) {
                BookmarksScreen(onBack = { navController.popBackStack() })
            }

            // ---------------- Tests ----------------
            composable(
                Screen.TestSetup.route,
                arguments = listOf(navArgument("blueprintId") { type = NavType.StringType })
            ) {
                TestSetupScreen(
                    onBack = { navController.popBackStack() },
                    onStartTest = { route -> navController.navigate(route) }
                )
            }
            composable(Screen.CustomTestSetup.route) {
                CustomTestSetupScreen(
                    onBack = { navController.popBackStack() },
                    onStartTest = { route -> navController.navigate(route) }
                )
            }
            composable(
                Screen.TestTaking.route,
                arguments = listOf(
                    navArgument("mode") { type = NavType.StringType },
                    navArgument("blueprintId") { type = NavType.StringType },
                    navArgument("subjectIds") { type = NavType.StringType },
                    navArgument("questionCount") { type = NavType.IntType },
                    navArgument("durationMinutes") { type = NavType.IntType },
                    navArgument("title") { type = NavType.StringType }
                )
            ) {
                TestTakingScreen(
                    onSubmitted = { attemptId ->
                        navController.navigate(Screen.TestResult.createRoute(attemptId)) {
                            popUpTo(Screen.Tests.route)
                        }
                    },
                    onExit = { navController.popBackStack() }
                )
            }
            composable(
                Screen.TestResult.route,
                arguments = listOf(navArgument("attemptId") { type = NavType.StringType })
            ) { entry ->
                val attemptId = entry.arguments?.getString("attemptId").orEmpty()
                ResultScreen(
                    onReviewAnswers = { navController.navigate(Screen.AnswerReview.createRoute(attemptId)) },
                    onDone = { navController.navigate(Screen.Home.route) { popUpTo(Screen.Tests.route) { inclusive = true } } }
                )
            }
            composable(
                Screen.AnswerReview.route,
                arguments = listOf(navArgument("attemptId") { type = NavType.StringType })
            ) {
                AnswerReviewScreen(onBack = { navController.popBackStack() })
            }

            // ---------------- Profile ----------------
            composable(Screen.EditProfile.route) {
                EditProfileScreen(onBack = { navController.popBackStack() })
            }
            composable(Screen.TestHistory.route) {
                TestHistoryScreen(
                    onBack = { navController.popBackStack() },
                    onAttemptClick = { id -> navController.navigate(Screen.TestResult.createRoute(id)) }
                )
            }
            composable(Screen.Settings.route) {
                SettingsScreen(onBack = { navController.popBackStack() })
            }

            // ---------------- Notifications ----------------
            composable(Screen.Notifications.route) {
                NotificationsScreen(
                    onBack = { navController.popBackStack() },
                    onNotificationClick = { notification ->
                        notification.relatedId?.let { relatedId ->
                            when (notification.type) {
                                NotificationType.NEW_JOB, NotificationType.DEADLINE ->
                                    navController.navigate(Screen.JobDetail.createRoute(relatedId))
                                NotificationType.NEW_TEST ->
                                    navController.navigate(Screen.TestSetup.createRoute(relatedId))
                                else -> Unit
                            }
                        }
                    }
                )
            }

            // ---------------- Admin ----------------
            composable(Screen.AdminDashboard.route) {
                AdminDashboardScreen(
                    onBack = { navController.popBackStack() },
                    onManageJobs = { navController.navigate(Screen.AdminJobs.route) },
                    onManageSubjects = { navController.navigate(Screen.AdminSubjects.route) },
                    onBulkImport = { navController.navigate(Screen.AdminBulkImport.route) },
                    onManageNotifications = { navController.navigate(Screen.AdminNotifications.route) },
                    onReportedQuestions = { navController.navigate(Screen.AdminReportedQuestions.route) }
                )
            }
            composable(Screen.AdminJobs.route) {
                AdminJobsScreen(
                    onBack = { navController.popBackStack() },
                    onAddJob = { navController.navigate(Screen.AdminJobEditor.createRoute(Screen.AdminJobEditor.NEW)) },
                    onEditJob = { id -> navController.navigate(Screen.AdminJobEditor.createRoute(id)) }
                )
            }
            composable(
                Screen.AdminJobEditor.route,
                arguments = listOf(navArgument("jobId") { type = NavType.StringType })
            ) {
                AdminJobEditorScreen(onBack = { navController.popBackStack() }, onSaved = { navController.popBackStack() })
            }
            composable(Screen.AdminSubjects.route) {
                AdminSubjectsScreen(
                    onBack = { navController.popBackStack() },
                    onSubjectClick = { id -> navController.navigate(Screen.AdminMcqList.createRoute(id)) }
                )
            }
            composable(
                Screen.AdminMcqList.route,
                arguments = listOf(navArgument("subjectId") { type = NavType.StringType })
            ) {
                AdminMcqListScreen(
                    onBack = { navController.popBackStack() },
                    onAddMcq = { subjectId -> navController.navigate(Screen.AdminMcqEditor.createRoute(subjectId, Screen.AdminMcqEditor.NEW)) },
                    onEditMcq = { subjectId, mcqId -> navController.navigate(Screen.AdminMcqEditor.createRoute(subjectId, mcqId)) }
                )
            }
            composable(
                Screen.AdminMcqEditor.route,
                arguments = listOf(
                    navArgument("subjectId") { type = NavType.StringType },
                    navArgument("mcqId") { type = NavType.StringType }
                )
            ) {
                AdminMcqEditorScreen(onBack = { navController.popBackStack() }, onSaved = { navController.popBackStack() })
            }
            composable(Screen.AdminBulkImport.route) {
                AdminBulkImportScreen(onBack = { navController.popBackStack() })
            }
            composable(Screen.AdminNotifications.route) {
                AdminNotificationsScreen(onBack = { navController.popBackStack() })
            }
            composable(Screen.AdminReportedQuestions.route) {
                AdminReportedQuestionsScreen(
                    onBack = { navController.popBackStack() },
                    onEditQuestion = { subjectId, mcqId -> navController.navigate(Screen.AdminMcqEditor.createRoute(subjectId, mcqId)) }
                )
            }
        }
    }
}
