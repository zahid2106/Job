package com.jobprep.pk.presentation.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector

/** Maps the icon keys stored with each Subject to a concrete Material icon. */
fun subjectIconFor(key: String): ImageVector = when (key) {
    "public" -> Icons.Filled.Public
    "flag" -> Icons.Filled.Flag
    "newspaper" -> Icons.Filled.Newspaper
    "mosque" -> Icons.Filled.Mosque
    "language" -> Icons.Filled.Translate
    "translate" -> Icons.Filled.GTranslate
    "calculate" -> Icons.Filled.Calculate
    "computer" -> Icons.Filled.Computer
    "science" -> Icons.Filled.Science
    "local_police" -> Icons.Filled.LocalPolice
    "account_balance" -> Icons.Filled.AccountBalance
    "school" -> Icons.Filled.School
    else -> Icons.Filled.MenuBook
}

fun orgIconFor(org: com.jobprep.pk.domain.model.OrgType): ImageVector = when (org) {
    com.jobprep.pk.domain.model.OrgType.POLICE -> Icons.Filled.LocalPolice
    com.jobprep.pk.domain.model.OrgType.ARMY -> Icons.Filled.Shield
    com.jobprep.pk.domain.model.OrgType.NAVY -> Icons.Filled.Anchor
    com.jobprep.pk.domain.model.OrgType.AIR_FORCE -> Icons.Filled.FlightTakeoff
    com.jobprep.pk.domain.model.OrgType.BANK -> Icons.Filled.AccountBalance
    com.jobprep.pk.domain.model.OrgType.TEACHING -> Icons.Filled.School
    else -> Icons.Filled.Business
}
