package com.jobprep.pk.data.local.dao

import androidx.room.*
import com.jobprep.pk.data.local.entity.SubjectEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface SubjectDao {
    @Query("SELECT * FROM subjects ORDER BY name ASC")
    fun observeAll(): Flow<List<SubjectEntity>>

    @Query("SELECT * FROM subjects WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): SubjectEntity?

    @Upsert
    suspend fun upsert(subject: SubjectEntity)

    @Query("DELETE FROM subjects WHERE id = :id")
    suspend fun delete(id: String)

    @Query("SELECT COUNT(*) FROM subjects")
    suspend fun count(): Int
}
