package com.jobprep.pk.presentation.navigation

/**
 * Single source of truth for every route in the app. Using a sealed class instead
 * of raw strings scattered across screens keeps navigation type-safe and makes it
 * obvious which screens exist and what arguments they require.
 */
sealed class Screen(val route: String) {

    // Auth
    data object Splash : Screen("splash")
    data object Login : Screen("login")
    data object Register : Screen("register")

    // Bottom navigation destinations
    data object Home : Screen("home")
    data object Jobs : Screen("jobs")
    data object McqBank : Screen("mcq_bank")
    data object Tests : Screen("tests")
    data object Profile : Screen("profile")

    // Jobs
    data object JobDetail : Screen("job_detail/{jobId}") {
        fun createRoute(jobId: String) = "job_detail/$jobId"
    }
    data object JobSearch : Screen("job_search")

    // MCQ / Practice
    data object Practice : Screen("practice/{subjectId}") {
        fun createRoute(subjectId: String) = "practice/$subjectId"
    }
    data object Bookmarks : Screen("bookmarks")

    // Tests
    data object TestSetup : Screen("test_setup/{blueprintId}") {
        fun createRoute(blueprintId: String) = "test_setup/$blueprintId"
    }
    data object CustomTestSetup : Screen("custom_test_setup")
    data object TestTaking : Screen(
        "test_taking/{mode}/{blueprintId}/{subjectIds}/{questionCount}/{durationMinutes}/{title}"
    ) {
        fun createRoute(
            mode: String,
            blueprintId: String,
            subjectIds: String,
            questionCount: Int,
            durationMinutes: Int,
            title: String
        ): String {
            val encodedTitle = java.net.URLEncoder.encode(title, "UTF-8")
            return "test_taking/$mode/$blueprintId/$subjectIds/$questionCount/$durationMinutes/$encodedTitle"
        }
    }
    data object TestResult : Screen("test_result/{attemptId}") {
        fun createRoute(attemptId: String) = "test_result/$attemptId"
    }
    data object AnswerReview : Screen("answer_review/{attemptId}") {
        fun createRoute(attemptId: String) = "answer_review/$attemptId"
    }

    // Profile
    data object EditProfile : Screen("edit_profile")
    data object TestHistory : Screen("test_history")
    data object Settings : Screen("settings")

    // Notifications
    data object Notifications : Screen("notifications")

    // Admin
    data object AdminDashboard : Screen("admin_dashboard")
    data object AdminJobs : Screen("admin_jobs")
    data object AdminJobEditor : Screen("admin_job_editor/{jobId}") {
        fun createRoute(jobId: String) = "admin_job_editor/$jobId"
        const val NEW = "new"
    }
    data object AdminSubjects : Screen("admin_subjects")
    data object AdminMcqList : Screen("admin_mcq_list/{subjectId}") {
        fun createRoute(subjectId: String) = "admin_mcq_list/$subjectId"
    }
    data object AdminMcqEditor : Screen("admin_mcq_editor/{subjectId}/{mcqId}") {
        fun createRoute(subjectId: String, mcqId: String) = "admin_mcq_editor/$subjectId/$mcqId"
        const val NEW = "new"
    }
    data object AdminBulkImport : Screen("admin_bulk_import")
    data object AdminNotifications : Screen("admin_notifications")
    data object AdminReportedQuestions : Screen("admin_reported_questions")
}
