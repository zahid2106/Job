package com.jobprep.pk.presentation.test

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.hilt.navigation.compose.hiltViewModel
import com.jobprep.pk.presentation.common.UiState
import com.jobprep.pk.presentation.components.*
import com.jobprep.pk.presentation.theme.Spacing

@Composable
fun TestsHomeScreen(
    onTestClick: (String) -> Unit,
    onCustomTestClick: () -> Unit,
    onHistoryClick: () -> Unit,
    viewModel: TestsViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            AppTopBar(title = "Mock Tests") {
                IconButton(onClick = onHistoryClick) {
                    Icon(Icons.Filled.History, contentDescription = "Test history")
                }
            }
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            OutlinedCard(
                onClick = onCustomTestClick,
                modifier = Modifier.fillMaxWidth().padding(Spacing.lg)
            ) {
                Row(modifier = Modifier.padding(Spacing.md), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Tune, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(Spacing.md))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Build a Custom Test", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                        Text(
                            "Choose subjects, question count and duration",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            SectionHeader("All Tests", modifier = Modifier.padding(horizontal = Spacing.lg, vertical = Spacing.sm))

            when (val s = state) {
                is UiState.Loading -> LoadingState()
                is UiState.Error -> ErrorState(message = s.message)
                is UiState.Empty -> EmptyState(title = "No tests available", message = "Please check back later.")
                is UiState.Success -> LazyColumn(
                    contentPadding = PaddingValues(horizontal = Spacing.lg, vertical = Spacing.sm),
                    verticalArrangement = Arrangement.spacedBy(Spacing.md)
                ) {
                    items(s.data, key = { it.id }) { blueprint ->
                        TestBlueprintCard(blueprint = blueprint, onClick = { onTestClick(blueprint.id) })
                    }
                    item { Spacer(Modifier.height(Spacing.xxl)) }
                }
            }
        }
    }
}
