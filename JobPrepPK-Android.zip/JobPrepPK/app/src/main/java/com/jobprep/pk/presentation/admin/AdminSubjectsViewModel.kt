package com.jobprep.pk.presentation.admin

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jobprep.pk.domain.model.OrgType
import com.jobprep.pk.domain.model.Subject
import com.jobprep.pk.domain.repository.McqRepository
import com.jobprep.pk.presentation.common.UiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID
import javax.inject.Inject

@HiltViewModel
class AdminSubjectsViewModel @Inject constructor(
    private val mcqRepository: McqRepository
) : ViewModel() {

    val uiState: StateFlow<UiState<List<Subject>>> = mcqRepository.observeSubjects()
        .map { list -> if (list.isEmpty()) UiState.Empty else UiState.Success(list) }
        .catch { emit(UiState.Error(it.message ?: "Failed to load subjects")) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UiState.Loading)

    fun addSubject(name: String, jobCategory: OrgType?) {
        if (name.isBlank()) return
        viewModelScope.launch {
            mcqRepository.upsertSubject(
                Subject(
                    id = "subj_${UUID.randomUUID().toString().take(8)}",
                    name = name.trim(),
                    iconKey = "menu_book",
                    colorHex = "#0E4D3C",
                    questionCount = 0,
                    jobCategory = jobCategory
                )
            )
        }
    }

    fun renameSubject(subject: Subject, newName: String) {
        if (newName.isBlank()) return
        viewModelScope.launch { mcqRepository.upsertSubject(subject.copy(name = newName.trim())) }
    }

    fun deleteSubject(id: String) {
        viewModelScope.launch { mcqRepository.deleteSubject(id) }
    }
}
