package com.jobprep.pk.domain.model

/** Pakistani recruiting/testing organizations supported by the app. */
enum class OrgType(val displayName: String) {
    FPSC("FPSC"),
    PPSC("PPSC"),
    SPSC("SPSC"),
    KPPSC("KPPSC"),
    BPSC("BPSC"),
    AJKPSC("AJKPSC"),
    NTS("NTS"),
    PTS("PTS"),
    OTS("OTS"),
    POLICE("Police"),
    ARMY("Pakistan Army"),
    NAVY("Pakistan Navy"),
    AIR_FORCE("Pakistan Air Force"),
    BANK("Banking Sector"),
    TEACHING("Teaching / Education"),
    OTHER("Other Government")
}

enum class JobStatus { OPEN, CLOSING_SOON, CLOSED }

enum class OptionKey { A, B, C, D }

enum class TestMode { PRACTICE, MOCK }

enum class QuestionDifficulty { EASY, MEDIUM, HARD }

enum class ThemeMode { LIGHT, DARK, SYSTEM }

enum class NotificationType(val label: String) {
    NEW_JOB("New Job"),
    DEADLINE("Deadline Reminder"),
    NEW_TEST("New Test"),
    ANNOUNCEMENT("Announcement")
}

enum class QuestionNavStatus { NOT_VISITED, NOT_ANSWERED, ANSWERED, MARKED_FOR_REVIEW, ANSWERED_MARKED }

enum class ReportStatus { PENDING, REVIEWED, DISMISSED }
