package com.jobprep.pk.presentation.test

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jobprep.pk.domain.model.OptionKey
import com.jobprep.pk.domain.model.QuestionNavStatus
import com.jobprep.pk.domain.model.TestAnswer
import com.jobprep.pk.domain.model.TestMode
import com.jobprep.pk.domain.repository.TestRepository
import com.jobprep.pk.domain.repository.UserRepository
import com.jobprep.pk.domain.usecase.GenerateTestUseCase
import com.jobprep.pk.presentation.common.UiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.net.URLDecoder
import javax.inject.Inject

data class TestTakingState(
    val title: String,
    val mode: TestMode,
    val answers: List<TestAnswer>,
    val currentIndex: Int = 0,
    val remainingSeconds: Int,
    val totalSeconds: Int,
    val isSubmitted: Boolean = false,
    val submittedAttemptId: String? = null,
    val showSubmitConfirm: Boolean = false,
    val showTimeUpDialog: Boolean = false
) {
    val currentAnswer: TestAnswer? get() = answers.getOrNull(currentIndex)

    fun statusFor(index: Int): QuestionNavStatus {
        val answer = answers.getOrNull(index) ?: return QuestionNavStatus.NOT_VISITED
        return when {
            answer.selectedOption != null && answer.isMarkedForReview -> QuestionNavStatus.ANSWERED_MARKED
            answer.selectedOption != null -> QuestionNavStatus.ANSWERED
            answer.isMarkedForReview -> QuestionNavStatus.MARKED_FOR_REVIEW
            else -> QuestionNavStatus.NOT_ANSWERED
        }
    }

    val answeredCount: Int get() = answers.count { it.selectedOption != null }
}

@HiltViewModel
class TestTakingViewModel @Inject constructor(
    private val generateTestUseCase: GenerateTestUseCase,
    private val testRepository: TestRepository,
    private val userRepository: UserRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val mode = TestMode.valueOf(checkNotNull(savedStateHandle["mode"]))
    private val blueprintId: String? = savedStateHandle.get<String>("blueprintId")?.takeIf { it != "none" }
    private val subjectIdsArg: String = checkNotNull(savedStateHandle["subjectIds"])
    private val questionCount: Int = checkNotNull(savedStateHandle["questionCount"])
    private val durationMinutes: Int = checkNotNull(savedStateHandle["durationMinutes"])
    private val title: String = URLDecoder.decode(checkNotNull(savedStateHandle["title"]), "UTF-8")

    private val _uiState = MutableStateFlow<UiState<TestTakingState>>(UiState.Loading)
    val uiState: StateFlow<UiState<TestTakingState>> = _uiState

    private var timerJob: Job? = null
    private var state: TestTakingState? = null

    init { loadTest() }

    private fun loadTest() {
        viewModelScope.launch {
            _uiState.value = UiState.Loading
            val subjectIds = if (subjectIdsArg == "all") emptyList() else subjectIdsArg.split(",")
            runCatching { generateTestUseCase(subjectIds, null, questionCount) }
                .onSuccess { answers ->
                    if (answers.isEmpty()) {
                        _uiState.value = UiState.Empty
                    } else {
                        val totalSeconds = durationMinutes * 60
                        state = TestTakingState(
                            title = title, mode = mode, answers = answers,
                            remainingSeconds = totalSeconds, totalSeconds = totalSeconds
                        )
                        _uiState.value = UiState.Success(state!!)
                        startTimer()
                    }
                }
                .onFailure { _uiState.value = UiState.Error(it.message ?: "Failed to generate the test") }
        }
    }

    private fun startTimer() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                val current = state ?: break
                if (current.isSubmitted) break
                val remaining = current.remainingSeconds - 1
                if (remaining <= 0) {
                    state = current.copy(remainingSeconds = 0, showTimeUpDialog = true)
                    _uiState.value = UiState.Success(state!!)
                    break
                } else {
                    state = current.copy(remainingSeconds = remaining)
                    _uiState.value = UiState.Success(state!!)
                }
            }
        }
    }

    fun selectOption(option: OptionKey) {
        val current = state ?: return
        val updatedAnswers = current.answers.toMutableList()
        val answer = updatedAnswers[current.currentIndex]
        updatedAnswers[current.currentIndex] = answer.copy(selectedOption = option)
        state = current.copy(answers = updatedAnswers)
        _uiState.value = UiState.Success(state!!)
    }

    fun toggleMarkForReview() {
        val current = state ?: return
        val updatedAnswers = current.answers.toMutableList()
        val answer = updatedAnswers[current.currentIndex]
        updatedAnswers[current.currentIndex] = answer.copy(isMarkedForReview = !answer.isMarkedForReview)
        state = current.copy(answers = updatedAnswers)
        _uiState.value = UiState.Success(state!!)
    }

    fun clearAnswer() {
        val current = state ?: return
        val updatedAnswers = current.answers.toMutableList()
        val answer = updatedAnswers[current.currentIndex]
        updatedAnswers[current.currentIndex] = answer.copy(selectedOption = null)
        state = current.copy(answers = updatedAnswers)
        _uiState.value = UiState.Success(state!!)
    }

    fun goToQuestion(index: Int) {
        val current = state ?: return
        if (index !in current.answers.indices) return
        state = current.copy(currentIndex = index)
        _uiState.value = UiState.Success(state!!)
    }

    fun nextQuestion() {
        val current = state ?: return
        if (current.currentIndex + 1 < current.answers.size) goToQuestion(current.currentIndex + 1)
    }

    fun previousQuestion() {
        val current = state ?: return
        if (current.currentIndex - 1 >= 0) goToQuestion(current.currentIndex - 1)
    }

    fun requestSubmit() {
        val current = state ?: return
        state = current.copy(showSubmitConfirm = true)
        _uiState.value = UiState.Success(state!!)
    }

    fun dismissSubmitConfirm() {
        val current = state ?: return
        state = current.copy(showSubmitConfirm = false)
        _uiState.value = UiState.Success(state!!)
    }

    fun confirmSubmit() {
        val current = state ?: return
        timerJob?.cancel()
        viewModelScope.launch {
            val userId = userRepository.currentUser.first()?.id ?: "guest"
            val elapsed = current.totalSeconds - current.remainingSeconds
            val attemptId = testRepository.saveAttempt(
                userId = userId,
                blueprintId = blueprintId,
                title = current.title,
                mode = current.mode,
                durationSeconds = elapsed,
                answers = current.answers
            )
            state = current.copy(isSubmitted = true, submittedAttemptId = attemptId, showSubmitConfirm = false, showTimeUpDialog = false)
            _uiState.value = UiState.Success(state!!)
        }
    }

    override fun onCleared() {
        super.onCleared()
        timerJob?.cancel()
    }
}
