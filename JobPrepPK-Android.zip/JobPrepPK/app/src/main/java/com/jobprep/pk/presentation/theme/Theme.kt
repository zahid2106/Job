package com.jobprep.pk.presentation.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import com.jobprep.pk.domain.model.ThemeMode

private val LightColors = lightColorScheme(
    primary = BrandPrimaryLight,
    onPrimary = Color_White,
    primaryContainer = BrandPrimaryContainerLight,
    onPrimaryContainer = BrandPrimaryLight,
    secondary = BrandSecondaryLight,
    onSecondary = Color_White,
    tertiary = BrandTertiaryLight,
    onTertiary = Color_White,
    background = SurfaceLight,
    onBackground = TextPrimaryLight,
    surface = SurfaceLight,
    onSurface = TextPrimaryLight,
    surfaceVariant = SurfaceContainerLight,
    onSurfaceVariant = TextSecondaryLight,
    outline = OutlineLight,
    error = ErrorLight,
    onError = Color_White
)

private val DarkColors = darkColorScheme(
    primary = BrandPrimaryDark,
    onPrimary = BrandPrimaryContainerDark,
    primaryContainer = BrandPrimaryContainerDark,
    onPrimaryContainer = BrandPrimaryDark,
    secondary = BrandSecondaryDark,
    onSecondary = SurfaceDark,
    tertiary = BrandTertiaryDark,
    onTertiary = SurfaceDark,
    background = SurfaceDark,
    onBackground = TextPrimaryDark,
    surface = SurfaceDark,
    onSurface = TextPrimaryDark,
    surfaceVariant = SurfaceContainerDark,
    onSurfaceVariant = TextSecondaryDark,
    outline = OutlineDark,
    error = ErrorDark,
    onError = SurfaceDark
)

/** Semantic status/success/warning colors not modeled by Material3's default ColorScheme. */
data class ExtendedColors(
    val success: androidx.compose.ui.graphics.Color,
    val warning: androidx.compose.ui.graphics.Color,
    val statusOpen: androidx.compose.ui.graphics.Color,
    val statusClosingSoon: androidx.compose.ui.graphics.Color,
    val statusClosed: androidx.compose.ui.graphics.Color
)

private val LocalExtendedColors = staticCompositionLocalOf {
    ExtendedColors(SuccessLight, WarningLight, StatusOpen, StatusClosingSoon, StatusClosed)
}

val MaterialTheme.extendedColors: ExtendedColors
    @Composable get() = LocalExtendedColors.current

@Composable
fun JobPrepTheme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    content: @Composable () -> Unit
) {
    val darkTheme = when (themeMode) {
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }
    val colorScheme = if (darkTheme) DarkColors else LightColors
    val extended = if (darkTheme) {
        ExtendedColors(SuccessDark, WarningDark, StatusOpen, StatusClosingSoon, StatusClosed)
    } else {
        ExtendedColors(SuccessLight, WarningLight, StatusOpen, StatusClosingSoon, StatusClosed)
    }

    androidx.compose.runtime.CompositionLocalProvider(LocalExtendedColors provides extended) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = AppTypography,
            shapes = AppShapes,
            content = content
        )
    }
}

private val Color_White = androidx.compose.ui.graphics.Color(0xFFFFFFFF)
