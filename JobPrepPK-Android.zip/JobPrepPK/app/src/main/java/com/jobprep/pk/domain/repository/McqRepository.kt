package com.jobprep.pk.domain.repository

import com.jobprep.pk.domain.model.Mcq
import com.jobprep.pk.domain.model.OrgType
import com.jobprep.pk.domain.model.Subject
import kotlinx.coroutines.flow.Flow

interface McqRepository {
    fun observeSubjects(): Flow<List<Subject>>
    suspend fun getSubjectById(id: String): Subject?

    suspend fun getRandomQuestions(
        subjectIds: List<String>,
        jobCategory: OrgType?,
        count: Int
    ): List<Mcq>

    fun observeBookmarked(userId: String): Flow<List<Mcq>>
    suspend fun toggleBookmark(userId: String, mcqId: String): Boolean
    suspend fun isBookmarked(userId: String, mcqId: String): Boolean
    suspend fun reportQuestion(mcqId: String, userId: String, reason: String)
    suspend fun refreshFromRemote(): Result<Unit>

    // Admin operations
    suspend fun upsertSubject(subject: Subject)
    suspend fun deleteSubject(id: String)
    suspend fun upsertMcq(mcq: Mcq)
    suspend fun deleteMcq(id: String)
    suspend fun bulkImportMcqs(mcqs: List<Mcq>): Int
    suspend fun getAllMcqsForSubject(subjectId: String): List<Mcq>

    // Admin: moderation queue for questions learners have flagged
    fun observeReportedQuestions(): Flow<List<Mcq>>
    suspend fun dismissReports(mcqId: String)
}
