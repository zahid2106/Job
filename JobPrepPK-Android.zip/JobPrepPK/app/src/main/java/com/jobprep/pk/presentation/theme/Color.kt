package com.jobprep.pk.presentation.theme

import androidx.compose.ui.graphics.Color

// Brand: a restrained, professional deep teal-green — evokes trust and public
// institutions without leaning on flag-color cliches or flashy gradients.
val BrandPrimaryLight = Color(0xFF0E4D3C)
val BrandPrimaryContainerLight = Color(0xFFD3F1E2)
val BrandSecondaryLight = Color(0xFF3D6B5C)
val BrandTertiaryLight = Color(0xFF8A6D1E) // muted gold accent, used sparingly (badges, highlights)

val BrandPrimaryDark = Color(0xFF7FD9B8)
val BrandPrimaryContainerDark = Color(0xFF16493A)
val BrandSecondaryDark = Color(0xFFA3CFBE)
val BrandTertiaryDark = Color(0xFFE2C067)

val SurfaceLight = Color(0xFFFBFCFA)
val SurfaceContainerLight = Color(0xFFF1F4F1)
val SurfaceDark = Color(0xFF101513)
val SurfaceContainerDark = Color(0xFF1A211D)

val OutlineLight = Color(0xFFD9DED9)
val OutlineDark = Color(0xFF3A423D)

val ErrorLight = Color(0xFFBA1A1A)
val ErrorDark = Color(0xFFFFB4AB)

val SuccessLight = Color(0xFF1B7A43)
val SuccessDark = Color(0xFF6FDB99)
val WarningLight = Color(0xFFA15C00)
val WarningDark = Color(0xFFFFB870)

val TextPrimaryLight = Color(0xFF1A1C1A)
val TextSecondaryLight = Color(0xFF49544D)
val TextPrimaryDark = Color(0xFFE2E3DF)
val TextSecondaryDark = Color(0xFFB9C2BB)

// Fixed semantic colors for job status chips (same in both themes for consistency)
val StatusOpen = Color(0xFF1B7A43)
val StatusClosingSoon = Color(0xFFA15C00)
val StatusClosed = Color(0xFF8A8F89)
