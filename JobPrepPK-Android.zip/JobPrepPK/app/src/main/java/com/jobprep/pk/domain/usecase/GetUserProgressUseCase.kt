package com.jobprep.pk.domain.usecase

import com.jobprep.pk.domain.model.UserProgress
import com.jobprep.pk.domain.repository.UserRepository
import javax.inject.Inject

class GetUserProgressUseCase @Inject constructor(
    private val userRepository: UserRepository
) {
    suspend operator fun invoke(userId: String): UserProgress = userRepository.getProgress(userId)
}
