package com.jobprep.pk.domain.model

data class SubjectPerformance(
    val subjectId: String,
    val subjectName: String,
    val correct: Int,
    val total: Int
) {
    val percentage: Float get() = if (total == 0) 0f else (correct * 100f / total)
}

data class TestAnswer(
    val mcq: Mcq,
    val selectedOption: OptionKey?,
    val isMarkedForReview: Boolean,
    val orderIndex: Int,
    val shuffledOptions: List<McqOption>
) {
    val isCorrect: Boolean get() = selectedOption != null && selectedOption == mcq.correctOption
    val isSkipped: Boolean get() = selectedOption == null
}

data class TestAttemptSummary(
    val id: String,
    val title: String,
    val mode: TestMode,
    val submittedAt: Long,
    val totalQuestions: Int,
    val correctCount: Int,
    val wrongCount: Int,
    val skippedCount: Int,
    val durationSeconds: Int,
    val score: Int,
    val percentage: Float
)

data class TestResult(
    val summary: TestAttemptSummary,
    val answers: List<TestAnswer>,
    val subjectPerformance: List<SubjectPerformance>
)
