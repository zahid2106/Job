package com.jobprep.pk.presentation.admin

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.jobprep.pk.presentation.components.AppTopBar
import com.jobprep.pk.presentation.theme.Spacing

@Composable
fun AdminDashboardScreen(
    onBack: () -> Unit,
    onManageJobs: () -> Unit,
    onManageSubjects: () -> Unit,
    onBulkImport: () -> Unit,
    onManageNotifications: () -> Unit,
    onReportedQuestions: () -> Unit,
    viewModel: AdminDashboardViewModel = hiltViewModel()
) {
    val stats by viewModel.stats.collectAsState()

    Scaffold(topBar = { AppTopBar(title = "Admin Panel", onBack = onBack) }) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(Spacing.lg)) {
            Text("Overview", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(Spacing.sm))
            Row(horizontalArrangement = Arrangement.spacedBy(Spacing.sm)) {
                StatTile("Jobs", stats.totalJobs.toString(), Modifier.weight(1f))
                StatTile("Subjects", stats.totalSubjects.toString(), Modifier.weight(1f))
            }
            Spacer(Modifier.height(Spacing.sm))
            Row(horizontalArrangement = Arrangement.spacedBy(Spacing.sm)) {
                StatTile("Mock Tests", stats.totalBlueprints.toString(), Modifier.weight(1f))
                StatTile(
                    "Reported MCQs", stats.reportedQuestions.toString(), Modifier.weight(1f),
                    highlight = stats.reportedQuestions > 0
                )
            }

            Spacer(Modifier.height(Spacing.xl))
            Text("Manage Content", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(Spacing.sm))

            AdminMenuRow(Icons.Filled.Work, "Job Announcements", "Add, edit or remove job listings", onManageJobs)
            AdminMenuRow(Icons.Filled.MenuBook, "Subjects & MCQs", "Manage subjects and questions", onManageSubjects)
            AdminMenuRow(Icons.Filled.UploadFile, "Bulk Import MCQs", "Import many questions at once", onBulkImport)
            AdminMenuRow(Icons.Filled.Campaign, "Notifications", "Send and manage announcements", onManageNotifications)
            AdminMenuRow(
                Icons.Filled.Flag, "Reported Questions", "Review learner-flagged MCQs",
                onReportedQuestions, badgeCount = stats.reportedQuestions
            )
        }
    }
}

@Composable
private fun StatTile(label: String, value: String, modifier: Modifier = Modifier, highlight: Boolean = false) {
    OutlinedCard(modifier = modifier) {
        Column(modifier = Modifier.padding(Spacing.md)) {
            Text(
                value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold,
                color = if (highlight) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
            )
            Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun AdminMenuRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    badgeCount: Int = 0
) {
    OutlinedCard(onClick = onClick, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(modifier = Modifier.padding(Spacing.md), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(Spacing.md))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (badgeCount > 0) {
                Badge(containerColor = MaterialTheme.colorScheme.error) { Text(badgeCount.toString()) }
                Spacer(Modifier.width(Spacing.sm))
            }
            Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
