package com.jobprep.pk.presentation.profile

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.outlined.Assignment
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.jobprep.pk.domain.model.TestAttemptSummary
import com.jobprep.pk.domain.model.TestMode
import com.jobprep.pk.presentation.common.UiState
import com.jobprep.pk.presentation.components.*
import com.jobprep.pk.presentation.theme.Spacing
import com.jobprep.pk.util.toFormattedDate
import com.jobprep.pk.util.toSecondsClock

@Composable
fun TestHistoryScreen(
    onBack: () -> Unit,
    onAttemptClick: (String) -> Unit,
    viewModel: TestHistoryViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()

    Scaffold(topBar = { AppTopBar(title = "Test History", onBack = onBack) }) { padding ->
        when (val s = state) {
            is UiState.Loading -> LoadingState(modifier = Modifier.padding(padding))
            is UiState.Error -> ErrorState(modifier = Modifier.padding(padding), message = s.message)
            is UiState.Empty -> EmptyState(
                modifier = Modifier.padding(padding),
                icon = androidx.compose.material.icons.Icons.Outlined.Assignment,
                title = "No tests yet",
                message = "Your practice sessions and mock tests will appear here."
            )
            is UiState.Success -> LazyColumn(
                modifier = Modifier.padding(padding),
                contentPadding = PaddingValues(Spacing.lg),
                verticalArrangement = Arrangement.spacedBy(Spacing.sm)
            ) {
                items(s.data, key = { it.id }) { attempt -> HistoryRow(attempt, onClick = { onAttemptClick(attempt.id) }) }
            }
        }
    }
}

@Composable
private fun HistoryRow(attempt: TestAttemptSummary, onClick: () -> Unit) {
    OutlinedCard(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.padding(Spacing.md), verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(attempt.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(2.dp))
                Text(
                    "${if (attempt.mode == TestMode.MOCK) "Mock Test" else "Practice"} • " +
                        "${attempt.submittedAt.toFormattedDate()} • ${attempt.durationSeconds.toSecondsClock()}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(
                "${"%.0f".format(attempt.percentage)}%",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = if (attempt.percentage >= 60f) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
            )
        }
    }
}
