package com.jobprep.pk.domain.model

data class AppNotification(
    val id: String,
    val title: String,
    val body: String,
    val type: NotificationType,
    val relatedId: String?,
    val createdAt: Long,
    val isRead: Boolean
)
