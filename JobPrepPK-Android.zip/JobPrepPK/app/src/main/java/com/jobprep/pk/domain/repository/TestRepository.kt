package com.jobprep.pk.domain.repository

import com.jobprep.pk.domain.model.TestAnswer
import com.jobprep.pk.domain.model.TestAttemptSummary
import com.jobprep.pk.domain.model.TestBlueprint
import com.jobprep.pk.domain.model.TestMode
import com.jobprep.pk.domain.model.TestResult
import kotlinx.coroutines.flow.Flow

interface TestRepository {
    fun observeBlueprints(): Flow<List<TestBlueprint>>
    fun observePopularBlueprints(limit: Int = 5): Flow<List<TestBlueprint>>
    suspend fun getBlueprintById(id: String): TestBlueprint?

    suspend fun saveAttempt(
        userId: String,
        blueprintId: String?,
        title: String,
        mode: TestMode,
        durationSeconds: Int,
        answers: List<TestAnswer>
    ): String

    fun observeHistory(userId: String, limit: Int = 50): Flow<List<TestAttemptSummary>>
    fun observeRecentAttempts(userId: String, limit: Int = 5): Flow<List<TestAttemptSummary>>
    suspend fun getResult(attemptId: String): TestResult?

    // Admin
    suspend fun upsertBlueprint(blueprint: TestBlueprint)
    suspend fun deleteBlueprint(id: String)
}
