package com.jobprep.pk.presentation.admin

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.hilt.navigation.compose.hiltViewModel
import com.jobprep.pk.domain.model.Mcq
import com.jobprep.pk.presentation.common.UiState
import com.jobprep.pk.presentation.components.*
import com.jobprep.pk.presentation.theme.Spacing

@Composable
fun AdminReportedQuestionsScreen(
    onBack: () -> Unit,
    onEditQuestion: (subjectId: String, mcqId: String) -> Unit,
    viewModel: AdminReportedQuestionsViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()
    var pendingDelete by remember { mutableStateOf<String?>(null) }

    Scaffold(topBar = { AppTopBar(title = "Reported Questions", onBack = onBack) }) { padding ->
        when (val s = state) {
            is UiState.Loading -> LoadingState(modifier = Modifier.padding(padding))
            is UiState.Error -> ErrorState(modifier = Modifier.padding(padding), message = s.message)
            is UiState.Empty -> EmptyState(
                modifier = Modifier.padding(padding),
                icon = Icons.Outlined.Flag,
                title = "No reported questions",
                message = "Questions flagged by learners for review will appear here."
            )
            is UiState.Success -> LazyColumn(
                modifier = Modifier.padding(padding),
                contentPadding = PaddingValues(Spacing.lg),
                verticalArrangement = Arrangement.spacedBy(Spacing.md)
            ) {
                items(s.data, key = { it.id }) { mcq ->
                    ReportedQuestionCard(
                        mcq = mcq,
                        onEdit = { onEditQuestion(mcq.subjectId, mcq.id) },
                        onDismiss = { viewModel.dismiss(mcq.id) },
                        onDelete = { pendingDelete = mcq.id }
                    )
                }
                item { Spacer(Modifier.height(Spacing.xxxl)) }
            }
        }
    }

    pendingDelete?.let { id ->
        ConfirmDialog(
            title = "Delete this question?",
            message = "This question will be permanently removed from the MCQ bank.",
            confirmLabel = "Delete",
            isDestructive = true,
            onConfirm = { viewModel.deleteQuestion(id); pendingDelete = null },
            onDismiss = { pendingDelete = null }
        )
    }
}

@Composable
private fun ReportedQuestionCard(mcq: Mcq, onEdit: () -> Unit, onDismiss: () -> Unit, onDelete: () -> Unit) {
    OutlinedCard(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(Spacing.md)) {
            Chip(mcq.subjectName, MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(Spacing.xs))
            Text(mcq.questionText, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(Spacing.sm))
            Text(
                "Correct answer: ${mcq.correctOption.name}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(Spacing.md))
            Row(horizontalArrangement = Arrangement.spacedBy(Spacing.sm)) {
                SecondaryButton(text = "Edit Question", onClick = onEdit, modifier = Modifier.weight(1f))
                SecondaryButton(text = "Dismiss", onClick = onDismiss, modifier = Modifier.weight(1f))
            }
            Spacer(Modifier.height(Spacing.sm))
            TextActionButton(text = "Delete Question", onClick = onDelete)
        }
    }
}
