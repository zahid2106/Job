package com.jobprep.pk.presentation.test

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.jobprep.pk.presentation.common.UiState
import com.jobprep.pk.presentation.components.*
import com.jobprep.pk.presentation.navigation.Screen
import com.jobprep.pk.presentation.theme.Spacing

@Composable
fun CustomTestSetupScreen(
    onBack: () -> Unit,
    onStartTest: (route: String) -> Unit,
    viewModel: CustomTestSetupViewModel = hiltViewModel()
) {
    val subjectsState by viewModel.subjectsState.collectAsState()
    val formState by viewModel.formState.collectAsState()

    Scaffold(topBar = { AppTopBar(title = "Custom Test", onBack = onBack) }) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            Text(
                "Select one or more subjects",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(horizontal = Spacing.lg, vertical = Spacing.md)
            )

            when (val s = subjectsState) {
                is UiState.Loading -> LoadingState(modifier = Modifier.weight(1f))
                is UiState.Error -> ErrorState(modifier = Modifier.weight(1f), message = s.message)
                is UiState.Empty -> EmptyState(modifier = Modifier.weight(1f), title = "No subjects", message = "Please check back later.")
                is UiState.Success -> LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(horizontal = Spacing.lg),
                    verticalArrangement = Arrangement.spacedBy(Spacing.xs)
                ) {
                    items(s.data, key = { it.id }) { subject ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = subject.id in formState.selectedSubjectIds,
                                onCheckedChange = { viewModel.toggleSubject(subject.id) }
                            )
                            Text(subject.name, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }

            Surface(shadowElevation = 4.dp) {
                Column(modifier = Modifier.padding(Spacing.lg)) {
                    Text("Number of questions: ${formState.questionCount}", style = MaterialTheme.typography.labelLarge)
                    Slider(
                        value = formState.questionCount.toFloat(),
                        onValueChange = { viewModel.setQuestionCount(it.toInt()) },
                        valueRange = 10f..100f,
                        steps = 8
                    )
                    Spacer(Modifier.height(Spacing.sm))
                    Text("Duration: ${formState.durationMinutes} minutes", style = MaterialTheme.typography.labelLarge)
                    Slider(
                        value = formState.durationMinutes.toFloat(),
                        onValueChange = { viewModel.setDuration(it.toInt()) },
                        valueRange = 5f..120f,
                        steps = 22
                    )
                    Spacer(Modifier.height(Spacing.md))
                    PrimaryButton(
                        text = "Start Test",
                        enabled = formState.selectedSubjectIds.isNotEmpty(),
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            val route = Screen.TestTaking.createRoute(
                                mode = "MOCK",
                                blueprintId = "none",
                                subjectIds = formState.selectedSubjectIds.joinToString(","),
                                questionCount = formState.questionCount,
                                durationMinutes = formState.durationMinutes,
                                title = "Custom Test"
                            )
                            onStartTest(route)
                        }
                    )
                    if (formState.selectedSubjectIds.isEmpty()) {
                        Spacer(Modifier.height(Spacing.xs))
                        Text(
                            "Select at least one subject to continue",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }
        }
    }
}
