package com.jobprep.pk.presentation.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jobprep.pk.domain.model.User
import com.jobprep.pk.domain.model.UserProgress
import com.jobprep.pk.domain.repository.UserRepository
import com.jobprep.pk.presentation.common.UiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ProfileData(val user: User, val progress: UserProgress)

@HiltViewModel
class ProfileViewModel @Inject constructor(
    private val userRepository: UserRepository
) : ViewModel() {

    private val refreshTrigger = MutableStateFlow(0)

    val uiState: StateFlow<UiState<ProfileData>> = userRepository.currentUser
        .combine(refreshTrigger) { user, _ -> user }
        .flatMapLatest { user ->
            if (user == null) flowOf(UiState.Empty)
            else flow { emit(UiState.Success(ProfileData(user, userRepository.getProgress(user.id)))) }
        }
        .catch { emit(UiState.Error(it.message ?: "Failed to load profile")) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UiState.Loading)

    fun refresh() {
        refreshTrigger.value += 1
    }

    fun logout() {
        viewModelScope.launch { userRepository.logout() }
    }
}
