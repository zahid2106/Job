package com.jobprep.pk.util

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

fun Long.toFormattedDate(pattern: String = "dd MMM yyyy"): String =
    SimpleDateFormat(pattern, Locale.getDefault()).format(Date(this))

fun Long.toRelativeTimeFromNow(): String {
    val diff = System.currentTimeMillis() - this
    val days = TimeUnit.MILLISECONDS.toDays(diff)
    return when {
        diff < 0 -> "just now"
        days == 0L -> "Today"
        days == 1L -> "Yesterday"
        days < 7 -> "$days days ago"
        else -> this.toFormattedDate()
    }
}

fun Long.daysUntil(): Long {
    val diff = this - System.currentTimeMillis()
    return TimeUnit.MILLISECONDS.toDays(diff).coerceAtLeast(0)
}

fun Int.toSecondsClock(): String {
    val minutes = this / 60
    val seconds = this % 60
    return "%02d:%02d".format(minutes, seconds)
}
