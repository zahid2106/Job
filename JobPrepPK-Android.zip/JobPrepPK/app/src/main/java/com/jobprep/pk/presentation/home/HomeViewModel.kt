package com.jobprep.pk.presentation.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jobprep.pk.domain.model.Job
import com.jobprep.pk.domain.model.TestAttemptSummary
import com.jobprep.pk.domain.model.TestBlueprint
import com.jobprep.pk.domain.model.User
import com.jobprep.pk.domain.model.UserProgress
import com.jobprep.pk.domain.repository.JobRepository
import com.jobprep.pk.domain.repository.NotificationRepository
import com.jobprep.pk.domain.repository.TestRepository
import com.jobprep.pk.domain.repository.UserRepository
import com.jobprep.pk.presentation.common.UiState
import com.jobprep.pk.util.NetworkMonitor
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import javax.inject.Inject

data class HomeUiData(
    val user: User?,
    val featuredJobs: List<Job>,
    val upcomingDeadlines: List<Job>,
    val popularTests: List<TestBlueprint>,
    val recentAttempts: List<TestAttemptSummary>,
    val progress: UserProgress?,
    val isOffline: Boolean
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val jobRepository: JobRepository,
    private val testRepository: TestRepository,
    private val userRepository: UserRepository,
    private val notificationRepository: NotificationRepository,
    networkMonitor: NetworkMonitor
) : ViewModel() {

    val unreadNotifications: StateFlow<Int> = notificationRepository.observeUnreadCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    private val isOffline: StateFlow<Boolean> = networkMonitor.observe()
        .map { connected -> !connected }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val uiState: StateFlow<UiState<HomeUiData>> = combine(
        userRepository.currentUser,
        jobRepository.observeFeaturedJobs(),
        jobRepository.observeUpcomingDeadlines(5),
        testRepository.observePopularBlueprints(5),
        isOffline
    ) { user, featured, deadlines, popular, offline ->
        Triple(user, featured to deadlines, popular) to offline
    }.flatMapLatest { (bundle, offline) ->
        val (user, jobPair) = bundle
        val (featured, deadlines) = jobPair
        val popular = bundle.third

        if (user == null) {
            flowOf(
                UiState.Success(
                    HomeUiData(null, featured, deadlines, popular, emptyList(), null, offline)
                )
            )
        } else {
            testRepository.observeRecentAttempts(user.id, 5).map { recent ->
                val progress = runCatching { userRepository.getProgress(user.id) }.getOrNull()
                UiState.Success(
                    HomeUiData(
                        user = user,
                        featuredJobs = featured,
                        upcomingDeadlines = deadlines,
                        popularTests = popular,
                        recentAttempts = recent,
                        progress = progress,
                        isOffline = offline
                    )
                )
            }
        }
    }.catch { emit(UiState.Error(it.message ?: "Something went wrong")) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UiState.Loading)
}
