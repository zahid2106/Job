package com.jobprep.pk.data.repository

import com.jobprep.pk.data.local.dao.NotificationDao
import com.jobprep.pk.domain.model.AppNotification
import com.jobprep.pk.domain.repository.NotificationRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NotificationRepositoryImpl @Inject constructor(
    private val notificationDao: NotificationDao
) : NotificationRepository {

    override fun observeAll(): Flow<List<AppNotification>> =
        notificationDao.observeAll().map { list -> list.map { it.toDomain() } }

    override fun observeUnreadCount(): Flow<Int> = notificationDao.observeUnreadCount()

    override suspend fun markRead(id: String) = notificationDao.markRead(id)

    override suspend fun markAllRead() = notificationDao.markAllRead()

    override suspend fun send(notification: AppNotification) = notificationDao.upsert(notification.toEntity())

    override suspend fun delete(id: String) = notificationDao.delete(id)
}
