package com.jobprep.pk.presentation.jobs

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.hilt.navigation.compose.hiltViewModel
import com.jobprep.pk.presentation.common.UiState
import com.jobprep.pk.presentation.components.*
import com.jobprep.pk.presentation.theme.Spacing

@Composable
fun JobSearchScreen(
    onBack: () -> Unit,
    onJobClick: (String) -> Unit,
    viewModel: JobsViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()
    val filter by viewModel.filterState.collectAsState()
    val focusRequester = remember { FocusRequester() }

    LaunchedEffect(Unit) { runCatching { focusRequester.requestFocus() } }

    Scaffold(topBar = { AppTopBar(title = "Search Jobs", onBack = onBack) }) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            Box(modifier = Modifier.padding(Spacing.lg)) {
                AppSearchBar(
                    query = filter.query,
                    onQueryChange = viewModel::onQueryChange,
                    placeholder = "Search by title or organization…",
                    modifier = Modifier.focusRequester(focusRequester)
                )
            }
            when (val s = state) {
                is UiState.Loading -> LoadingState()
                is UiState.Error -> ErrorState(message = s.message)
                is UiState.Empty -> EmptyState(
                    icon = androidx.compose.material.icons.Icons.Outlined.Search,
                    title = if (filter.query.isBlank()) "Search for a job" else "No results",
                    message = if (filter.query.isBlank()) "Try \"FPSC\", \"Police\" or \"Bank Officer\"" else "Try a different search term."
                )
                is UiState.Success -> LazyColumn(
                    contentPadding = PaddingValues(horizontal = Spacing.lg, vertical = Spacing.sm),
                    verticalArrangement = Arrangement.spacedBy(Spacing.md)
                ) {
                    items(s.data, key = { it.id }) { job -> JobCard(job = job, onClick = { onJobClick(job.id) }) }
                }
            }
        }
    }
}
