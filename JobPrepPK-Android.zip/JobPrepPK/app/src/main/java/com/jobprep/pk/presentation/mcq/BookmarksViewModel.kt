package com.jobprep.pk.presentation.mcq

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jobprep.pk.domain.model.Mcq
import com.jobprep.pk.domain.repository.McqRepository
import com.jobprep.pk.domain.repository.UserRepository
import com.jobprep.pk.presentation.common.UiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class BookmarksViewModel @Inject constructor(
    private val mcqRepository: McqRepository,
    private val userRepository: UserRepository
) : ViewModel() {

    val uiState: StateFlow<UiState<List<Mcq>>> = userRepository.currentUser
        .flatMapLatest { user ->
            if (user == null) flowOf(UiState.Empty)
            else mcqRepository.observeBookmarked(user.id).map { list ->
                if (list.isEmpty()) UiState.Empty else UiState.Success(list)
            }
        }
        .catch { emit(UiState.Error(it.message ?: "Failed to load bookmarks")) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UiState.Loading)

    fun removeBookmark(mcqId: String) {
        viewModelScope.launch {
            val userId = userRepository.currentUser.first()?.id ?: return@launch
            mcqRepository.toggleBookmark(userId, mcqId)
        }
    }
}
