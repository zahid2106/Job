package com.jobprep.pk.presentation.test

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.jobprep.pk.domain.model.SubjectPerformance
import com.jobprep.pk.domain.model.TestResult
import com.jobprep.pk.presentation.common.UiState
import com.jobprep.pk.presentation.components.*
import com.jobprep.pk.presentation.theme.Spacing
import com.jobprep.pk.presentation.theme.extendedColors
import com.jobprep.pk.util.toSecondsClock

@Composable
fun ResultScreen(
    onReviewAnswers: () -> Unit,
    onDone: () -> Unit,
    viewModel: ResultViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()

    Scaffold(topBar = { AppTopBar(title = "Test Result") }) { padding ->
        when (val s = state) {
            is UiState.Loading -> LoadingState(modifier = Modifier.padding(padding))
            is UiState.Error -> ErrorState(modifier = Modifier.padding(padding), message = s.message)
            is UiState.Empty -> EmptyState(modifier = Modifier.padding(padding), title = "Not found", message = "This result is unavailable.")
            is UiState.Success -> ResultContent(
                modifier = Modifier.padding(padding),
                result = s.data,
                onReviewAnswers = onReviewAnswers,
                onDone = onDone
            )
        }
    }
}

@Composable
private fun ResultContent(
    modifier: Modifier = Modifier,
    result: TestResult,
    onReviewAnswers: () -> Unit,
    onDone: () -> Unit
) {
    val summary = result.summary
    Column(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(Spacing.lg),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            ScoreRing(percentage = summary.percentage)
            Spacer(Modifier.height(Spacing.md))
            Text(summary.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(Spacing.xxl))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(Spacing.sm)
            ) {
                MetricCard("Correct", summary.correctCount.toString(), MaterialTheme.colorScheme.primary, Modifier.weight(1f))
                MetricCard("Wrong", summary.wrongCount.toString(), MaterialTheme.colorScheme.error, Modifier.weight(1f))
                MetricCard("Skipped", summary.skippedCount.toString(), MaterialTheme.colorScheme.onSurfaceVariant, Modifier.weight(1f))
            }
            Spacer(Modifier.height(Spacing.sm))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Spacing.sm)) {
                MetricCard("Time Taken", summary.durationSeconds.toSecondsClock(), MaterialTheme.colorScheme.secondary, Modifier.weight(1f))
                MetricCard("Total Questions", summary.totalQuestions.toString(), MaterialTheme.colorScheme.secondary, Modifier.weight(1f))
            }

            if (result.subjectPerformance.size > 1) {
                Spacer(Modifier.height(Spacing.xl))
                Text(
                    "Subject-wise Performance", style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold, modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(Spacing.sm))
                result.subjectPerformance.forEach { perf -> SubjectPerformanceRow(perf) }
            }
            Spacer(Modifier.height(Spacing.xxl))
        }

        Surface(shadowElevation = 4.dp) {
            Column(modifier = Modifier.padding(Spacing.lg)) {
                PrimaryButton(text = "Review Answers", onClick = onReviewAnswers, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(Spacing.sm))
                SecondaryButton(text = "Done", onClick = onDone, modifier = Modifier.fillMaxWidth())
            }
        }
    }
}

@Composable
private fun ScoreRing(percentage: Float) {
    val color = when {
        percentage >= 75f -> MaterialTheme.colorScheme.primary
        percentage >= 50f -> MaterialTheme.extendedColors.warning
        else -> MaterialTheme.colorScheme.error
    }
    Box(
        modifier = Modifier
            .padding(top = Spacing.lg)
            .size(140.dp)
            .clip(CircleShape)
            .background(color.copy(alpha = 0.1f)),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("${"%.0f".format(percentage)}%", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold, color = color)
            Text("Score", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun MetricCard(label: String, value: String, accentColor: androidx.compose.ui.graphics.Color, modifier: Modifier = Modifier) {
    OutlinedCard(modifier = modifier) {
        Column(modifier = Modifier.padding(Spacing.sm), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = accentColor)
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun SubjectPerformanceRow(perf: SubjectPerformance) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = Spacing.xs)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(perf.subjectName, style = MaterialTheme.typography.bodyMedium)
            Text("${perf.correct}/${perf.total}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { perf.percentage / 100f },
            modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
            color = if (perf.percentage >= 60f) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
        )
    }
}
