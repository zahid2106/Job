package com.jobprep.pk.data.repository

import com.jobprep.pk.data.datastore.PreferencesManager
import com.jobprep.pk.data.local.dao.BookmarkDao
import com.jobprep.pk.data.local.dao.TestAttemptDao
import com.jobprep.pk.data.local.dao.UserDao
import com.jobprep.pk.data.local.entity.UserEntity
import com.jobprep.pk.domain.model.SubjectPerformance
import com.jobprep.pk.domain.model.User
import com.jobprep.pk.domain.model.UserProgress
import com.jobprep.pk.domain.repository.AuthResult
import com.jobprep.pk.domain.repository.UserRepository
import com.jobprep.pk.util.PasswordHasher
import com.jobprep.pk.util.Validators
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class UserRepositoryImpl @Inject constructor(
    private val userDao: UserDao,
    private val attemptDao: TestAttemptDao,
    private val bookmarkDao: BookmarkDao,
    private val preferencesManager: PreferencesManager
) : UserRepository {

    override val currentUser: Flow<User?> = preferencesManager.sessionUserId
        .distinctUntilChanged()
        .flatMapLatest { userId ->
            if (userId == null) flowOf(null)
            else flowOf(userId) // resolved lazily below via getById to avoid over-fetching in a hot flow
        }
        .map { userId -> userId?.let { userDao.getById(it)?.toDomain() } }

    override suspend fun register(name: String, email: String, password: String): AuthResult {
        if (!Validators.isValidName(name)) return AuthResult.Error("Please enter a valid name (2-60 characters).")
        if (!Validators.isValidEmail(email)) return AuthResult.Error("Please enter a valid email address.")
        Validators.passwordStrengthMessage(password)?.let { return AuthResult.Error(it) }
        if (userDao.getByEmail(email.trim().lowercase()) != null) {
            return AuthResult.Error("An account with this email already exists.")
        }

        val salt = PasswordHasher.generateSalt()
        val entity = UserEntity(
            id = UUID.randomUUID().toString(),
            name = name.trim(),
            email = email.trim().lowercase(),
            passwordHash = PasswordHasher.hash(password, salt),
            salt = salt,
            isAdmin = false,
            createdAt = System.currentTimeMillis()
        )
        userDao.insert(entity)
        preferencesManager.setSessionUserId(entity.id)
        return AuthResult.Success(entity.toDomain())
    }

    override suspend fun login(email: String, password: String): AuthResult {
        if (!Validators.isValidEmail(email)) return AuthResult.Error("Please enter a valid email address.")
        val entity = userDao.getByEmail(email.trim().lowercase())
            ?: return AuthResult.Error("No account found with this email.")
        if (!PasswordHasher.verify(password, entity.salt, entity.passwordHash)) {
            return AuthResult.Error("Incorrect password. Please try again.")
        }
        preferencesManager.setSessionUserId(entity.id)
        return AuthResult.Success(entity.toDomain())
    }

    override suspend fun logout() {
        preferencesManager.setSessionUserId(null)
    }

    override suspend fun updateProfile(name: String, email: String): AuthResult {
        if (!Validators.isValidName(name)) return AuthResult.Error("Please enter a valid name.")
        if (!Validators.isValidEmail(email)) return AuthResult.Error("Please enter a valid email.")

        val sessionUserId = preferencesManager.sessionUserId.first()
            ?: return AuthResult.Error("Your session has expired. Please sign in again.")
        val existing = userDao.getById(sessionUserId)
            ?: return AuthResult.Error("Your session has expired. Please sign in again.")

        val normalizedEmail = email.trim().lowercase()
        if (normalizedEmail != existing.email) {
            val emailTaken = userDao.getByEmail(normalizedEmail)
            if (emailTaken != null) return AuthResult.Error("Another account already uses this email.")
        }

        val updated = existing.copy(name = name.trim(), email = normalizedEmail)
        userDao.update(updated)
        return AuthResult.Success(updated.toDomain())
    }

    override suspend fun getProgress(userId: String): UserProgress {
        val attempts = attemptDao.getAllForUser(userId)
        val bookmarkedCount = bookmarkDao.countForUser(userId)

        if (attempts.isEmpty()) {
            return UserProgress(
                testsAttempted = 0, averageScore = 0f, highestScore = 0f, totalQuestionsAnswered = 0,
                totalCorrect = 0, subjectPerformance = emptyList(), weakSubjects = emptyList(),
                bookmarkedCount = bookmarkedCount
            )
        }

        val averageScore = attempts.map { it.percentage }.average().toFloat()
        val highestScore = attempts.maxOf { it.percentage }
        val totalQuestions = attempts.sumOf { it.totalQuestions }
        val totalCorrect = attempts.sumOf { it.correctCount }

        // Subject-wise performance requires joining answers -> mcqs -> subjects,
        // which is done at the answer level in TestRepository for a single attempt.
        // Here we approximate weak areas using per-attempt aggregate percentage,
        // grouped by attempt title as a lightweight proxy when full answer detail
        // across all history would be expensive to recompute on every profile view.
        val bySubjectLikeGroup = attempts.groupBy { it.title }
        val subjectPerformance = bySubjectLikeGroup.map { (title, list) ->
            SubjectPerformance(
                subjectId = title,
                subjectName = title,
                correct = list.sumOf { it.correctCount },
                total = list.sumOf { it.totalQuestions }
            )
        }.sortedByDescending { it.total }

        val weakSubjects = subjectPerformance.filter { it.percentage < 60f }.sortedBy { it.percentage }

        return UserProgress(
            testsAttempted = attempts.size,
            averageScore = (averageScore * 10).let { kotlin.math.round(it) / 10f },
            highestScore = highestScore,
            totalQuestionsAnswered = totalQuestions,
            totalCorrect = totalCorrect,
            subjectPerformance = subjectPerformance,
            weakSubjects = weakSubjects,
            bookmarkedCount = bookmarkedCount
        )
    }
}
