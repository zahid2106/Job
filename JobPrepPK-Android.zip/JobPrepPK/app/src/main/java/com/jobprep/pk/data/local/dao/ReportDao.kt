package com.jobprep.pk.data.local.dao

import androidx.room.Insert
import androidx.room.Dao
import androidx.room.Query
import com.jobprep.pk.data.local.entity.ReportEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ReportDao {
    @Insert
    suspend fun insert(report: ReportEntity)

    @Query("SELECT * FROM reports ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<ReportEntity>>
}
