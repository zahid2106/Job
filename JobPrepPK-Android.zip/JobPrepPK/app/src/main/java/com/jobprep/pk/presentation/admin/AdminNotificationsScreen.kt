package com.jobprep.pk.presentation.admin

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.jobprep.pk.domain.model.AppNotification
import com.jobprep.pk.domain.model.NotificationType
import com.jobprep.pk.presentation.common.UiState
import com.jobprep.pk.presentation.components.*
import com.jobprep.pk.presentation.theme.Spacing
import com.jobprep.pk.util.toRelativeTimeFromNow

@Composable
fun AdminNotificationsScreen(
    onBack: () -> Unit,
    viewModel: AdminNotificationsViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()
    var showComposeDialog by remember { mutableStateOf(false) }
    var pendingDelete by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = { AppTopBar(title = "Notifications", onBack = onBack) },
        floatingActionButton = {
            FloatingActionButton(onClick = { showComposeDialog = true }) { Icon(Icons.Filled.Add, contentDescription = "Compose") }
        }
    ) { padding ->
        when (val s = state) {
            is UiState.Loading -> LoadingState(modifier = Modifier.padding(padding))
            is UiState.Error -> ErrorState(modifier = Modifier.padding(padding), message = s.message)
            is UiState.Empty -> EmptyState(
                modifier = Modifier.padding(padding), title = "No notifications sent",
                message = "Compose an announcement to notify learners.", actionLabel = "Compose",
                onAction = { showComposeDialog = true }
            )
            is UiState.Success -> LazyColumn(
                modifier = Modifier.padding(padding),
                contentPadding = PaddingValues(Spacing.lg),
                verticalArrangement = Arrangement.spacedBy(Spacing.sm)
            ) {
                items(s.data, key = { it.id }) { notification ->
                    AdminNotificationRow(notification, onDelete = { pendingDelete = notification.id })
                }
                item { Spacer(Modifier.height(Spacing.xxxl)) }
            }
        }
    }

    if (showComposeDialog) {
        ComposeNotificationDialog(
            onDismiss = { showComposeDialog = false },
            onSend = { title, body, type -> viewModel.sendNotification(title, body, type); showComposeDialog = false }
        )
    }

    pendingDelete?.let { id ->
        ConfirmDialog(
            title = "Delete notification?",
            message = "Learners who haven't seen it yet will no longer receive it.",
            confirmLabel = "Delete",
            isDestructive = true,
            onConfirm = { viewModel.deleteNotification(id); pendingDelete = null },
            onDismiss = { pendingDelete = null }
        )
    }
}

@Composable
private fun AdminNotificationRow(notification: AppNotification, onDelete: () -> Unit) {
    OutlinedCard(modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.padding(Spacing.md), verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Chip(notification.type.label, MaterialTheme.colorScheme.primary)
                }
                Spacer(Modifier.height(4.dp))
                Text(notification.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text(notification.body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
                Spacer(Modifier.height(4.dp))
                Text(notification.createdAt.toRelativeTimeFromNow(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error) }
        }
    }
}

@Composable
private fun ComposeNotificationDialog(onDismiss: () -> Unit, onSend: (String, String, NotificationType) -> Unit) {
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var type by remember { mutableStateOf(NotificationType.ANNOUNCEMENT) }
    var typeMenuExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Compose Notification") },
        text = {
            Column {
                AppTextField(value = title, onValueChange = { title = it }, label = "Title")
                Spacer(Modifier.height(Spacing.sm))
                AppTextField(value = body, onValueChange = { body = it }, label = "Message", minLines = 2, singleLine = false)
                Spacer(Modifier.height(Spacing.sm))
                Box {
                    OutlinedButton(onClick = { typeMenuExpanded = true }) { Text("Type: ${type.label}") }
                    DropdownMenu(expanded = typeMenuExpanded, onDismissRequest = { typeMenuExpanded = false }) {
                        NotificationType.entries.forEach { option ->
                            DropdownMenuItem(text = { Text(option.label) }, onClick = { type = option; typeMenuExpanded = false })
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onSend(title, body, type) }, enabled = title.isNotBlank() && body.isNotBlank()) { Text("Send") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
