package com.jobprep.pk.domain.usecase

import com.jobprep.pk.domain.model.Mcq
import com.jobprep.pk.domain.model.McqOption
import com.jobprep.pk.domain.model.OptionKey
import com.jobprep.pk.domain.model.TestAnswer
import com.jobprep.pk.domain.repository.McqRepository
import javax.inject.Inject

/**
 * Builds a randomized, shuffled question set for a mock/practice test.
 * Both question order and option order are randomized per attempt so
 * repeated attempts of the same blueprint never look identical.
 */
class GenerateTestUseCase @Inject constructor(
    private val mcqRepository: McqRepository
) {
    suspend operator fun invoke(
        subjectIds: List<String>,
        jobCategory: com.jobprep.pk.domain.model.OrgType?,
        questionCount: Int
    ): List<TestAnswer> {
        val questions = mcqRepository.getRandomQuestions(subjectIds, jobCategory, questionCount)
        return questions.mapIndexed { index, mcq ->
            TestAnswer(
                mcq = mcq,
                selectedOption = null,
                isMarkedForReview = false,
                orderIndex = index,
                shuffledOptions = mcq.options.shuffled()
            )
        }
    }
}
