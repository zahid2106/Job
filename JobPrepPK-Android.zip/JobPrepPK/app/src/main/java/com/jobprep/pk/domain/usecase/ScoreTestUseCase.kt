package com.jobprep.pk.domain.usecase

import com.jobprep.pk.domain.model.SubjectPerformance
import com.jobprep.pk.domain.model.TestAnswer
import kotlin.math.roundToInt

data class ScoreBreakdown(
    val correct: Int,
    val wrong: Int,
    val skipped: Int,
    val score: Int,
    val percentage: Float,
    val subjectPerformance: List<SubjectPerformance>
)

/** Pure scoring logic: no negative marking, 1 mark per correct answer. */
class ScoreTestUseCase {
    operator fun invoke(answers: List<TestAnswer>): ScoreBreakdown {
        val correct = answers.count { it.isCorrect }
        val skipped = answers.count { it.isSkipped }
        val wrong = answers.size - correct - skipped
        val percentage = if (answers.isEmpty()) 0f else (correct * 100f / answers.size)

        val bySubject = answers.groupBy { it.mcq.subjectId }
        val subjectPerformance = bySubject.map { (subjectId, list) ->
            SubjectPerformance(
                subjectId = subjectId,
                subjectName = list.first().mcq.subjectName,
                correct = list.count { it.isCorrect },
                total = list.size
            )
        }.sortedByDescending { it.total }

        return ScoreBreakdown(
            correct = correct,
            wrong = wrong,
            skipped = skipped,
            score = correct,
            percentage = (percentage * 10).roundToInt() / 10f,
            subjectPerformance = subjectPerformance
        )
    }
}
