package com.jobprep.pk.presentation.jobs

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jobprep.pk.domain.model.Job
import com.jobprep.pk.domain.model.OrgType
import com.jobprep.pk.domain.repository.JobFilter
import com.jobprep.pk.domain.repository.JobRepository
import com.jobprep.pk.presentation.common.UiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import javax.inject.Inject

data class JobsFilterState(
    val query: String = "",
    val selectedOrgs: Set<OrgType> = emptySet()
)

@HiltViewModel
class JobsViewModel @Inject constructor(
    private val jobRepository: JobRepository
) : ViewModel() {

    private val _filterState = MutableStateFlow(JobsFilterState())
    val filterState: StateFlow<JobsFilterState> = _filterState

    val uiState: StateFlow<UiState<List<Job>>> = _filterState
        .debounce(200)
        .flatMapLatest { filter ->
            jobRepository.observeJobs(JobFilter(organizations = filter.selectedOrgs, query = filter.query))
        }
        .map { jobs -> if (jobs.isEmpty()) UiState.Empty else UiState.Success(jobs) }
        .catch { emit(UiState.Error(it.message ?: "Failed to load jobs")) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UiState.Loading)

    fun onQueryChange(query: String) {
        _filterState.value = _filterState.value.copy(query = query)
    }

    fun toggleOrg(org: OrgType) {
        val current = _filterState.value.selectedOrgs
        _filterState.value = _filterState.value.copy(
            selectedOrgs = if (org in current) current - org else current + org
        )
    }

    fun clearFilters() {
        _filterState.value = JobsFilterState()
    }
}
