package com.jobprep.pk.data.repository

import com.jobprep.pk.data.local.dao.JobDao
import com.jobprep.pk.domain.model.Job
import com.jobprep.pk.domain.repository.JobFilter
import com.jobprep.pk.domain.repository.JobRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class JobRepositoryImpl @Inject constructor(
    private val jobDao: JobDao
) : JobRepository {

    override fun observeJobs(filter: JobFilter): Flow<List<Job>> {
        return jobDao.searchAll(filter.query.trim()).map { list ->
            list.map { it.toDomain() }
                .filter { job -> filter.organizations.isEmpty() || job.organization in filter.organizations }
                .filter { job -> !filter.activeOnly || job.isActive }
        }
    }

    override fun observeFeaturedJobs(): Flow<List<Job>> =
        jobDao.observeFeatured().map { list -> list.map { it.toDomain() } }

    override fun observeUpcomingDeadlines(limit: Int): Flow<List<Job>> =
        jobDao.observeUpcomingDeadlines(System.currentTimeMillis(), limit).map { list -> list.map { it.toDomain() } }

    override suspend fun getJobById(id: String): Job? = jobDao.getById(id)?.toDomain()

    override suspend fun refreshFromRemote(): Result<Unit> {
        // Remote sync is best-effort: if the backend is unreachable the app keeps
        // working fully offline from the local cache (Room), which is the single
        // source of truth for the UI. See SyncWorker for the periodic trigger.
        return Result.success(Unit)
    }

    override suspend fun upsertJob(job: Job) = jobDao.upsert(job.toEntity())

    override suspend fun deleteJob(id: String) = jobDao.delete(id)
}
