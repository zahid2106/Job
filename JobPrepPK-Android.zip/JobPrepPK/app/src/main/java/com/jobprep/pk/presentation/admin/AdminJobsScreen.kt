package com.jobprep.pk.presentation.admin

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.jobprep.pk.domain.model.Job
import com.jobprep.pk.presentation.common.UiState
import com.jobprep.pk.presentation.components.*
import com.jobprep.pk.presentation.theme.Spacing

@Composable
fun AdminJobsScreen(
    onBack: () -> Unit,
    onAddJob: () -> Unit,
    onEditJob: (String) -> Unit,
    viewModel: AdminJobsViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()
    var pendingDeleteId by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = { AppTopBar(title = "Manage Jobs", onBack = onBack) },
        floatingActionButton = {
            FloatingActionButton(onClick = onAddJob) { Icon(Icons.Filled.Add, contentDescription = "Add job") }
        }
    ) { padding ->
        when (val s = state) {
            is UiState.Loading -> LoadingState(modifier = Modifier.padding(padding))
            is UiState.Error -> ErrorState(modifier = Modifier.padding(padding), message = s.message)
            is UiState.Empty -> EmptyState(
                modifier = Modifier.padding(padding), title = "No jobs yet",
                message = "Tap the + button to add your first job listing.", actionLabel = "Add Job", onAction = onAddJob
            )
            is UiState.Success -> LazyColumn(
                modifier = Modifier.padding(padding),
                contentPadding = PaddingValues(Spacing.lg),
                verticalArrangement = Arrangement.spacedBy(Spacing.sm)
            ) {
                items(s.data, key = { it.id }) { job ->
                    AdminJobRow(
                        job = job,
                        onEdit = { onEditJob(job.id) },
                        onDelete = { pendingDeleteId = job.id }
                    )
                }
                item { Spacer(Modifier.height(Spacing.xxxl)) }
            }
        }
    }

    pendingDeleteId?.let { id ->
        ConfirmDialog(
            title = "Delete job listing?",
            message = "This will permanently remove the job announcement. This action cannot be undone.",
            confirmLabel = "Delete",
            isDestructive = true,
            onConfirm = { viewModel.deleteJob(id); pendingDeleteId = null },
            onDismiss = { pendingDeleteId = null }
        )
    }
}

@Composable
private fun AdminJobRow(job: Job, onEdit: () -> Unit, onDelete: () -> Unit) {
    OutlinedCard(modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.padding(Spacing.md), verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(job.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text(
                    "${job.organization.displayName} • ${job.vacancies} vacancies",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(4.dp))
                StatusBadge(job.status())
            }
            IconButton(onClick = onEdit) { Icon(Icons.Filled.Edit, contentDescription = "Edit") }
            IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error) }
        }
    }
}
