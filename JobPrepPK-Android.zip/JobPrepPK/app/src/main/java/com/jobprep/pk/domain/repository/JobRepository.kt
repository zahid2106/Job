package com.jobprep.pk.domain.repository

import com.jobprep.pk.domain.model.Job
import com.jobprep.pk.domain.model.OrgType
import kotlinx.coroutines.flow.Flow

data class JobFilter(
    val organizations: Set<OrgType> = emptySet(),
    val query: String = "",
    val activeOnly: Boolean = true
)

interface JobRepository {
    fun observeJobs(filter: JobFilter): Flow<List<Job>>
    fun observeFeaturedJobs(): Flow<List<Job>>
    fun observeUpcomingDeadlines(limit: Int = 5): Flow<List<Job>>
    suspend fun getJobById(id: String): Job?
    suspend fun refreshFromRemote(): Result<Unit>

    // Admin operations
    suspend fun upsertJob(job: Job)
    suspend fun deleteJob(id: String)
}
