package com.jobprep.pk.presentation.home

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.outlined.WorkOff
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.jobprep.pk.presentation.common.UiState
import com.jobprep.pk.presentation.components.*
import com.jobprep.pk.presentation.theme.Spacing
import com.jobprep.pk.util.daysUntil

@Composable
fun HomeScreen(
    onJobClick: (String) -> Unit,
    onSearchClick: () -> Unit,
    onNotificationsClick: () -> Unit,
    onTestClick: (String) -> Unit,
    onSeeAllJobs: () -> Unit,
    onSeeAllTests: () -> Unit,
    viewModel: HomeViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()
    val unread by viewModel.unreadNotifications.collectAsState()

    Scaffold(
        topBar = {
            HomeTopBar(
                userName = (state as? UiState.Success)?.data?.user?.name ?: "Guest",
                unreadNotifications = unread,
                onNotificationsClick = onNotificationsClick
            )
        }
    ) { padding ->
        when (val s = state) {
            is UiState.Loading -> LoadingState(modifier = Modifier.padding(padding))
            is UiState.Error -> ErrorState(modifier = Modifier.padding(padding), message = s.message)
            is UiState.Empty -> EmptyState(modifier = Modifier.padding(padding), title = "Nothing here yet", message = "Check back soon.")
            is UiState.Success -> HomeContent(
                data = s.data,
                modifier = Modifier.padding(padding),
                onJobClick = onJobClick,
                onSearchClick = onSearchClick,
                onTestClick = onTestClick,
                onSeeAllJobs = onSeeAllJobs,
                onSeeAllTests = onSeeAllTests
            )
        }
    }
}

@Composable
private fun HomeContent(
    data: HomeUiData,
    modifier: Modifier = Modifier,
    onJobClick: (String) -> Unit,
    onSearchClick: () -> Unit,
    onTestClick: (String) -> Unit,
    onSeeAllJobs: () -> Unit,
    onSeeAllTests: () -> Unit
) {
    androidx.compose.foundation.lazy.LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = Spacing.xxl)
    ) {
        if (data.isOffline) {
            item { OfflineBanner() }
        }

        item {
            Box(modifier = Modifier.padding(horizontal = Spacing.lg, vertical = Spacing.md)) {
                AppSearchBarClickable(onClick = onSearchClick)
            }
        }

        if (data.progress != null && data.progress.testsAttempted > 0) {
            item {
                ProgressSummaryCard(
                    testsAttempted = data.progress.testsAttempted,
                    averageScore = data.progress.averageScore,
                    modifier = Modifier.padding(horizontal = Spacing.lg, vertical = Spacing.sm)
                )
            }
        }

        item {
            SectionHeader(
                "Featured Jobs",
                actionLabel = "See all",
                onAction = onSeeAllJobs,
                modifier = Modifier.padding(horizontal = Spacing.lg, vertical = Spacing.sm)
            )
        }
        if (data.featuredJobs.isEmpty()) {
            item {
                EmptyRow(icon = Icons.Outlined.WorkOff, text = "No featured jobs right now")
            }
        } else {
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = Spacing.lg),
                    horizontalArrangement = Arrangement.spacedBy(Spacing.md)
                ) {
                    items(data.featuredJobs, key = { it.id }) { job ->
                        Box(modifier = Modifier.width(280.dp)) {
                            JobCard(job = job, onClick = { onJobClick(job.id) })
                        }
                    }
                }
            }
        }

        if (data.upcomingDeadlines.isNotEmpty()) {
            item {
                SectionHeader("Closing Soon", modifier = Modifier.padding(horizontal = Spacing.lg, vertical = Spacing.sm))
            }
            items(data.upcomingDeadlines, key = { "deadline_${it.id}" }) { job ->
                Box(modifier = Modifier.padding(horizontal = Spacing.lg)) {
                    JobCardCompact(job = job, onClick = { onJobClick(job.id) })
                }
            }
        }

        item {
            SectionHeader(
                "Popular Mock Tests",
                actionLabel = "See all",
                onAction = onSeeAllTests,
                modifier = Modifier.padding(horizontal = Spacing.lg, vertical = Spacing.sm)
            )
        }
        item {
            LazyRow(
                contentPadding = PaddingValues(horizontal = Spacing.lg),
                horizontalArrangement = Arrangement.spacedBy(Spacing.md)
            ) {
                items(data.popularTests, key = { it.id }) { test ->
                    Box(modifier = Modifier.width(240.dp)) {
                        TestBlueprintCard(blueprint = test, onClick = { onTestClick(test.id) })
                    }
                }
            }
        }

        if (data.recentAttempts.isNotEmpty()) {
            item {
                SectionHeader("Recently Attempted", modifier = Modifier.padding(horizontal = Spacing.lg, vertical = Spacing.sm))
            }
            items(data.recentAttempts, key = { it.id }) { attempt ->
                Box(modifier = Modifier.padding(horizontal = Spacing.lg, vertical = Spacing.xxs)) {
                    RecentAttemptRow(title = attempt.title, percentage = attempt.percentage, correct = attempt.correctCount, total = attempt.totalQuestions)
                }
            }
        }
    }
}

@Composable
private fun AppSearchBarClickable(onClick: () -> Unit) {
    OutlinedCard(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.padding(Spacing.md),
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
        ) {
            Icon(androidx.compose.material.icons.Icons.Filled.Search, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.width(Spacing.sm))
            Text("Search jobs, organizations…", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun ProgressSummaryCard(testsAttempted: Int, averageScore: Float, modifier: Modifier = Modifier) {
    ElevatedCard(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.padding(Spacing.lg),
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.TrendingUp, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(Spacing.md))
            Column(modifier = Modifier.weight(1f)) {
                Text("Your progress", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text(
                    "$testsAttempted tests attempted • ${"%.1f".format(averageScore)}% average",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun RecentAttemptRow(title: String, percentage: Float, correct: Int, total: Int) {
    OutlinedCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.padding(Spacing.md),
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall, maxLines = 1)
                Text("$correct / $total correct", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(
                "${"%.0f".format(percentage)}%",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = if (percentage >= 60f) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
            )
        }
    }
}

@Composable
private fun EmptyRow(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = Spacing.lg, vertical = Spacing.md),
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(Spacing.sm))
        Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
