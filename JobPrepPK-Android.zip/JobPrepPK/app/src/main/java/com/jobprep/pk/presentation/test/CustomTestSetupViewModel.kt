package com.jobprep.pk.presentation.test

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jobprep.pk.domain.model.Subject
import com.jobprep.pk.domain.repository.McqRepository
import com.jobprep.pk.presentation.common.UiState
import com.jobprep.pk.util.Constants
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

data class CustomTestFormState(
    val selectedSubjectIds: Set<String> = emptySet(),
    val questionCount: Int = 20,
    val durationMinutes: Int = Constants.DEFAULT_MOCK_DURATION_MIN
)

@HiltViewModel
class CustomTestSetupViewModel @Inject constructor(
    mcqRepository: McqRepository
) : ViewModel() {

    val subjectsState: StateFlow<UiState<List<Subject>>> = mcqRepository.observeSubjects()
        .map { subjects -> if (subjects.isEmpty()) UiState.Empty else UiState.Success(subjects) }
        .catch { emit(UiState.Error(it.message ?: "Failed to load subjects")) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UiState.Loading)

    private val _formState = MutableStateFlow(CustomTestFormState())
    val formState: StateFlow<CustomTestFormState> = _formState

    fun toggleSubject(id: String) {
        val current = _formState.value.selectedSubjectIds
        _formState.value = _formState.value.copy(
            selectedSubjectIds = if (id in current) current - id else current + id
        )
    }

    fun setQuestionCount(count: Int) {
        _formState.value = _formState.value.copy(
            questionCount = count.coerceIn(Constants.MIN_MOCK_QUESTIONS, Constants.MAX_MOCK_QUESTIONS)
        )
    }

    fun setDuration(minutes: Int) {
        _formState.value = _formState.value.copy(durationMinutes = minutes.coerceIn(5, 180))
    }
}
