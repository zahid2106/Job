package com.jobprep.pk.domain.repository

import com.jobprep.pk.domain.model.AppNotification
import kotlinx.coroutines.flow.Flow

interface NotificationRepository {
    fun observeAll(): Flow<List<AppNotification>>
    fun observeUnreadCount(): Flow<Int>
    suspend fun markRead(id: String)
    suspend fun markAllRead()
    suspend fun send(notification: AppNotification)
    suspend fun delete(id: String)
}
