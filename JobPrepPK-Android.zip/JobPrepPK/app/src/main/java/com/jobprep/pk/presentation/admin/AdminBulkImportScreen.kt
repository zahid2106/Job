package com.jobprep.pk.presentation.admin

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.jobprep.pk.presentation.components.AppTextField
import com.jobprep.pk.presentation.components.AppTopBar
import com.jobprep.pk.presentation.components.PrimaryButton
import com.jobprep.pk.presentation.components.SecondaryButton
import com.jobprep.pk.presentation.theme.Spacing

@Composable
fun AdminBulkImportScreen(
    onBack: () -> Unit,
    viewModel: AdminBulkImportViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsState()

    Scaffold(topBar = { AppTopBar(title = "Bulk Import MCQs", onBack = onBack) }) { padding ->
        LazyColumn(modifier = Modifier.padding(padding), contentPadding = PaddingValues(Spacing.lg)) {
            item {
                Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = MaterialTheme.shapes.medium) {
                    Column(modifier = Modifier.padding(Spacing.md)) {
                        Text("Format: one question per line", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(Spacing.xs))
                        Text(
                            "subjectId | question | option A | option B | option C | option D | correct letter | explanation",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(Spacing.xs))
                        Text(
                            "Example:\nsubj_gk | Capital of Pakistan? | Karachi | Islamabad | Lahore | Quetta | B | Islamabad has been the capital since 1967.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Spacer(Modifier.height(Spacing.lg))
            }

            item {
                AppTextField(
                    value = state.rawText,
                    onValueChange = viewModel::onTextChange,
                    label = "Paste questions here",
                    minLines = 6,
                    singleLine = false
                )
                Spacer(Modifier.height(Spacing.md))
                Row(horizontalArrangement = Arrangement.spacedBy(Spacing.sm)) {
                    SecondaryButton(text = "Validate", onClick = viewModel::parse, modifier = Modifier.weight(1f), enabled = state.rawText.isNotBlank())
                    PrimaryButton(
                        text = "Import Valid Rows (${state.validCount})",
                        onClick = viewModel::importValidRows,
                        loading = state.isImporting,
                        enabled = state.validCount > 0,
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(Modifier.height(Spacing.lg))
            }

            if (state.hasImported) {
                item {
                    Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = MaterialTheme.shapes.medium) {
                        Text(
                            "Successfully imported ${state.importedCount} questions.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.padding(Spacing.md)
                        )
                    }
                    Spacer(Modifier.height(Spacing.lg))
                }
            }

            if (state.results.isNotEmpty()) {
                item {
                    Text(
                        "${state.validCount} valid • ${state.invalidCount} with errors",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.height(Spacing.sm))
                }
            }
            items(state.results) { result ->
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = Spacing.xs),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        if (result.mcq != null) Icons.Filled.CheckCircle else Icons.Filled.Error,
                        contentDescription = null,
                        tint = if (result.mcq != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                    Spacer(Modifier.width(Spacing.sm))
                    Column {
                        Text("Line ${result.lineNumber}", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                        if (result.errors.isNotEmpty()) {
                            result.errors.forEach { err ->
                                Text(err, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                            }
                        } else {
                            Text(
                                result.mcq?.questionText.orEmpty(),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(Spacing.xxxl)) }
        }
    }
}
