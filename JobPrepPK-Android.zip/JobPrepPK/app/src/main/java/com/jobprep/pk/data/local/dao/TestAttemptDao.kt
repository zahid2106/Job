package com.jobprep.pk.data.local.dao

import androidx.room.*
import com.jobprep.pk.data.local.entity.TestAnswerEntity
import com.jobprep.pk.data.local.entity.TestAttemptEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TestAttemptDao {
    @Insert
    suspend fun insertAttempt(attempt: TestAttemptEntity)

    @Insert
    suspend fun insertAnswers(answers: List<TestAnswerEntity>)

    @Query("SELECT * FROM test_attempts WHERE userId = :userId ORDER BY submittedAt DESC LIMIT :limit")
    fun observeHistory(userId: String, limit: Int): Flow<List<TestAttemptEntity>>

    @Query("SELECT * FROM test_attempts WHERE userId = :userId ORDER BY submittedAt DESC LIMIT :limit")
    fun observeRecent(userId: String, limit: Int): Flow<List<TestAttemptEntity>>

    @Query("SELECT * FROM test_attempts WHERE id = :id LIMIT 1")
    suspend fun getAttempt(id: String): TestAttemptEntity?

    @Query("SELECT * FROM test_answers WHERE attemptId = :attemptId ORDER BY orderIndex ASC")
    suspend fun getAnswers(attemptId: String): List<TestAnswerEntity>

    @Query("SELECT * FROM test_attempts WHERE userId = :userId")
    suspend fun getAllForUser(userId: String): List<TestAttemptEntity>
}
