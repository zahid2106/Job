package com.jobprep.pk.presentation.mcq

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jobprep.pk.domain.model.Subject
import com.jobprep.pk.domain.repository.McqRepository
import com.jobprep.pk.presentation.common.UiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

@HiltViewModel
class SubjectListViewModel @Inject constructor(
    mcqRepository: McqRepository
) : ViewModel() {

    val uiState: StateFlow<UiState<List<Subject>>> = mcqRepository.observeSubjects()
        .map { subjects -> if (subjects.isEmpty()) UiState.Empty else UiState.Success(subjects) }
        .catch { emit(UiState.Error(it.message ?: "Failed to load subjects")) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UiState.Loading)
}
