package com.jobprep.pk.presentation.jobs

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.jobprep.pk.domain.model.Job
import com.jobprep.pk.presentation.common.UiState
import com.jobprep.pk.presentation.components.*
import com.jobprep.pk.presentation.theme.Spacing
import com.jobprep.pk.util.toFormattedDate

@Composable
fun JobDetailScreen(
    onBack: () -> Unit,
    viewModel: JobDetailViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()
    val context = LocalContext.current

    Scaffold(topBar = { AppTopBar(title = "Job Details", onBack = onBack) }) { padding ->
        when (val s = state) {
            is UiState.Loading -> LoadingState(modifier = Modifier.padding(padding))
            is UiState.Error -> ErrorState(modifier = Modifier.padding(padding), message = s.message, onRetry = viewModel::load)
            is UiState.Empty -> EmptyState(modifier = Modifier.padding(padding), title = "Not found", message = "This job could not be found.")
            is UiState.Success -> JobDetailContent(
                job = s.data,
                modifier = Modifier.padding(padding),
                onApply = {
                    runCatching {
                        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(s.data.applyLink)))
                    }
                }
            )
        }
    }
}

@Composable
private fun JobDetailContent(job: Job, modifier: Modifier = Modifier, onApply: () -> Unit) {
    Column(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(Spacing.lg)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                OrgTag(job.organization.displayName)
                Spacer(Modifier.width(Spacing.sm))
                StatusBadge(job.status())
            }
            Spacer(Modifier.height(Spacing.md))
            Text(job.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(Spacing.xs))
            Text(
                "Advertisement No. ${job.advertisementNumber}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(Modifier.height(Spacing.xl))
            InfoGrid(job)

            Spacer(Modifier.height(Spacing.xl))
            Text("Details", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(Spacing.sm))
            Text(job.details, style = MaterialTheme.typography.bodyMedium)

            Spacer(Modifier.height(Spacing.xxl))
        }

        Surface(shadowElevation = 4.dp) {
            Row(
                modifier = Modifier.padding(Spacing.lg),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Deadline", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(job.deadline.toFormattedDate(), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                }
                PrimaryButton(
                    text = "Apply Now",
                    onClick = onApply,
                    enabled = job.status() != com.jobprep.pk.domain.model.JobStatus.CLOSED
                )
            }
        }
    }
}

@Composable
private fun InfoGrid(job: Job) {
    val rows = listOf(
        Icons.Filled.WorkOutline to ("BPS / Grade" to job.bpsOrGrade),
        Icons.Filled.School to ("Qualification" to job.qualification),
        Icons.Filled.Cake to ("Age Limit" to "${job.ageLimitMin} - ${job.ageLimitMax} years"),
        Icons.Filled.People to ("Vacancies" to job.vacancies.toString()),
        Icons.Filled.WorkHistory to ("Experience" to job.experienceRequired),
        Icons.Filled.LocationOn to ("Province" to job.province),
        Icons.Filled.Event to ("Posted On" to job.postedDate.toFormattedDate())
    )
    Column(verticalArrangement = Arrangement.spacedBy(Spacing.md)) {
        rows.forEach { (icon, pair) ->
            Row(verticalAlignment = Alignment.Top) {
                Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp).padding(top = 2.dp), tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(Spacing.md))
                Column {
                    Text(pair.first, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(pair.second, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}
