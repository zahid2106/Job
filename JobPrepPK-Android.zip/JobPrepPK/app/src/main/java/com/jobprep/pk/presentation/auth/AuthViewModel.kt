package com.jobprep.pk.presentation.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jobprep.pk.domain.model.User
import com.jobprep.pk.domain.repository.AuthResult
import com.jobprep.pk.domain.repository.UserRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class AuthFormState(
    val name: String = "",
    val email: String = "",
    val password: String = "",
    val isSubmitting: Boolean = false,
    val errorMessage: String? = null
)

@HiltViewModel
class AuthViewModel @Inject constructor(
    private val userRepository: UserRepository
) : ViewModel() {

    val currentUser: StateFlow<User?> = userRepository.currentUser
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _formState = MutableStateFlow(AuthFormState())
    val formState: StateFlow<AuthFormState> = _formState

    private val _authCompleted = MutableStateFlow(false)
    val authCompleted: StateFlow<Boolean> = _authCompleted

    fun onNameChange(value: String) { _formState.value = _formState.value.copy(name = value, errorMessage = null) }
    fun onEmailChange(value: String) { _formState.value = _formState.value.copy(email = value, errorMessage = null) }
    fun onPasswordChange(value: String) { _formState.value = _formState.value.copy(password = value, errorMessage = null) }

    fun login() {
        val state = _formState.value
        if (state.email.isBlank() || state.password.isBlank()) {
            _formState.value = state.copy(errorMessage = "Please enter both email and password.")
            return
        }
        viewModelScope.launch {
            _formState.value = state.copy(isSubmitting = true, errorMessage = null)
            when (val result = userRepository.login(state.email, state.password)) {
                is AuthResult.Success -> {
                    _formState.value = AuthFormState()
                    _authCompleted.value = true
                }
                is AuthResult.Error -> {
                    _formState.value = _formState.value.copy(isSubmitting = false, errorMessage = result.message)
                }
            }
        }
    }

    fun register() {
        val state = _formState.value
        if (state.name.isBlank() || state.email.isBlank() || state.password.isBlank()) {
            _formState.value = state.copy(errorMessage = "Please fill in all fields.")
            return
        }
        viewModelScope.launch {
            _formState.value = state.copy(isSubmitting = true, errorMessage = null)
            when (val result = userRepository.register(state.name, state.email, state.password)) {
                is AuthResult.Success -> {
                    _formState.value = AuthFormState()
                    _authCompleted.value = true
                }
                is AuthResult.Error -> {
                    _formState.value = _formState.value.copy(isSubmitting = false, errorMessage = result.message)
                }
            }
        }
    }

    fun logout() {
        viewModelScope.launch { userRepository.logout() }
    }

    fun consumeAuthCompleted() { _authCompleted.value = false }
    fun clearError() { _formState.value = _formState.value.copy(errorMessage = null) }
}
