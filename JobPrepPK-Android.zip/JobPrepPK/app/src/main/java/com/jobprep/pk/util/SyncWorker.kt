package com.jobprep.pk.util

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.jobprep.pk.domain.repository.JobRepository
import com.jobprep.pk.domain.repository.McqRepository
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject

/**
 * Periodically pulls fresh content (jobs, MCQs) from the remote content API and
 * upserts it into Room. This is what allows the backend team to publish new
 * jobs, questions, tests and notifications without shipping a new APK/AAB —
 * the Android UI always reads from Room, never directly from the network.
 */
@HiltWorker
class SyncWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val jobRepository: JobRepository,
    private val mcqRepository: McqRepository
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val jobsResult = jobRepository.refreshFromRemote()
        val mcqResult = mcqRepository.refreshFromRemote()
        return if (jobsResult.isSuccess && mcqResult.isSuccess) Result.success() else Result.retry()
    }
}
