package com.jobprep.pk.presentation.components

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.jobprep.pk.domain.model.JobStatus
import com.jobprep.pk.presentation.theme.extendedColors

@Composable
fun StatusBadge(status: JobStatus, modifier: Modifier = Modifier) {
    val (color, label) = when (status) {
        JobStatus.OPEN -> MaterialTheme.extendedColors.statusOpen to "Open"
        JobStatus.CLOSING_SOON -> MaterialTheme.extendedColors.statusClosingSoon to "Closing Soon"
        JobStatus.CLOSED -> MaterialTheme.extendedColors.statusClosed to "Closed"
    }
    Chip(text = label, color = color, modifier = modifier)
}

@Composable
fun Chip(text: String, color: Color, modifier: Modifier = Modifier) {
    androidx.compose.material3.Surface(
        modifier = modifier,
        color = color.copy(alpha = 0.12f),
        shape = MaterialTheme.shapes.extraSmall
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = color,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun OrgTag(text: String, modifier: Modifier = Modifier) {
    androidx.compose.material3.Surface(
        modifier = modifier,
        color = MaterialTheme.colorScheme.primaryContainer,
        shape = MaterialTheme.shapes.extraSmall
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onPrimaryContainer,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}
