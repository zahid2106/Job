package com.jobprep.pk.presentation.test

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jobprep.pk.domain.model.TestResult
import com.jobprep.pk.domain.repository.TestRepository
import com.jobprep.pk.presentation.common.UiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ResultViewModel @Inject constructor(
    private val testRepository: TestRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val attemptId: String = checkNotNull(savedStateHandle["attemptId"])

    private val _uiState = MutableStateFlow<UiState<TestResult>>(UiState.Loading)
    val uiState: StateFlow<UiState<TestResult>> = _uiState

    init {
        viewModelScope.launch {
            val result = testRepository.getResult(attemptId)
            _uiState.value = if (result == null) UiState.Error("Result not found.") else UiState.Success(result)
        }
    }
}
