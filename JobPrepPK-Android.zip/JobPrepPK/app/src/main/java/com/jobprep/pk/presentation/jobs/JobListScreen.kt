package com.jobprep.pk.presentation.jobs

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.outlined.SearchOff
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import com.jobprep.pk.domain.model.OrgType
import com.jobprep.pk.presentation.common.UiState
import com.jobprep.pk.presentation.components.*
import com.jobprep.pk.presentation.theme.Spacing

@Composable
fun JobListScreen(
    onJobClick: (String) -> Unit,
    viewModel: JobsViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()
    val filter by viewModel.filterState.collectAsState()

    Scaffold(topBar = { AppTopBar(title = "Job Announcements") }) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            Box(modifier = Modifier.padding(horizontal = Spacing.lg, vertical = Spacing.sm)) {
                AppSearchBar(query = filter.query, onQueryChange = viewModel::onQueryChange, placeholder = "Search organization or title…")
            }

            LazyRow(
                contentPadding = PaddingValues(horizontal = Spacing.lg),
                horizontalArrangement = Arrangement.spacedBy(Spacing.xs),
                modifier = Modifier.padding(bottom = Spacing.sm)
            ) {
                items(OrgType.entries.toList()) { org ->
                    FilterChip(
                        selected = org in filter.selectedOrgs,
                        onClick = { viewModel.toggleOrg(org) },
                        label = { Text(org.displayName) }
                    )
                }
            }

            when (val s = state) {
                is UiState.Loading -> LoadingState()
                is UiState.Error -> ErrorState(message = s.message)
                is UiState.Empty -> EmptyState(
                    icon = androidx.compose.material.icons.Icons.Outlined.SearchOff,
                    title = "No jobs found",
                    message = "Try a different search term or clear your filters.",
                    actionLabel = if (filter.query.isNotEmpty() || filter.selectedOrgs.isNotEmpty()) "Clear filters" else null,
                    onAction = viewModel::clearFilters
                )
                is UiState.Success -> LazyColumn(
                    contentPadding = PaddingValues(horizontal = Spacing.lg, vertical = Spacing.sm),
                    verticalArrangement = Arrangement.spacedBy(Spacing.md)
                ) {
                    items(s.data, key = { it.id }) { job ->
                        JobCard(job = job, onClick = { onJobClick(job.id) })
                    }
                    item { Spacer(Modifier.height(Spacing.xxl)) }
                }
            }
        }
    }
}
