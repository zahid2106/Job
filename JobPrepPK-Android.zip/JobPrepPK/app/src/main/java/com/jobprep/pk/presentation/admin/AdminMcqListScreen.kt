package com.jobprep.pk.presentation.admin

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.jobprep.pk.domain.model.Mcq
import com.jobprep.pk.presentation.common.UiState
import com.jobprep.pk.presentation.components.*
import com.jobprep.pk.presentation.theme.Spacing

@Composable
fun AdminMcqListScreen(
    onBack: () -> Unit,
    onAddMcq: (subjectId: String) -> Unit,
    onEditMcq: (subjectId: String, mcqId: String) -> Unit,
    viewModel: AdminMcqListViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()
    val subjectName by viewModel.subjectName.collectAsState()
    var pendingDelete by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) { viewModel.load() }

    Scaffold(
        topBar = { AppTopBar(title = subjectName, onBack = onBack) },
        floatingActionButton = {
            FloatingActionButton(onClick = { onAddMcq(viewModel.subjectId) }) { Icon(Icons.Filled.Add, contentDescription = "Add question") }
        }
    ) { padding ->
        when (val s = state) {
            is UiState.Loading -> LoadingState(modifier = Modifier.padding(padding))
            is UiState.Error -> ErrorState(modifier = Modifier.padding(padding), message = s.message)
            is UiState.Empty -> EmptyState(
                modifier = Modifier.padding(padding), title = "No questions yet",
                message = "Add your first question for this subject.", actionLabel = "Add Question",
                onAction = { onAddMcq(viewModel.subjectId) }
            )
            is UiState.Success -> LazyColumn(
                modifier = Modifier.padding(padding),
                contentPadding = PaddingValues(Spacing.lg),
                verticalArrangement = Arrangement.spacedBy(Spacing.sm)
            ) {
                items(s.data, key = { it.id }) { mcq ->
                    AdminMcqRow(
                        mcq = mcq,
                        onClick = { onEditMcq(viewModel.subjectId, mcq.id) },
                        onDelete = { pendingDelete = mcq.id }
                    )
                }
                item { Spacer(Modifier.height(Spacing.xxxl)) }
            }
        }
    }

    pendingDelete?.let { id ->
        ConfirmDialog(
            title = "Delete this question?",
            message = "This will permanently remove the question from the MCQ bank.",
            confirmLabel = "Delete",
            isDestructive = true,
            onConfirm = { viewModel.deleteMcq(id); pendingDelete = null },
            onDismiss = { pendingDelete = null }
        )
    }
}

@Composable
private fun AdminMcqRow(mcq: Mcq, onClick: () -> Unit, onDelete: () -> Unit) {
    OutlinedCard(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.padding(Spacing.md), verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(mcq.questionText, style = MaterialTheme.typography.bodyMedium, maxLines = 2)
                Spacer(Modifier.height(4.dp))
                Chip("Correct: ${mcq.correctOption.name}", MaterialTheme.colorScheme.primary)
            }
            IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error) }
        }
    }
}
