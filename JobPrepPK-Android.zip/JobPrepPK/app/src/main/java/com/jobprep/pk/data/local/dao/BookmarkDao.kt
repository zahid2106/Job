package com.jobprep.pk.data.local.dao

import androidx.room.*
import com.jobprep.pk.data.local.entity.BookmarkEntity
import com.jobprep.pk.data.local.entity.McqEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface BookmarkDao {
    @Query("""
        SELECT mcqs.* FROM mcqs
        INNER JOIN bookmarks ON mcqs.id = bookmarks.mcqId
        WHERE bookmarks.userId = :userId
        ORDER BY bookmarks.createdAt DESC
    """)
    fun observeBookmarkedMcqs(userId: String): Flow<List<McqEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM bookmarks WHERE userId = :userId AND mcqId = :mcqId)")
    suspend fun isBookmarked(userId: String, mcqId: String): Boolean

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(bookmark: BookmarkEntity)

    @Query("DELETE FROM bookmarks WHERE userId = :userId AND mcqId = :mcqId")
    suspend fun delete(userId: String, mcqId: String)

    @Query("SELECT COUNT(*) FROM bookmarks WHERE userId = :userId")
    suspend fun countForUser(userId: String): Int
}
