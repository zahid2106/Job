package com.jobprep.pk.presentation.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jobprep.pk.domain.model.TestAttemptSummary
import com.jobprep.pk.domain.repository.TestRepository
import com.jobprep.pk.domain.repository.UserRepository
import com.jobprep.pk.presentation.common.UiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import javax.inject.Inject

@HiltViewModel
class TestHistoryViewModel @Inject constructor(
    private val testRepository: TestRepository,
    userRepository: UserRepository
) : ViewModel() {

    val uiState: StateFlow<UiState<List<TestAttemptSummary>>> = userRepository.currentUser
        .flatMapLatest { user ->
            if (user == null) flowOf(UiState.Empty)
            else testRepository.observeHistory(user.id).map { list -> if (list.isEmpty()) UiState.Empty else UiState.Success(list) }
        }
        .catch { emit(UiState.Error(it.message ?: "Failed to load history")) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UiState.Loading)
}
