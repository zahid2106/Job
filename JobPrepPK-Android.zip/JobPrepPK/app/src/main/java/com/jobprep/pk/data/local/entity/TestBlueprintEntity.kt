package com.jobprep.pk.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "test_blueprints")
data class TestBlueprintEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val subjectIds: String, // comma separated subject ids
    val jobCategory: String?,
    val questionCount: Int,
    val durationMinutes: Int,
    val attemptsCount: Int,
    val isPopular: Boolean
)
