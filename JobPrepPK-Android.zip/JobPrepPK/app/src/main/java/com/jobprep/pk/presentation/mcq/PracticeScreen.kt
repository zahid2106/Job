package com.jobprep.pk.presentation.mcq

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.jobprep.pk.domain.model.Mcq
import com.jobprep.pk.domain.model.McqOption
import com.jobprep.pk.domain.model.OptionKey
import com.jobprep.pk.presentation.common.UiState
import com.jobprep.pk.presentation.components.*
import com.jobprep.pk.presentation.theme.Spacing

@Composable
fun PracticeScreen(
    onBack: () -> Unit,
    viewModel: PracticeViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()
    var showReportDialog by remember { mutableStateOf(false) }

    Scaffold(topBar = { AppTopBar(title = "Practice Mode", onBack = onBack) }) { padding ->
        when (val s = state) {
            is UiState.Loading -> LoadingState(modifier = Modifier.padding(padding))
            is UiState.Error -> ErrorState(modifier = Modifier.padding(padding), message = s.message, onRetry = viewModel::loadSession)
            is UiState.Empty -> EmptyState(
                modifier = Modifier.padding(padding),
                title = "No questions available",
                message = "There are no MCQs for this subject yet."
            )
            is UiState.Success -> {
                val session = s.data
                if (session.isSessionComplete) {
                    SessionCompleteView(
                        modifier = Modifier.padding(padding),
                        correct = session.correctCount,
                        attempted = session.attemptedCount,
                        onRestart = viewModel::restartSession,
                        onExit = onBack
                    )
                } else {
                    session.currentQuestion?.let { question ->
                        PracticeQuestionContent(
                            modifier = Modifier.padding(padding),
                            question = question,
                            session = session,
                            onSelectOption = viewModel::selectOption,
                            onCheck = viewModel::checkAnswer,
                            onNext = viewModel::nextQuestion,
                            onToggleBookmark = viewModel::toggleBookmark,
                            onReportClick = { showReportDialog = true }
                        )
                    }
                }

                if (showReportDialog) {
                    ReportQuestionDialog(
                        onDismiss = { showReportDialog = false },
                        onSubmit = { reason ->
                            viewModel.reportQuestion(reason)
                            showReportDialog = false
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun PracticeQuestionContent(
    modifier: Modifier = Modifier,
    question: Mcq,
    session: PracticeSessionState,
    onSelectOption: (OptionKey) -> Unit,
    onCheck: () -> Unit,
    onNext: () -> Unit,
    onToggleBookmark: () -> Unit,
    onReportClick: () -> Unit
) {
    Column(modifier = modifier.fillMaxSize()) {
        LinearProgressIndicator(progress = { session.progress }, modifier = Modifier.fillMaxWidth())

        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = Spacing.lg, vertical = Spacing.sm),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Question ${session.currentIndex + 1} of ${session.questions.size}",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.weight(1f))
            Chip(question.subjectName, MaterialTheme.colorScheme.primary)
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = Spacing.lg)
                .verticalScroll(rememberScrollState())
        ) {
            Row(verticalAlignment = Alignment.Top, modifier = Modifier.fillMaxWidth()) {
                Text(
                    question.questionText,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onToggleBookmark) {
                    Icon(
                        if (question.id in session.bookmarkedIds) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder,
                        contentDescription = "Bookmark",
                        tint = if (question.id in session.bookmarkedIds) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(Modifier.height(Spacing.lg))

            question.options.forEach { option ->
                OptionRow(
                    option = option,
                    isSelected = session.selectedOption == option.key,
                    isChecked = session.isChecked,
                    isCorrectAnswer = option.key == question.correctOption,
                    onClick = { onSelectOption(option.key) }
                )
                Spacer(Modifier.height(Spacing.sm))
            }

            if (session.isChecked) {
                Spacer(Modifier.height(Spacing.md))
                ExplanationCard(isCorrect = session.selectedOption == question.correctOption, explanation = question.explanation)
            }

            Spacer(Modifier.height(Spacing.xl))
            TextActionButton(text = "Report an issue with this question", onClick = onReportClick)
            if (session.reportSubmittedFor == question.id) {
                Text(
                    "Thanks — this question has been flagged for review.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            Spacer(Modifier.height(Spacing.xxl))
        }

        Surface(shadowElevation = 4.dp) {
            Box(modifier = Modifier.padding(Spacing.lg)) {
                if (!session.isChecked) {
                    PrimaryButton(
                        text = "Check Answer",
                        onClick = onCheck,
                        enabled = session.selectedOption != null,
                        modifier = Modifier.fillMaxWidth()
                    )
                } else {
                    PrimaryButton(
                        text = if (session.currentIndex + 1 == session.questions.size) "Finish" else "Next Question",
                        onClick = onNext,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}

@Composable
private fun OptionRow(
    option: McqOption,
    isSelected: Boolean,
    isChecked: Boolean,
    isCorrectAnswer: Boolean,
    onClick: () -> Unit
) {
    val borderColor = when {
        isChecked && isCorrectAnswer -> MaterialTheme.colorScheme.primary
        isChecked && isSelected && !isCorrectAnswer -> MaterialTheme.colorScheme.error
        isSelected -> MaterialTheme.colorScheme.primary
        else -> MaterialTheme.colorScheme.outline
    }
    val backgroundColor = when {
        isChecked && isCorrectAnswer -> MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
        isChecked && isSelected && !isCorrectAnswer -> MaterialTheme.colorScheme.error.copy(alpha = 0.08f)
        else -> Color.Transparent
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .border(1.dp, borderColor, RoundedCornerShape(10.dp))
            .background(backgroundColor)
            .clickable(enabled = !isChecked, onClick = onClick)
            .padding(Spacing.md),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            option.key.name, style = MaterialTheme.typography.labelLarge,
            color = borderColor, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.width(24.dp)
        )
        Spacer(Modifier.width(Spacing.sm))
        Text(option.text, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        if (isChecked && isCorrectAnswer) {
            Icon(Icons.Filled.CheckCircle, contentDescription = "Correct", tint = MaterialTheme.colorScheme.primary)
        } else if (isChecked && isSelected && !isCorrectAnswer) {
            Icon(Icons.Filled.Cancel, contentDescription = "Incorrect", tint = MaterialTheme.colorScheme.error)
        }
    }
}

@Composable
private fun ExplanationCard(isCorrect: Boolean, explanation: String) {
    Surface(
        color = if (isCorrect) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(Spacing.md)) {
            Text(
                if (isCorrect) "Correct!" else "Not quite — here's why",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = if (isCorrect) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
            )
            Spacer(Modifier.height(4.dp))
            Text(explanation, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun SessionCompleteView(
    modifier: Modifier = Modifier,
    correct: Int,
    attempted: Int,
    onRestart: () -> Unit,
    onExit: () -> Unit
) {
    Column(
        modifier = modifier.fillMaxSize().padding(Spacing.xl),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Filled.EmojiEvents, contentDescription = null, modifier = Modifier.size(56.dp), tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(Spacing.lg))
        Text("Session complete!", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(Spacing.sm))
        Text(
            "You answered $correct out of $attempted correctly",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(Spacing.xl))
        PrimaryButton(text = "Practice Again", onClick = onRestart, modifier = Modifier.fillMaxWidth(0.8f))
        Spacer(Modifier.height(Spacing.sm))
        SecondaryButton(text = "Back to Subjects", onClick = onExit, modifier = Modifier.fillMaxWidth(0.8f))
    }
}

@Composable
private fun ReportQuestionDialog(onDismiss: () -> Unit, onSubmit: (String) -> Unit) {
    var reason by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Report this question") },
        text = {
            Column {
                Text("What's wrong with this question?", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(Spacing.sm))
                AppTextField(value = reason, onValueChange = { reason = it }, label = "Reason", minLines = 2, singleLine = false)
            }
        },
        confirmButton = {
            TextButton(onClick = { onSubmit(reason.ifBlank { "No reason provided" }) }) { Text("Submit") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
