package com.jobprep.pk

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.jobprep.pk.data.datastore.PreferencesManager
import com.jobprep.pk.domain.model.ThemeMode
import com.jobprep.pk.presentation.navigation.JobPrepNavHost
import com.jobprep.pk.presentation.theme.JobPrepTheme
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject lateinit var preferencesManager: PreferencesManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val themeMode by preferencesManager.themeMode.collectAsState(initial = ThemeMode.SYSTEM)

            JobPrepTheme(themeMode = themeMode) {
                JobPrepNavHost()
            }
        }
    }
}
