package com.jobprep.pk.domain.model

/** A pre-configured, "popular" mock test template shown on Home / Tests. */
data class TestBlueprint(
    val id: String,
    val title: String,
    val description: String,
    val subjectIds: List<String>,
    val jobCategory: OrgType?,
    val questionCount: Int,
    val durationMinutes: Int,
    val attemptsCount: Int,
    val isPopular: Boolean
)
