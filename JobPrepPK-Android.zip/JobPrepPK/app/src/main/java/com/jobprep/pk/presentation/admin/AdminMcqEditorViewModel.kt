package com.jobprep.pk.presentation.admin

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jobprep.pk.domain.model.Mcq
import com.jobprep.pk.domain.model.McqOption
import com.jobprep.pk.domain.model.OptionKey
import com.jobprep.pk.domain.model.QuestionDifficulty
import com.jobprep.pk.domain.repository.McqRepository
import com.jobprep.pk.domain.usecase.ValidateMcqUseCase
import com.jobprep.pk.presentation.navigation.Screen
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.util.UUID
import javax.inject.Inject

data class McqEditorFormState(
    val isNew: Boolean = true,
    val questionText: String = "",
    val optionA: String = "",
    val optionB: String = "",
    val optionC: String = "",
    val optionD: String = "",
    val correctOption: OptionKey = OptionKey.A,
    val explanation: String = "",
    val difficulty: QuestionDifficulty = QuestionDifficulty.MEDIUM,
    val isLoading: Boolean = true,
    val isSaving: Boolean = false,
    val errors: List<String> = emptyList(),
    val isSaved: Boolean = false
)

@HiltViewModel
class AdminMcqEditorViewModel @Inject constructor(
    private val mcqRepository: McqRepository,
    private val validateMcqUseCase: ValidateMcqUseCase,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val subjectId: String = checkNotNull(savedStateHandle["subjectId"])
    private val mcqId: String = checkNotNull(savedStateHandle["mcqId"])
    private val existingId: String? = mcqId.takeIf { it != Screen.AdminMcqEditor.NEW }

    private val _state = MutableStateFlow(McqEditorFormState(isNew = existingId == null))
    val state: StateFlow<McqEditorFormState> = _state

    init {
        viewModelScope.launch {
            if (existingId != null) {
                val existing = mcqRepository.getAllMcqsForSubject(subjectId).find { it.id == existingId }
                if (existing != null) {
                    val opt = existing.options.associateBy { it.key }
                    _state.value = _state.value.copy(
                        isNew = false,
                        questionText = existing.questionText,
                        optionA = opt[OptionKey.A]?.text.orEmpty(),
                        optionB = opt[OptionKey.B]?.text.orEmpty(),
                        optionC = opt[OptionKey.C]?.text.orEmpty(),
                        optionD = opt[OptionKey.D]?.text.orEmpty(),
                        correctOption = existing.correctOption,
                        explanation = existing.explanation,
                        difficulty = existing.difficulty,
                        isLoading = false
                    )
                } else {
                    _state.value = _state.value.copy(isLoading = false, errors = listOf("Question not found."))
                }
            } else {
                _state.value = _state.value.copy(isLoading = false)
            }
        }
    }

    fun update(transform: (McqEditorFormState) -> McqEditorFormState) {
        _state.value = transform(_state.value).copy(errors = emptyList(), isSaved = false)
    }

    fun save() {
        val form = _state.value
        val mcq = Mcq(
            id = existingId ?: "mcq_${UUID.randomUUID().toString().take(10)}",
            subjectId = subjectId,
            subjectName = "",
            jobCategory = null,
            questionText = form.questionText.trim(),
            options = listOf(
                McqOption(OptionKey.A, form.optionA.trim()),
                McqOption(OptionKey.B, form.optionB.trim()),
                McqOption(OptionKey.C, form.optionC.trim()),
                McqOption(OptionKey.D, form.optionD.trim())
            ),
            correctOption = form.correctOption,
            explanation = form.explanation.trim(),
            difficulty = form.difficulty
        )

        val validation = validateMcqUseCase(mcq)
        if (!validation.isValid) {
            _state.value = form.copy(errors = validation.errors)
            return
        }

        viewModelScope.launch {
            _state.value = form.copy(isSaving = true)
            mcqRepository.upsertMcq(mcq)
            _state.value = form.copy(isSaving = false, isSaved = true)
        }
    }
}
