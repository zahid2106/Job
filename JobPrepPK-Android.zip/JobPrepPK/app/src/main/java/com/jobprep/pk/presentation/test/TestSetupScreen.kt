package com.jobprep.pk.presentation.test

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.jobprep.pk.presentation.common.UiState
import com.jobprep.pk.presentation.components.*
import com.jobprep.pk.presentation.navigation.Screen
import com.jobprep.pk.presentation.theme.Spacing

@Composable
fun TestSetupScreen(
    onBack: () -> Unit,
    onStartTest: (route: String) -> Unit,
    viewModel: TestSetupViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()

    Scaffold(topBar = { AppTopBar(title = "Test Overview", onBack = onBack) }) { padding ->
        when (val s = state) {
            is UiState.Loading -> LoadingState(modifier = Modifier.padding(padding))
            is UiState.Error -> ErrorState(modifier = Modifier.padding(padding), message = s.message)
            is UiState.Empty -> EmptyState(modifier = Modifier.padding(padding), title = "Not found", message = "This test could not be found.")
            is UiState.Success -> {
                val blueprint = s.data
                Column(modifier = Modifier.fillMaxSize().padding(padding).padding(Spacing.lg)) {
                    Text(blueprint.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(Spacing.sm))
                    Text(blueprint.description, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)

                    Spacer(Modifier.height(Spacing.xl))
                    Row(horizontalArrangement = Arrangement.spacedBy(Spacing.lg)) {
                        StatTile(icon = Icons.Filled.HelpOutline, label = "Questions", value = blueprint.questionCount.toString())
                        StatTile(icon = Icons.Filled.Timer, label = "Duration", value = "${blueprint.durationMinutes} min")
                    }

                    Spacer(Modifier.height(Spacing.xl))
                    Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = MaterialTheme.shapes.medium) {
                        Column(modifier = Modifier.padding(Spacing.md)) {
                            Text("Instructions", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(Spacing.xs))
                            listOf(
                                "Once started, the timer cannot be paused.",
                                "You can mark questions for review and revisit them anytime before submitting.",
                                "The test auto-submits when time runs out.",
                                "Each question has exactly one correct answer."
                            ).forEach {
                                Text("• $it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }

                    Spacer(Modifier.weight(1f))
                    PrimaryButton(
                        text = "Start Test",
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            val route = Screen.TestTaking.createRoute(
                                mode = "MOCK",
                                blueprintId = blueprint.id,
                                subjectIds = blueprint.subjectIds.joinToString(","),
                                questionCount = blueprint.questionCount,
                                durationMinutes = blueprint.durationMinutes,
                                title = blueprint.title
                            )
                            onStartTest(route)
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun StatTile(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, value: String) {
    Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = MaterialTheme.shapes.medium, modifier = Modifier.weight(1f)) {
        Column(modifier = Modifier.padding(Spacing.md), horizontalAlignment = Alignment.Start) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(20.dp))
            Spacer(Modifier.height(4.dp))
            Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onPrimaryContainer)
            Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
        }
    }
}
