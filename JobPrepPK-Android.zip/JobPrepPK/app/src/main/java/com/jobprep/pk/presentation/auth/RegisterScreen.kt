package com.jobprep.pk.presentation.auth

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.jobprep.pk.presentation.components.AppTextField
import com.jobprep.pk.presentation.components.AppTopBar
import com.jobprep.pk.presentation.components.PrimaryButton
import com.jobprep.pk.presentation.theme.Spacing

@Composable
fun RegisterScreen(
    onRegisterSuccess: () -> Unit,
    onBack: () -> Unit,
    viewModel: AuthViewModel = hiltViewModel()
) {
    val formState by viewModel.formState.collectAsState()
    val authCompleted by viewModel.authCompleted.collectAsState()

    LaunchedEffect(authCompleted) {
        if (authCompleted) {
            viewModel.consumeAuthCompleted()
            onRegisterSuccess()
        }
    }

    Scaffold(topBar = { AppTopBar(title = "Create Account", onBack = onBack) }) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = Spacing.xl, vertical = Spacing.lg)
        ) {
            Text(
                "Join thousands preparing for FPSC, PPSC, NTS and other exams",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(Spacing.xl))

            AppTextField(value = formState.name, onValueChange = viewModel::onNameChange, label = "Full Name")
            Spacer(Modifier.height(Spacing.md))
            AppTextField(
                value = formState.email, onValueChange = viewModel::onEmailChange,
                label = "Email", keyboardType = KeyboardType.Email
            )
            Spacer(Modifier.height(Spacing.md))
            AppTextField(
                value = formState.password, onValueChange = viewModel::onPasswordChange,
                label = "Password", isPassword = true, keyboardType = KeyboardType.Password
            )
            Spacer(Modifier.height(4.dp))
            Text(
                "At least 6 characters, including a number",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (formState.errorMessage != null) {
                Spacer(Modifier.height(Spacing.sm))
                Text(formState.errorMessage!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }

            Spacer(Modifier.height(Spacing.xl))
            PrimaryButton(
                text = "Create Account",
                onClick = viewModel::register,
                loading = formState.isSubmitting,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(Spacing.lg))
        }
    }
}
