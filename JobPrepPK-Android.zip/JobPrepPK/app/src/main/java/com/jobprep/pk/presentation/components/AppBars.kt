package com.jobprep.pk.presentation.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.foundation.layout.RowScope
import androidx.compose.material3.*
import androidx.compose.runtime.Composable

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppTopBar(
    title: String,
    onBack: (() -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {},
) {
    TopAppBar(
        title = { Text(title) },
        navigationIcon = {
            if (onBack != null) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                }
            }
        },
        actions = actions
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeTopBar(
    userName: String,
    unreadNotifications: Int,
    onNotificationsClick: () -> Unit
) {
    TopAppBar(
        title = {
            Column {
                Text("Welcome back", style = MaterialTheme.typography.bodySmall)
                Text(userName, style = MaterialTheme.typography.titleMedium)
            }
        },
        actions = {
            BadgedBox(
                badge = {
                    if (unreadNotifications > 0) {
                        Badge { Text(if (unreadNotifications > 9) "9+" else unreadNotifications.toString()) }
                    }
                }
            ) {
                IconButton(onClick = onNotificationsClick) {
                    Icon(Icons.Filled.Notifications, contentDescription = "Notifications")
                }
            }
        }
    )
}
