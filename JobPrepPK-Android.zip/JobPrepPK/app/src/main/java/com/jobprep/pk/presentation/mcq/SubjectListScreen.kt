package com.jobprep.pk.presentation.mcq

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.hilt.navigation.compose.hiltViewModel
import com.jobprep.pk.presentation.common.UiState
import com.jobprep.pk.presentation.components.*
import com.jobprep.pk.presentation.theme.Spacing

@Composable
fun SubjectListScreen(
    onSubjectClick: (String) -> Unit,
    onBookmarksClick: () -> Unit,
    onRandomPracticeClick: () -> Unit,
    viewModel: SubjectListViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()

    Scaffold(topBar = { AppTopBar(title = "MCQ Bank") }) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = Spacing.lg, vertical = Spacing.md),
                horizontalArrangement = Arrangement.spacedBy(Spacing.md)
            ) {
                QuickActionCard(
                    icon = Icons.Filled.Shuffle, title = "Random Practice",
                    subtitle = "All subjects mixed", modifier = Modifier.weight(1f),
                    onClick = onRandomPracticeClick
                )
                QuickActionCard(
                    icon = Icons.Filled.Bookmark, title = "Bookmarked",
                    subtitle = "Saved questions", modifier = Modifier.weight(1f),
                    onClick = onBookmarksClick
                )
            }

            SectionHeader("Subjects", modifier = Modifier.padding(horizontal = Spacing.lg, vertical = Spacing.sm))

            when (val s = state) {
                is UiState.Loading -> LoadingState()
                is UiState.Error -> ErrorState(message = s.message)
                is UiState.Empty -> EmptyState(title = "No subjects available", message = "Please check back later.")
                is UiState.Success -> LazyColumn(
                    contentPadding = PaddingValues(horizontal = Spacing.lg, vertical = Spacing.sm),
                    verticalArrangement = Arrangement.spacedBy(Spacing.sm)
                ) {
                    items(s.data, key = { it.id }) { subject ->
                        SubjectCard(subject = subject, onClick = { onSubjectClick(subject.id) })
                    }
                    item { Spacer(Modifier.height(Spacing.xxl)) }
                }
            }
        }
    }
}

@Composable
private fun QuickActionCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    ElevatedCard(onClick = onClick, modifier = modifier) {
        Column(modifier = Modifier.padding(Spacing.md)) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(Spacing.sm))
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
