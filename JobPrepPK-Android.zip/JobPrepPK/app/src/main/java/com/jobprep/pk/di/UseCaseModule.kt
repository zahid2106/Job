package com.jobprep.pk.di

import com.jobprep.pk.domain.usecase.ScoreTestUseCase
import com.jobprep.pk.domain.usecase.ValidateMcqUseCase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object UseCaseModule {
    @Provides @Singleton
    fun provideScoreTestUseCase(): ScoreTestUseCase = ScoreTestUseCase()

    @Provides @Singleton
    fun provideValidateMcqUseCase(): ValidateMcqUseCase = ValidateMcqUseCase()
}
