package com.jobprep.pk.presentation.admin

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.hilt.navigation.compose.hiltViewModel
import com.jobprep.pk.domain.model.OrgType
import com.jobprep.pk.presentation.components.AppTextField
import com.jobprep.pk.presentation.components.AppTopBar
import com.jobprep.pk.presentation.components.PrimaryButton
import com.jobprep.pk.presentation.theme.Spacing

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminJobEditorScreen(
    onBack: () -> Unit,
    onSaved: () -> Unit,
    viewModel: AdminJobEditorViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsState()
    var orgMenuExpanded by remember { mutableStateOf(false) }

    LaunchedEffect(state.isSaved) { if (state.isSaved) onSaved() }

    Scaffold(topBar = { AppTopBar(title = if (state.isNew) "Add Job" else "Edit Job", onBack = onBack) }) { padding ->
        if (state.isLoading) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = androidx.compose.ui.Alignment.Center) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }

        Column(
            modifier = Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(Spacing.lg)
        ) {
            ExposedDropdownMenuBox(expanded = orgMenuExpanded, onExpandedChange = { orgMenuExpanded = it }) {
                OutlinedTextField(
                    value = state.organization.displayName,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Organization") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = orgMenuExpanded) },
                    modifier = Modifier.fillMaxWidth().menuAnchor()
                )
                ExposedDropdownMenu(expanded = orgMenuExpanded, onDismissRequest = { orgMenuExpanded = false }) {
                    OrgType.entries.forEach { org ->
                        DropdownMenuItem(
                            text = { Text(org.displayName) },
                            onClick = {
                                viewModel.update { it.copy(organization = org) }
                                orgMenuExpanded = false
                            }
                        )
                    }
                }
            }
            Spacer(Modifier.height(Spacing.md))

            AppTextField(value = state.title, onValueChange = { v -> viewModel.update { it.copy(title = v) } }, label = "Job Title")
            Spacer(Modifier.height(Spacing.md))
            Row(horizontalArrangement = Arrangement.spacedBy(Spacing.md)) {
                AppTextField(
                    value = state.bpsOrGrade, onValueChange = { v -> viewModel.update { it.copy(bpsOrGrade = v) } },
                    label = "BPS / Grade", modifier = Modifier.weight(1f)
                )
                AppTextField(
                    value = state.vacancies, onValueChange = { v -> viewModel.update { it.copy(vacancies = v) } },
                    label = "Vacancies", keyboardType = KeyboardType.Number, modifier = Modifier.weight(1f)
                )
            }
            Spacer(Modifier.height(Spacing.md))
            AppTextField(
                value = state.qualification, onValueChange = { v -> viewModel.update { it.copy(qualification = v) } },
                label = "Qualification", minLines = 2, singleLine = false
            )
            Spacer(Modifier.height(Spacing.md))
            Row(horizontalArrangement = Arrangement.spacedBy(Spacing.md)) {
                AppTextField(
                    value = state.ageLimitMin, onValueChange = { v -> viewModel.update { it.copy(ageLimitMin = v) } },
                    label = "Min Age", keyboardType = KeyboardType.Number, modifier = Modifier.weight(1f)
                )
                AppTextField(
                    value = state.ageLimitMax, onValueChange = { v -> viewModel.update { it.copy(ageLimitMax = v) } },
                    label = "Max Age", keyboardType = KeyboardType.Number, modifier = Modifier.weight(1f)
                )
            }
            Spacer(Modifier.height(Spacing.md))
            AppTextField(
                value = state.experienceRequired, onValueChange = { v -> viewModel.update { it.copy(experienceRequired = v) } },
                label = "Experience Required"
            )
            Spacer(Modifier.height(Spacing.md))
            AppTextField(value = state.province, onValueChange = { v -> viewModel.update { it.copy(province = v) } }, label = "Province / Region")
            Spacer(Modifier.height(Spacing.md))
            AppTextField(
                value = state.deadlineText, onValueChange = { v -> viewModel.update { it.copy(deadlineText = v) } },
                label = "Application Deadline (YYYY-MM-DD)", placeholder = "2026-12-31"
            )
            Spacer(Modifier.height(Spacing.md))
            AppTextField(
                value = state.advertisementNumber, onValueChange = { v -> viewModel.update { it.copy(advertisementNumber = v) } },
                label = "Advertisement Number"
            )
            Spacer(Modifier.height(Spacing.md))
            AppTextField(
                value = state.applyLink, onValueChange = { v -> viewModel.update { it.copy(applyLink = v) } },
                label = "Official Apply Link", keyboardType = KeyboardType.Uri
            )
            Spacer(Modifier.height(Spacing.md))
            AppTextField(
                value = state.details, onValueChange = { v -> viewModel.update { it.copy(details = v) } },
                label = "Details", minLines = 4, singleLine = false
            )
            Spacer(Modifier.height(Spacing.md))
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Checkbox(checked = state.isFeatured, onCheckedChange = { v -> viewModel.update { it.copy(isFeatured = v) } })
                Text("Show as featured on Home", style = MaterialTheme.typography.bodyMedium)
            }

            if (state.errors.isNotEmpty()) {
                Spacer(Modifier.height(Spacing.md))
                Surface(color = MaterialTheme.colorScheme.errorContainer, shape = MaterialTheme.shapes.small) {
                    Column(modifier = Modifier.padding(Spacing.md)) {
                        state.errors.forEach { error ->
                            Text("• $error", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onErrorContainer)
                        }
                    }
                }
            }

            Spacer(Modifier.height(Spacing.xl))
            PrimaryButton(text = "Save Job", onClick = viewModel::save, loading = state.isSaving, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(Spacing.xxl))
        }
    }
}
