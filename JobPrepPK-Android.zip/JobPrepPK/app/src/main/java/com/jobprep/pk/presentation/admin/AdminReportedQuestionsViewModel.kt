package com.jobprep.pk.presentation.admin

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jobprep.pk.domain.model.Mcq
import com.jobprep.pk.domain.repository.McqRepository
import com.jobprep.pk.presentation.common.UiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AdminReportedQuestionsViewModel @Inject constructor(
    private val mcqRepository: McqRepository
) : ViewModel() {

    val uiState: StateFlow<UiState<List<Mcq>>> = mcqRepository.observeReportedQuestions()
        .map { list -> if (list.isEmpty()) UiState.Empty else UiState.Success(list) }
        .catch { emit(UiState.Error(it.message ?: "Failed to load reported questions")) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UiState.Loading)

    fun dismiss(mcqId: String) {
        viewModelScope.launch { mcqRepository.dismissReports(mcqId) }
    }

    fun deleteQuestion(mcqId: String) {
        viewModelScope.launch { mcqRepository.deleteMcq(mcqId) }
    }
}
