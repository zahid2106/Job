package com.jobprep.pk.data.repository

import com.jobprep.pk.data.local.dao.McqDao
import com.jobprep.pk.data.local.dao.SubjectDao
import com.jobprep.pk.data.local.dao.TestAttemptDao
import com.jobprep.pk.data.local.dao.TestBlueprintDao
import com.jobprep.pk.data.local.entity.TestAnswerEntity
import com.jobprep.pk.data.local.entity.TestAttemptEntity
import com.jobprep.pk.domain.model.*
import com.jobprep.pk.domain.repository.TestRepository
import com.jobprep.pk.domain.usecase.ScoreTestUseCase
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TestRepositoryImpl @Inject constructor(
    private val blueprintDao: TestBlueprintDao,
    private val attemptDao: TestAttemptDao,
    private val mcqDao: McqDao,
    private val subjectDao: SubjectDao,
    private val scoreTestUseCase: ScoreTestUseCase
) : TestRepository {

    override fun observeBlueprints(): Flow<List<TestBlueprint>> =
        blueprintDao.observeAll().map { list -> list.map { it.toDomain() } }

    override fun observePopularBlueprints(limit: Int): Flow<List<TestBlueprint>> =
        blueprintDao.observePopular(limit).map { list -> list.map { it.toDomain() } }

    override suspend fun getBlueprintById(id: String): TestBlueprint? = blueprintDao.getById(id)?.toDomain()

    override suspend fun saveAttempt(
        userId: String,
        blueprintId: String?,
        title: String,
        mode: TestMode,
        durationSeconds: Int,
        answers: List<TestAnswer>
    ): String {
        val breakdown = scoreTestUseCase(answers)
        val attemptId = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()

        attemptDao.insertAttempt(
            TestAttemptEntity(
                id = attemptId, userId = userId, blueprintId = blueprintId, title = title, mode = mode.name,
                startedAt = now - durationSeconds * 1000L, submittedAt = now, durationSeconds = durationSeconds,
                totalQuestions = answers.size, correctCount = breakdown.correct, wrongCount = breakdown.wrong,
                skippedCount = breakdown.skipped, score = breakdown.score, percentage = breakdown.percentage
            )
        )
        attemptDao.insertAnswers(
            answers.map { answer ->
                TestAnswerEntity(
                    attemptId = attemptId,
                    mcqId = answer.mcq.id,
                    selectedOption = answer.selectedOption?.name,
                    isMarkedForReview = answer.isMarkedForReview,
                    orderIndex = answer.orderIndex,
                    shuffledOptionsOrder = answer.shuffledOptions.joinToString(",") { it.key.name }
                )
            }
        )
        blueprintId?.let { blueprintDao.incrementAttempts(it) }
        return attemptId
    }

    override fun observeHistory(userId: String, limit: Int): Flow<List<TestAttemptSummary>> =
        attemptDao.observeHistory(userId, limit).map { list -> list.map { it.toSummary() } }

    override fun observeRecentAttempts(userId: String, limit: Int): Flow<List<TestAttemptSummary>> =
        attemptDao.observeRecent(userId, limit).map { list -> list.map { it.toSummary() } }

    override suspend fun getResult(attemptId: String): TestResult? {
        val attempt = attemptDao.getAttempt(attemptId) ?: return null
        val answerEntities = attemptDao.getAnswers(attemptId)
        val mcqEntities = mcqDao.getByIds(answerEntities.map { it.mcqId }).associateBy { it.id }
        val subjectNames = subjectDao.observeAll()

        val answers = answerEntities.mapNotNull { answerEntity ->
            val mcqEntity = mcqEntities[answerEntity.mcqId] ?: return@mapNotNull null
            val subjectName = subjectDao.getById(mcqEntity.subjectId)?.name ?: "General"
            val mcq = mcqEntity.toDomain(subjectName)
            val order = answerEntity.shuffledOptionsOrder.split(",").mapNotNull { key ->
                mcq.options.firstOrNull { it.key.name == key }
            }
            TestAnswer(
                mcq = mcq,
                selectedOption = answerEntity.selectedOption?.let { OptionKey.valueOf(it) },
                isMarkedForReview = answerEntity.isMarkedForReview,
                orderIndex = answerEntity.orderIndex,
                shuffledOptions = order.ifEmpty { mcq.options }
            )
        }.sortedBy { it.orderIndex }

        val breakdown = scoreTestUseCase(answers)
        return TestResult(
            summary = attempt.toSummary(),
            answers = answers,
            subjectPerformance = breakdown.subjectPerformance
        )
    }

    override suspend fun upsertBlueprint(blueprint: TestBlueprint) = blueprintDao.upsert(blueprint.toEntity())

    override suspend fun deleteBlueprint(id: String) = blueprintDao.delete(id)
}
