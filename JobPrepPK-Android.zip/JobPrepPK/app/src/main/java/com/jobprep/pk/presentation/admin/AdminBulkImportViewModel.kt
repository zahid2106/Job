package com.jobprep.pk.presentation.admin

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jobprep.pk.domain.model.Mcq
import com.jobprep.pk.domain.model.McqOption
import com.jobprep.pk.domain.model.OptionKey
import com.jobprep.pk.domain.model.QuestionDifficulty
import com.jobprep.pk.domain.repository.McqRepository
import com.jobprep.pk.domain.usecase.ValidateMcqUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.util.UUID
import javax.inject.Inject

data class BulkImportRowResult(val lineNumber: Int, val rawLine: String, val mcq: Mcq?, val errors: List<String>)

data class BulkImportState(
    val rawText: String = "",
    val results: List<BulkImportRowResult> = emptyList(),
    val isImporting: Boolean = false,
    val importedCount: Int = 0,
    val hasImported: Boolean = false
) {
    val validCount: Int get() = results.count { it.mcq != null }
    val invalidCount: Int get() = results.size - validCount
}

@HiltViewModel
class AdminBulkImportViewModel @Inject constructor(
    private val mcqRepository: McqRepository,
    private val validateMcqUseCase: ValidateMcqUseCase
) : ViewModel() {

    private val _state = MutableStateFlow(BulkImportState())
    val state: StateFlow<BulkImportState> = _state

    fun onTextChange(text: String) {
        _state.value = _state.value.copy(rawText = text, hasImported = false)
    }

    /**
     * Expected format, one question per line, pipe-delimited:
     * subjectId|question text|option A|option B|option C|option D|correct letter (A-D)|explanation
     */
    fun parse() {
        val lines = _state.value.rawText.lines().map { it.trim() }.filter { it.isNotBlank() }
        val results = lines.mapIndexed { index, line ->
            val parts = line.split("|").map { it.trim() }
            if (parts.size < 8) {
                BulkImportRowResult(index + 1, line, null, listOf("Expected 8 fields separated by '|', found ${parts.size}."))
            } else {
                val (subjectId, question, a, b, c, d, correct, explanation) = parts
                val correctKey = runCatching { OptionKey.valueOf(correct.uppercase()) }.getOrNull()
                if (correctKey == null) {
                    BulkImportRowResult(index + 1, line, null, listOf("Correct answer must be one of A, B, C, D."))
                } else {
                    val mcq = Mcq(
                        id = "mcq_${UUID.randomUUID().toString().take(10)}",
                        subjectId = subjectId,
                        subjectName = "",
                        jobCategory = null,
                        questionText = question,
                        options = listOf(
                            McqOption(OptionKey.A, a), McqOption(OptionKey.B, b),
                            McqOption(OptionKey.C, c), McqOption(OptionKey.D, d)
                        ),
                        correctOption = correctKey,
                        explanation = explanation,
                        difficulty = QuestionDifficulty.MEDIUM
                    )
                    val validation = validateMcqUseCase(mcq)
                    if (validation.isValid) BulkImportRowResult(index + 1, line, mcq, emptyList())
                    else BulkImportRowResult(index + 1, line, null, validation.errors)
                }
            }
        }
        _state.value = _state.value.copy(results = results)
    }

    fun importValidRows() {
        val validMcqs = _state.value.results.mapNotNull { it.mcq }
        if (validMcqs.isEmpty()) return
        viewModelScope.launch {
            _state.value = _state.value.copy(isImporting = true)
            val count = mcqRepository.bulkImportMcqs(validMcqs)
            _state.value = _state.value.copy(isImporting = false, importedCount = count, hasImported = true, results = emptyList(), rawText = "")
        }
    }

    // Destructuring support for List<String> with 8 elements
    private operator fun <T> List<T>.component6() = this[5]
    private operator fun <T> List<T>.component7() = this[6]
    private operator fun <T> List<T>.component8() = this[7]
}
