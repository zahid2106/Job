package com.jobprep.pk.domain.model

/**
 * A job announcement from a Pakistani recruiting organization (FPSC, PPSC, NTS, etc).
 */
data class Job(
    val id: String,
    val organization: OrgType,
    val title: String,
    val bpsOrGrade: String,
    val qualification: String,
    val ageLimitMin: Int,
    val ageLimitMax: Int,
    val vacancies: Int,
    val experienceRequired: String,
    val province: String,
    val postedDate: Long,
    val deadline: Long,
    val advertisementNumber: String,
    val details: String,
    val applyLink: String,
    val isFeatured: Boolean,
    val isActive: Boolean
) {
    fun status(now: Long = System.currentTimeMillis()): JobStatus = when {
        deadline < now -> JobStatus.CLOSED
        deadline - now <= 3L * 24 * 60 * 60 * 1000 -> JobStatus.CLOSING_SOON
        else -> JobStatus.OPEN
    }
}
