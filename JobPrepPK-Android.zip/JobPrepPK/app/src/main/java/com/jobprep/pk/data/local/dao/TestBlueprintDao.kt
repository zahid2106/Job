package com.jobprep.pk.data.local.dao

import androidx.room.*
import com.jobprep.pk.data.local.entity.TestBlueprintEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TestBlueprintDao {
    @Query("SELECT * FROM test_blueprints ORDER BY isPopular DESC, title ASC")
    fun observeAll(): Flow<List<TestBlueprintEntity>>

    @Query("SELECT * FROM test_blueprints WHERE isPopular = 1 ORDER BY attemptsCount DESC LIMIT :limit")
    fun observePopular(limit: Int): Flow<List<TestBlueprintEntity>>

    @Query("SELECT * FROM test_blueprints WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): TestBlueprintEntity?

    @Upsert
    suspend fun upsert(blueprint: TestBlueprintEntity)

    @Query("DELETE FROM test_blueprints WHERE id = :id")
    suspend fun delete(id: String)

    @Query("UPDATE test_blueprints SET attemptsCount = attemptsCount + 1 WHERE id = :id")
    suspend fun incrementAttempts(id: String)

    @Query("SELECT COUNT(*) FROM test_blueprints")
    suspend fun count(): Int
}
