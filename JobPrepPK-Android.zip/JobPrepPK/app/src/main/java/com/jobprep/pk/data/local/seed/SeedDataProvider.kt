package com.jobprep.pk.data.local.seed

import com.jobprep.pk.data.local.entity.*
import com.jobprep.pk.util.Constants
import com.jobprep.pk.util.PasswordHasher
import java.util.concurrent.TimeUnit

/**
 * Provides realistic sample data so the app is fully testable on first launch,
 * without needing the remote content API to be reachable. This mirrors the shape
 * of data that would normally come from [com.jobprep.pk.data.remote.api.ContentApiService],
 * keeping the UI layer agnostic to where content originates from.
 */
object SeedDataProvider {

    private val now = System.currentTimeMillis()
    private fun daysFromNow(days: Long) = now + TimeUnit.DAYS.toMillis(days)
    private fun daysAgo(days: Long) = now - TimeUnit.DAYS.toMillis(days)

    fun seedUsers(): List<UserEntity> {
        val adminSalt = PasswordHasher.generateSalt()
        val demoSalt = PasswordHasher.generateSalt()
        return listOf(
            UserEntity(
                id = "user_admin",
                name = "System Administrator",
                email = Constants.SEED_ADMIN_EMAIL,
                passwordHash = PasswordHasher.hash(Constants.SEED_ADMIN_PASSWORD, adminSalt),
                salt = adminSalt,
                isAdmin = true,
                createdAt = daysAgo(120)
            ),
            UserEntity(
                id = "user_demo",
                name = "Ahmed Raza",
                email = Constants.SEED_DEMO_EMAIL,
                passwordHash = PasswordHasher.hash(Constants.SEED_DEMO_PASSWORD, demoSalt),
                salt = demoSalt,
                isAdmin = false,
                createdAt = daysAgo(60)
            )
        )
    }

    fun seedSubjects(): List<SubjectEntity> = listOf(
        SubjectEntity("subj_gk", "General Knowledge", "public", "#2563EB", null),
        SubjectEntity("subj_pak_studies", "Pakistan Studies", "flag", "#16A34A", null),
        SubjectEntity("subj_current_affairs", "Current Affairs", "newspaper", "#D97706", null),
        SubjectEntity("subj_islamiat", "Islamiat", "mosque", "#0D9488", null),
        SubjectEntity("subj_english", "English", "language", "#7C3AED", null),
        SubjectEntity("subj_urdu", "Urdu", "translate", "#DB2777", null),
        SubjectEntity("subj_math", "Mathematics", "calculate", "#DC2626", null),
        SubjectEntity("subj_computer", "Computer Science", "computer", "#0284C7", null),
        SubjectEntity("subj_science", "General Science", "science", "#65A30D", null),
        SubjectEntity("subj_police_rules", "Police Rules & Procedure", "local_police", "#334155", "POLICE"),
        SubjectEntity("subj_banking", "Banking & Finance", "account_balance", "#0F766E", "BANK"),
        SubjectEntity("subj_pedagogy", "Teaching & Pedagogy", "school", "#9333EA", "TEACHING")
    )

    fun seedJobs(): List<JobEntity> = listOf(
        JobEntity(
            id = "job_fpsc_css_2026",
            organization = "FPSC", title = "Central Superior Services (CSS) Competitive Exam 2026",
            bpsOrGrade = "BPS-17", qualification = "Bachelor's Degree (Second Division) from a recognized university",
            ageLimitMin = 21, ageLimitMax = 30, vacancies = 512, experienceRequired = "Not required",
            province = "Federal", postedDate = daysAgo(10), deadline = daysFromNow(9),
            advertisementNumber = "F.4-01/2026-R", isFeatured = true, isActive = true,
            applyLink = "https://www.fpsc.gov.pk",
            details = "FPSC invites applications from Pakistani nationals for the Central Superior Services " +
                "Competitive Examination 2026 for appointment to posts in BPS-17 under the Federal Government. " +
                "Candidates must possess a bachelor's degree in any discipline and meet the prescribed age and " +
                "medical fitness criteria. The exam consists of a written test, psychological assessment and interview."
        ),
        JobEntity(
            id = "job_ppsc_lecturer_2026",
            organization = "PPSC", title = "Lecturer (Computer Science)",
            bpsOrGrade = "BPS-17", qualification = "MSc/BS Computer Science with minimum 2nd Division, 18 years education",
            ageLimitMin = 21, ageLimitMax = 35, vacancies = 148, experienceRequired = "Not required",
            province = "Punjab", postedDate = daysAgo(5), deadline = daysFromNow(15),
            advertisementNumber = "PPSC/2026/Edu-14", isFeatured = true, isActive = true,
            applyLink = "https://www.ppsc.gop.pk",
            details = "Punjab Public Service Commission is hiring Lecturers (Computer Science) for Colleges " +
                "under the School Education Department, Government of Punjab. Domicile of Punjab is mandatory. " +
                "Selection will be based on a written test conducted by PPSC followed by an interview."
        ),
        JobEntity(
            id = "job_nts_wapda_2026",
            organization = "NTS", title = "Sub Engineer (Electrical) - WAPDA",
            bpsOrGrade = "BPS-11", qualification = "DAE (Electrical) from a recognized board",
            ageLimitMin = 18, ageLimitMax = 28, vacancies = 220, experienceRequired = "Not required",
            province = "All Pakistan", postedDate = daysAgo(3), deadline = daysFromNow(6),
            advertisementNumber = "NTS-WAPDA-2026-02", isFeatured = true, isActive = true,
            applyLink = "https://www.nts.org.pk",
            details = "National Testing Service is conducting recruitment tests on behalf of WAPDA for the post " +
                "of Sub Engineer (Electrical). Candidates holding a 3-year DAE from a PEC-recognized institute " +
                "are eligible to apply. Test will be NTS-NAT based, MCQ format, 100 marks."
        ),
        JobEntity(
            id = "job_pts_health_2026",
            organization = "PTS", title = "Medical Technician - Health Department",
            bpsOrGrade = "BPS-12", qualification = "DMLT / Diploma in Medical Lab Technology",
            ageLimitMin = 18, ageLimitMax = 30, vacancies = 76, experienceRequired = "1 year preferred",
            province = "KPK", postedDate = daysAgo(2), deadline = daysFromNow(20),
            advertisementNumber = "PTS/HD/2026/07", isFeatured = false, isActive = true,
            applyLink = "https://www.pts.org.pk",
            details = "Punjab/Khyber Testing Service invites applications for Medical Technician posts in the " +
                "Health Department. Candidates must hold a valid DMLT certificate and be registered with the " +
                "relevant medical council."
        ),
        JobEntity(
            id = "job_ots_forest_2026",
            organization = "OTS", title = "Forest Guard",
            bpsOrGrade = "BPS-07", qualification = "Matriculation, physically fit, height 5'6\" minimum",
            ageLimitMin = 18, ageLimitMax = 25, vacancies = 340, experienceRequired = "Not required",
            province = "KPK", postedDate = daysAgo(7), deadline = daysFromNow(4),
            advertisementNumber = "OTS/KP/FD/2026-11", isFeatured = false, isActive = true,
            applyLink = "https://www.ots.org.pk",
            details = "Open Testing Service KPK is recruiting Forest Guards for the Forest Department. " +
                "A physical measurement test will be conducted before the written MCQ-based test."
        ),
        JobEntity(
            id = "job_police_constable_2026",
            organization = "POLICE", title = "Police Constable (BPS-07)",
            bpsOrGrade = "BPS-07", qualification = "Matriculation or equivalent",
            ageLimitMin = 18, ageLimitMax = 25, vacancies = 4500, experienceRequired = "Not required",
            province = "Punjab", postedDate = daysAgo(12), deadline = daysFromNow(2),
            advertisementNumber = "PPD/2026/CONST-03", isFeatured = true, isActive = true,
            applyLink = "https://www.punjabpolice.gov.pk",
            details = "Punjab Police is recruiting Constables across all districts. Candidates must clear " +
                "the physical standard test (height, chest, running) followed by a written test covering " +
                "General Knowledge, Pakistan Studies, Islamiat, English and Police Rules."
        ),
        JobEntity(
            id = "job_army_soldier_2026",
            organization = "ARMY", title = "Soldier General Duty (Pakistan Army)",
            bpsOrGrade = "Soldier Rank", qualification = "Matriculation, unmarried, medically fit",
            ageLimitMin = 17, ageLimitMax = 23, vacancies = 2000, experienceRequired = "Not required",
            province = "All Pakistan", postedDate = daysAgo(15), deadline = daysFromNow(25),
            advertisementNumber = "PA/GD/2026-Batch-A", isFeatured = false, isActive = true,
            applyLink = "https://www.joinpakarmy.gov.pk",
            details = "Pakistan Army is inviting applications for Soldier (General Duty) from eligible " +
                "Pakistani male citizens. Selection includes initial test, physical test, medical examination " +
                "and final merit test at the Army Selection & Recruitment Centre."
        ),
        JobEntity(
            id = "job_navy_sailor_2026",
            organization = "NAVY", title = "Sailor (Seaman Branch) - Pakistan Navy",
            bpsOrGrade = "Sailor Rank", qualification = "Matriculation with Science, minimum 55% marks",
            ageLimitMin = 16, ageLimitMax = 22, vacancies = 450, experienceRequired = "Not required",
            province = "All Pakistan", postedDate = daysAgo(8), deadline = daysFromNow(18),
            advertisementNumber = "PN/SAILOR/2026-B", isFeatured = false, isActive = true,
            applyLink = "https://www.joinpaknavy.gov.pk",
            details = "Pakistan Navy is recruiting Sailors in the Seaman Branch. Candidates undergo an " +
                "Intelligence test, academic written test, physical fitness test and interview at Navy " +
                "recruitment centers in Karachi, Lahore and Islamabad."
        ),
        JobEntity(
            id = "job_paf_airman_2026",
            organization = "AIR_FORCE", title = "Airman (Avionics) - Pakistan Air Force",
            bpsOrGrade = "Airman Rank", qualification = "FSc Pre-Engineering / DAE Electronics, minimum 60%",
            ageLimitMin = 16, ageLimitMax = 21, vacancies = 300, experienceRequired = "Not required",
            province = "All Pakistan", postedDate = daysAgo(4), deadline = daysFromNow(30),
            advertisementNumber = "PAF/AVN/2026-C", isFeatured = false, isActive = true,
            applyLink = "https://www.joinpaf.gov.pk",
            details = "PAF is looking for young Pakistani men and women to join as Airmen in the Avionics " +
                "trade. Written intelligence & academic test followed by ISSB assessment and medical board."
        ),
        JobEntity(
            id = "job_nbp_ogp_2026",
            organization = "BANK", title = "Officer Grade III (OG-III) - National Bank of Pakistan",
            bpsOrGrade = "OG-III", qualification = "BBA/BCom/MBA/MSc with minimum CGPA 2.5 or 60% marks",
            ageLimitMin = 21, ageLimitMax = 28, vacancies = 600, experienceRequired = "Not required",
            province = "All Pakistan", postedDate = daysAgo(6), deadline = daysFromNow(11),
            advertisementNumber = "NBP/HR/2026-OG3", isFeatured = true, isActive = true,
            applyLink = "https://www.nbp.com.pk",
            details = "National Bank of Pakistan is hiring fresh graduates as Officer Grade III across all " +
                "branches. Test will assess Quantitative Aptitude, English, General Banking Knowledge and " +
                "Current Affairs, followed by a panel interview."
        ),
        JobEntity(
            id = "job_teaching_educator_2026",
            organization = "TEACHING", title = "Educator (SESE - Science)",
            bpsOrGrade = "BPS-16", qualification = "BSc/BS with B.Ed, 18 years education preferred",
            ageLimitMin = 21, ageLimitMax = 35, vacancies = 900, experienceRequired = "Not required",
            province = "Sindh", postedDate = daysAgo(1), deadline = daysFromNow(21),
            advertisementNumber = "SED-SINDH/2026/EDU-08", isFeatured = false, isActive = true,
            applyLink = "https://www.steta.edu.pk",
            details = "Sindh Education & Literacy Department is recruiting Secondary School Educators " +
                "(Science) through Sindh Teachers Education Development Authority (STEDA). A computer-based " +
                "test covering subject knowledge and pedagogy will be conducted."
        ),
        JobEntity(
            id = "job_wasa_admin_2026",
            organization = "OTHER", title = "Assistant Director (Admin) - WASA",
            bpsOrGrade = "BPS-17", qualification = "Master's Degree in Public Administration or relevant field",
            ageLimitMin = 21, ageLimitMax = 32, vacancies = 12, experienceRequired = "2 years relevant experience",
            province = "Punjab", postedDate = daysAgo(20), deadline = daysAgo(2),
            advertisementNumber = "WASA/2026/AD-02", isFeatured = false, isActive = true,
            applyLink = "https://www.wasa.gop.pk",
            details = "Water and Sanitation Agency invites applications for Assistant Director (Admin). " +
                "This listing has now closed; check WASA's website for future announcements."
        )
    )

    fun seedBlueprints(): List<TestBlueprintEntity> = listOf(
        TestBlueprintEntity(
            id = "test_general_mega", title = "General Knowledge Mega Test",
            description = "A broad mixed test covering GK, Pakistan Studies, Current Affairs and Islamiat — " +
                "similar to the first stage of most FPSC/PPSC/NTS screening tests.",
            subjectIds = "subj_gk,subj_pak_studies,subj_current_affairs,subj_islamiat",
            jobCategory = null, questionCount = 30, durationMinutes = 30, attemptsCount = 4210, isPopular = true
        ),
        TestBlueprintEntity(
            id = "test_english_grammar", title = "English & Grammar Booster",
            description = "Focused practice on vocabulary, grammar, synonyms/antonyms and sentence correction.",
            subjectIds = "subj_english", jobCategory = null, questionCount = 20, durationMinutes = 20,
            attemptsCount = 3120, isPopular = true
        ),
        TestBlueprintEntity(
            id = "test_police_constable", title = "Police Constable Full Test",
            description = "Simulates the Punjab Police constable written test: GK, Pak Studies, Islamiat, " +
                "English and Police Rules.",
            subjectIds = "subj_gk,subj_pak_studies,subj_islamiat,subj_english,subj_police_rules",
            jobCategory = "POLICE", questionCount = 25, durationMinutes = 25, attemptsCount = 2870, isPopular = true
        ),
        TestBlueprintEntity(
            id = "test_bank_officer", title = "Bank Officer (OG-III) Mock Test",
            description = "Quantitative aptitude, English and banking/current affairs matching NBP/HBL/UBL test patterns.",
            subjectIds = "subj_math,subj_english,subj_banking,subj_current_affairs",
            jobCategory = "BANK", questionCount = 30, durationMinutes = 35, attemptsCount = 1980, isPopular = true
        ),
        TestBlueprintEntity(
            id = "test_teaching_pedagogy", title = "Educator / Teaching Test",
            description = "Subject knowledge plus pedagogy and teaching methodology questions for Educator posts.",
            subjectIds = "subj_science,subj_pedagogy,subj_english,subj_urdu",
            jobCategory = "TEACHING", questionCount = 25, durationMinutes = 30, attemptsCount = 1540, isPopular = true
        ),
        TestBlueprintEntity(
            id = "test_computer_it", title = "Computer Science / IT Fundamentals",
            description = "MS Office, internet basics, hardware/software and programming fundamentals.",
            subjectIds = "subj_computer", jobCategory = null, questionCount = 20, durationMinutes = 20,
            attemptsCount = 990, isPopular = false
        ),
        TestBlueprintEntity(
            id = "test_math_quant", title = "Mathematics & Quantitative Aptitude",
            description = "Arithmetic, percentages, ratios, algebra and data interpretation.",
            subjectIds = "subj_math", jobCategory = null, questionCount = 20, durationMinutes = 25,
            attemptsCount = 1310, isPopular = false
        )
    )

    fun seedNotifications(): List<NotificationEntity> = listOf(
        NotificationEntity(
            "notif_1", "FPSC CSS 2026 applications open",
            "Apply before the deadline for 512 BPS-17 vacancies across federal departments.",
            "NEW_JOB", "job_fpsc_css_2026", daysAgo(1), false
        ),
        NotificationEntity(
            "notif_2", "Police Constable deadline in 2 days",
            "Punjab Police constable recruitment closes soon — 4500 vacancies. Don't miss it.",
            "DEADLINE", "job_police_constable_2026", daysAgo(0), false
        ),
        NotificationEntity(
            "notif_3", "New mock test added: Bank Officer (OG-III)",
            "Practice with a fresh 30-question mock test matching NBP's OG-III pattern.",
            "NEW_TEST", "test_bank_officer", daysAgo(3), true
        ),
        NotificationEntity(
            "notif_4", "OTS Forest Guard test schedule announced",
            "Physical test followed by written MCQ test. Check the job details for the schedule.",
            "ANNOUNCEMENT", "job_ots_forest_2026", daysAgo(5), true
        ),
        NotificationEntity(
            "notif_5", "WAPDA Sub Engineer applications via NTS",
            "220 vacancies for DAE (Electrical) holders. Apply through the NTS portal.",
            "NEW_JOB", "job_nts_wapda_2026", daysAgo(6), true
        )
    )

    // ---- MCQs -------------------------------------------------------------

    private fun mcq(
        id: String, subjectId: String, q: String,
        a: String, b: String, c: String, d: String, correct: String,
        explanation: String, difficulty: String = "MEDIUM", jobCategory: String? = null
    ) = McqEntity(id, subjectId, jobCategory, q, a, b, c, d, correct, explanation, difficulty)

    fun seedMcqs(): List<McqEntity> = buildList {
        // General Knowledge
        add(mcq("mcq_gk_1", "subj_gk", "Which is the largest continent by area?",
            "Africa", "Asia", "North America", "Antarctica", "B",
            "Asia is the largest continent, covering about 30% of Earth's land area.", "EASY"))
        add(mcq("mcq_gk_2", "subj_gk", "The headquarters of the United Nations is located in which city?",
            "Geneva", "Paris", "New York", "London", "C",
            "The UN Headquarters is located in Manhattan, New York City, USA."))
        add(mcq("mcq_gk_3", "subj_gk", "Which is the longest river in the world?",
            "Amazon River", "Nile River", "Yangtze River", "Mississippi River", "B",
            "The Nile River in Africa is traditionally considered the longest river at about 6,650 km."))
        add(mcq("mcq_gk_4", "subj_gk", "The 'Nobel Prize' is awarded in which country?",
            "Sweden", "Norway", "Switzerland", "Denmark", "A",
            "Most Nobel Prizes are awarded in Stockholm, Sweden, except the Peace Prize, awarded in Oslo, Norway."))
        add(mcq("mcq_gk_5", "subj_gk", "Which organ of the human body is primarily responsible for pumping blood?",
            "Lungs", "Liver", "Heart", "Kidney", "C",
            "The heart pumps blood through the circulatory system via rhythmic contractions.", "EASY"))
        add(mcq("mcq_gk_6", "subj_gk", "The currency of Japan is called?",
            "Won", "Yuan", "Yen", "Ringgit", "C", "Japan's official currency is the Yen (JPY)."))
        add(mcq("mcq_gk_7", "subj_gk", "Which gas makes up the majority of Earth's atmosphere?",
            "Oxygen", "Carbon Dioxide", "Nitrogen", "Hydrogen", "C",
            "Nitrogen makes up about 78% of Earth's atmosphere, followed by oxygen at about 21%."))

        // Pakistan Studies
        add(mcq("mcq_ps_1", "subj_pak_studies", "Pakistan came into existence on which date?",
            "14 August 1947", "23 March 1940", "11 September 1948", "6 September 1965", "A",
            "Pakistan gained independence from British rule on 14 August 1947.", "EASY"))
        add(mcq("mcq_ps_2", "subj_pak_studies", "The Lahore Resolution was presented in which year?",
            "1930", "1940", "1946", "1947", "B",
            "The Lahore Resolution (Pakistan Resolution) was presented by A.K. Fazlul Huq on 23 March 1940."))
        add(mcq("mcq_ps_3", "subj_pak_studies", "Who was the first Governor-General of Pakistan?",
            "Liaquat Ali Khan", "Muhammad Ali Jinnah", "Sir Zafarullah Khan", "Ayub Khan", "B",
            "Muhammad Ali Jinnah served as Pakistan's first Governor-General from 1947 until his death in 1948."))
        add(mcq("mcq_ps_4", "subj_pak_studies", "Which mountain range separates Pakistan from China?",
            "Hindu Kush", "Himalayas", "Karakoram", "Sulaiman Range", "C",
            "The Karakoram Range, home to K2, lies along Pakistan's border with China."))
        add(mcq("mcq_ps_5", "subj_pak_studies", "The national language of Pakistan is?",
            "Punjabi", "Urdu", "Sindhi", "Pashto", "B",
            "Urdu is Pakistan's national language, as declared in the Constitution of 1973.", "EASY"))
        add(mcq("mcq_ps_6", "subj_pak_studies", "Pakistan's first Constitution was enforced in which year?",
            "1956", "1962", "1973", "1947", "A",
            "Pakistan's first Constitution was enforced on 23 March 1956, making it an Islamic Republic."))
        add(mcq("mcq_ps_7", "subj_pak_studies", "Which is the largest province of Pakistan by area?",
            "Punjab", "Sindh", "Balochistan", "Khyber Pakhtunkhwa", "C",
            "Balochistan is the largest province of Pakistan by land area, covering about 44% of the country."))

        // Current Affairs
        add(mcq("mcq_ca_1", "subj_current_affairs", "SCO stands for which organization?",
            "South Central Organization", "Shanghai Cooperation Organisation",
            "South Cooperation Office", "Strategic Command Organization", "B",
            "SCO (Shanghai Cooperation Organisation) is a Eurasian political, economic and security alliance."))
        add(mcq("mcq_ca_2", "subj_current_affairs", "CPEC is a flagship project of which larger initiative?",
            "SAARC", "Belt and Road Initiative (BRI)", "G20", "OIC", "B",
            "The China-Pakistan Economic Corridor (CPEC) is a flagship project of China's Belt and Road Initiative."))
        add(mcq("mcq_ca_3", "subj_current_affairs", "Which organization publishes the annual 'Human Development Index'?",
            "World Bank", "IMF", "UNDP", "WTO", "C",
            "The United Nations Development Programme (UNDP) publishes the Human Development Index (HDI) each year."))
        add(mcq("mcq_ca_4", "subj_current_affairs", "The G20 summit primarily brings together which group of economies?",
            "Only European economies", "Major and emerging world economies",
            "Only Asian economies", "Only oil-exporting economies", "B",
            "The G20 comprises 19 countries and the EU, representing the world's major and emerging economies."))
        add(mcq("mcq_ca_5", "subj_current_affairs", "Which Pakistani city hosted the 2023 SCO Foreign Ministers meeting preparations hub historically associated with SAARC summits?",
            "Islamabad", "Lahore", "Karachi", "Peshawar", "A",
            "Islamabad, as the federal capital, typically hosts major diplomatic summits and ministerial meetings."))

        // Islamiat
        add(mcq("mcq_isl_1", "subj_islamiat", "How many Surahs are there in the Holy Quran?",
            "110", "114", "120", "99", "B", "The Holy Quran consists of 114 Surahs (chapters).", "EASY"))
        add(mcq("mcq_isl_2", "subj_islamiat", "Which was the first revealed Surah of the Holy Quran?",
            "Al-Fatiha", "Al-Baqarah", "Al-Alaq", "Al-Ikhlas", "C",
            "The first verses revealed to Prophet Muhammad (PBUH) were from Surah Al-Alaq, in the Cave of Hira."))
        add(mcq("mcq_isl_3", "subj_islamiat", "How many pillars of Islam are there?",
            "Four", "Five", "Six", "Seven", "B",
            "Islam has five pillars: Shahadah, Salah, Zakat, Sawm and Hajj.", "EASY"))
        add(mcq("mcq_isl_4", "subj_islamiat", "In which year did the Hijrah (migration to Madinah) take place?",
            "610 CE", "622 CE", "632 CE", "570 CE", "B",
            "The Hijrah took place in 622 CE and marks the beginning of the Islamic (Hijri) calendar."))
        add(mcq("mcq_isl_5", "subj_islamiat", "Who was the first Caliph of Islam?",
            "Hazrat Umar (RA)", "Hazrat Abu Bakr (RA)", "Hazrat Usman (RA)", "Hazrat Ali (RA)", "B",
            "Hazrat Abu Bakr Siddiq (RA) was elected as the first Caliph after the death of the Prophet (PBUH)."))

        // English
        add(mcq("mcq_en_1", "subj_english", "Choose the correct synonym of 'Abundant':",
            "Scarce", "Plentiful", "Limited", "Rare", "B",
            "'Abundant' means existing in large quantities; 'plentiful' is its closest synonym."))
        add(mcq("mcq_en_2", "subj_english", "Choose the correct antonym of 'Optimistic':",
            "Hopeful", "Cheerful", "Pessimistic", "Confident", "C",
            "'Pessimistic' is the opposite of 'optimistic', meaning expecting the worst outcome."))
        add(mcq("mcq_en_3", "subj_english", "Identify the correctly punctuated sentence:",
            "Its a beautiful day, isnt it?", "It's a beautiful day, isn't it?",
            "Its a beautiful day, isn't it.", "It's a beautiful day isnt it", "B",
            "'It's' (it is) and 'isn't' (is not) require apostrophes, and the sentence ends with a question mark."))
        add(mcq("mcq_en_4", "subj_english", "Fill in the blank: She has been working here ___ 2019.",
            "since", "for", "from", "at", "A",
            "'Since' is used with a specific point in time (2019); 'for' would be used with a duration."))
        add(mcq("mcq_en_5", "subj_english", "Choose the correctly spelled word:",
            "Recieve", "Receive", "Receeve", "Receve", "B",
            "The correct spelling follows 'i before e except after c': R-E-C-E-I-V-E."))
        add(mcq("mcq_en_6", "subj_english", "What is the plural of 'Criterion'?",
            "Criterions", "Criteria", "Criterias", "Criterion's", "B",
            "'Criterion' is a Greek-origin word whose irregular plural is 'Criteria'."))

        // Urdu
        add(mcq("mcq_ur_1", "subj_urdu", "\u0645\u062A\u0636\u0627\u062F \u0644\u06A9\u06BE\u06CC\u06BA: \u0627\u0645\u06CC\u0631",
            "\u0641\u0642\u06CC\u0631", "\u063A\u0631\u06CC\u0628", "\u0631\u0626\u06CC\u0633", "\u0645\u0633\u06A9\u06CC\u0646", "A",
            "\"\u0627\u0645\u06CC\u0631\" \u06A9\u0627 \u0645\u062A\u0636\u0627\u062F \"\u0641\u0642\u06CC\u0631\" \u06C1\u06D2\u06D4"))
        add(mcq("mcq_ur_2", "subj_urdu", "\"\u0645\u0648\u0644\u0627\u0646\u0627 \u062D\u0627\u0644\u06CC \u0645\u0639\u0627\u0648\u06CC \u0646\u062F\u0648\u06CC\" \u06A9\u06CC \u0634\u06C1\u0631\u06CC \u06A9\u062A\u0627\u0628 \u06A9\u0648\u0646 \u0633\u06CC \u06C1\u06D2\u061F",
            "\u0628\u0627\u0646\u06AF \u062F\u0631\u0627", "\u0627\u0644\u06C1\u0644\u0627\u0644", "\u062A\u0630\u06A9\u0631\u06C1 \u06C1\u0646\u062F\u0648\u0627\u0644\u0628 \u0627\u06CC\u0645\u0627\u0646", "\u0645\u0642\u062F\u0645\u06C1 \u0634\u0639\u0631\u0648 \u0634\u0627\u0639\u0631\u06CC", "B",
            "\"\u0627\u0644\u06C1\u0644\u0627\u0644\" \u0645\u0648\u0644\u0627\u0646\u0627 \u062D\u0627\u0644\u06CC \u0645\u0639\u0627\u0648\u06CC \u0646\u062F\u0648\u06CC \u06A9\u06CC \u0627\u06C1\u0645 \u062A\u0635\u0646\u06CC\u0641 \u06C1\u06D2\u06D4"))
        add(mcq("mcq_ur_3", "subj_urdu", "\"\u0642\u0644\u0645\" \u06A9\u0627 \u062C\u0645\u0639 \u06A9\u06CC\u0627 \u06C1\u06D2\u061F",
            "\u0642\u0644\u0645\u06CC\u0646", "\u0627\u0642\u0644\u0627\u0645", "\u0642\u0644\u0645\u0648\u06BA", "\u0642\u0644\u0645\u0627\u062A", "B",
            "\"\u0642\u0644\u0645\" \u06A9\u0627 \u062F\u0631\u0633\u062A \u062C\u0645\u0639 \"\u0627\u0642\u0644\u0627\u0645\" \u06C1\u06D2\u06D4"))

        // Mathematics
        add(mcq("mcq_math_1", "subj_math", "What is 15% of 200?",
            "20", "25", "30", "35", "C", "15% of 200 = (15/100) x 200 = 30.", "EASY"))
        add(mcq("mcq_math_2", "subj_math", "If a train travels 60 km in 45 minutes, what is its speed in km/h?",
            "60 km/h", "75 km/h", "80 km/h", "90 km/h", "C",
            "Speed = Distance / Time = 60 km / 0.75 h = 80 km/h."))
        add(mcq("mcq_math_3", "subj_math", "Solve for x: 2x + 5 = 17",
            "5", "6", "7", "8", "B", "2x + 5 = 17 -> 2x = 12 -> x = 6."))
        add(mcq("mcq_math_4", "subj_math", "What is the value of 7^2 - 4^2?",
            "33", "43", "49", "16", "A", "7^2 = 49, 4^2 = 16, so 49 - 16 = 33."))
        add(mcq("mcq_math_5", "subj_math", "The average of 10, 20 and 30 is:",
            "15", "20", "25", "30", "B", "Average = (10+20+30)/3 = 60/3 = 20.", "EASY"))
        add(mcq("mcq_math_6", "subj_math", "A shopkeeper sells an item for Rs. 1200 at a 20% profit. What was the cost price?",
            "Rs. 900", "Rs. 960", "Rs. 1000", "Rs. 1100", "C",
            "Cost Price = Selling Price / (1 + profit%) = 1200 / 1.2 = Rs. 1000."))

        // Computer Science
        add(mcq("mcq_cs_1", "subj_computer", "What does 'CPU' stand for?",
            "Central Processing Unit", "Computer Personal Unit",
            "Central Program Utility", "Control Processing Unit", "A",
            "CPU stands for Central Processing Unit, the primary component that executes instructions.", "EASY"))
        add(mcq("mcq_cs_2", "subj_computer", "Which of these is an operating system?",
            "MS Word", "Windows", "Photoshop", "Chrome", "B",
            "Windows is an operating system; the others are application software."))
        add(mcq("mcq_cs_3", "subj_computer", "In MS Excel, which symbol starts a formula?",
            "@", "#", "=", "$", "C", "Every formula in Excel begins with an equals sign (=)."))
        add(mcq("mcq_cs_4", "subj_computer", "What does 'RAM' stand for?",
            "Random Access Memory", "Read Access Memory", "Rapid Access Module", "Random Application Memory", "A",
            "RAM (Random Access Memory) is volatile memory used for temporary data storage while a device is running."))
        add(mcq("mcq_cs_5", "subj_computer", "Which shortcut key is used to copy selected text?",
            "Ctrl+V", "Ctrl+X", "Ctrl+C", "Ctrl+Z", "C", "Ctrl+C is the standard shortcut for copying selected content."))

        // General Science
        add(mcq("mcq_sci_1", "subj_science", "What is the chemical symbol for water?",
            "H2O", "HO2", "O2H", "H2O2", "A", "Water's chemical formula is H2O — two hydrogen atoms and one oxygen atom.", "EASY"))
        add(mcq("mcq_sci_2", "subj_science", "Which planet is known as the 'Red Planet'?",
            "Venus", "Mars", "Jupiter", "Saturn", "B",
            "Mars appears red due to iron oxide (rust) on its surface, earning it the nickname 'Red Planet'."))
        add(mcq("mcq_sci_3", "subj_science", "The process by which plants make their food is called?",
            "Respiration", "Photosynthesis", "Transpiration", "Digestion", "B",
            "Photosynthesis is the process by which green plants use sunlight to synthesize food from CO2 and water."))
        add(mcq("mcq_sci_4", "subj_science", "Which blood group is known as the universal donor?",
            "AB+", "O-", "A+", "B-", "B",
            "O-negative blood lacks A, B and Rh antigens, making it safe for transfusion to nearly all blood types."))
        add(mcq("mcq_sci_5", "subj_science", "Sound cannot travel through which of the following?",
            "Water", "Steel", "Vacuum", "Air", "C",
            "Sound is a mechanical wave and requires a medium to travel; it cannot travel through a vacuum."))

        // Police Rules & Procedure (job-specific)
        add(mcq("mcq_pol_1", "subj_police_rules", "Under the Police Order 2002, who heads a District Police?",
            "SHO", "District Police Officer (DPO)", "IGP", "ASI", "B",
            "The District Police Officer (DPO) is responsible for police administration at the district level."))
        add(mcq("mcq_pol_2", "subj_police_rules", "An FIR stands for:",
            "First Investigation Record", "First Information Report",
            "Final Inquiry Report", "Field Incident Report", "B",
            "FIR (First Information Report) is the document prepared when police first receive information about a cognizable offence."))
        add(mcq("mcq_pol_3", "subj_police_rules", "Which section of the Pakistan Penal Code deals with murder (Qatl-e-Amd)?",
            "Section 302", "Section 320", "Section 109", "Section 420", "A",
            "Section 302 of the PPC prescribes punishment for Qatl-e-Amd (intentional murder)."))

        // Banking & Finance (job-specific)
        add(mcq("mcq_bank_1", "subj_banking", "Which institution regulates commercial banks in Pakistan?",
            "SECP", "State Bank of Pakistan (SBP)", "FBR", "NAB", "B",
            "The State Bank of Pakistan (SBP) is the central bank responsible for regulating monetary policy and commercial banks."))
        add(mcq("mcq_bank_2", "subj_banking", "What does 'IBAN' stand for in banking?",
            "International Bank Account Number", "Internal Bank Account Number",
            "International Banking Access Network", "Interbank Automated Network", "A",
            "IBAN (International Bank Account Number) is a standardized format used to identify bank accounts internationally."))
        add(mcq("mcq_bank_3", "subj_banking", "A 'cheque' that has no funds to cover it is commonly called:",
            "Crossed cheque", "Bounced/dishonoured cheque", "Bearer cheque", "Post-dated cheque", "B",
            "A cheque returned unpaid due to insufficient funds is referred to as a bounced or dishonoured cheque."))

        // Teaching & Pedagogy (job-specific)
        add(mcq("mcq_ped_1", "subj_pedagogy", "Which teaching method emphasizes learning by doing?",
            "Lecture method", "Activity-based/experiential method", "Rote memorization", "Dictation method", "B",
            "Activity-based (experiential) learning emphasizes hands-on, learning-by-doing approaches."))
        add(mcq("mcq_ped_2", "subj_pedagogy", "Formative assessment is primarily used to:",
            "Assign final grades only", "Monitor ongoing learning and provide feedback",
            "Rank students against each other", "Replace final exams entirely", "B",
            "Formative assessment monitors student learning during instruction to provide ongoing feedback for improvement."))
        add(mcq("mcq_ped_3", "subj_pedagogy", "Bloom's Taxonomy is primarily used for classifying:",
            "School buildings", "Educational learning objectives", "Student attendance", "Exam fee structures", "B",
            "Bloom's Taxonomy is a framework for categorizing educational learning objectives by complexity."))
    }
}
