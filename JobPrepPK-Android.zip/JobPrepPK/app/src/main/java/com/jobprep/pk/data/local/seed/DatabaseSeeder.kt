package com.jobprep.pk.data.local.seed

import com.jobprep.pk.data.local.dao.*
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Populates Room with realistic sample content the first time the app runs,
 * so every feature (jobs, MCQ bank, mock tests, notifications, admin login)
 * can be exercised immediately without a live backend connection.
 */
@Singleton
class DatabaseSeeder @Inject constructor(
    private val userDao: UserDao,
    private val jobDao: JobDao,
    private val subjectDao: SubjectDao,
    private val mcqDao: McqDao,
    private val blueprintDao: TestBlueprintDao,
    private val notificationDao: NotificationDao
) {
    suspend fun seedIfEmpty() {
        if (userDao.count() == 0) {
            SeedDataProvider.seedUsers().forEach { userDao.insert(it) }
        }
        if (jobDao.count() == 0) {
            jobDao.upsertAll(SeedDataProvider.seedJobs())
        }
        if (subjectDao.count() == 0) {
            SeedDataProvider.seedSubjects().forEach { subjectDao.upsert(it) }
        }
        if (mcqDao.count() == 0) {
            mcqDao.upsertAll(SeedDataProvider.seedMcqs())
        }
        if (blueprintDao.count() == 0) {
            SeedDataProvider.seedBlueprints().forEach { blueprintDao.upsert(it) }
        }
        if (notificationDao.count() == 0) {
            SeedDataProvider.seedNotifications().forEach { notificationDao.upsert(it) }
        }
    }
}
