package com.jobprep.pk.presentation.admin

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jobprep.pk.domain.repository.JobRepository
import com.jobprep.pk.domain.repository.JobFilter
import com.jobprep.pk.domain.repository.McqRepository
import com.jobprep.pk.domain.repository.TestRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

data class AdminStats(
    val totalJobs: Int,
    val totalSubjects: Int,
    val totalBlueprints: Int,
    val reportedQuestions: Int
)

@HiltViewModel
class AdminDashboardViewModel @Inject constructor(
    jobRepository: JobRepository,
    mcqRepository: McqRepository,
    testRepository: TestRepository
) : ViewModel() {

    val stats: StateFlow<AdminStats> = combine(
        jobRepository.observeJobs(JobFilter(activeOnly = false)),
        mcqRepository.observeSubjects(),
        testRepository.observeBlueprints(),
        mcqRepository.observeReportedQuestions()
    ) { jobs, subjects, blueprints, reported ->
        AdminStats(
            totalJobs = jobs.size,
            totalSubjects = subjects.size,
            totalBlueprints = blueprints.size,
            reportedQuestions = reported.size
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AdminStats(0, 0, 0, 0))
}
