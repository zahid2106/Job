package com.jobprep.pk.di

import com.jobprep.pk.data.repository.*
import com.jobprep.pk.domain.repository.*
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds @Singleton
    abstract fun bindJobRepository(impl: JobRepositoryImpl): JobRepository

    @Binds @Singleton
    abstract fun bindMcqRepository(impl: McqRepositoryImpl): McqRepository

    @Binds @Singleton
    abstract fun bindTestRepository(impl: TestRepositoryImpl): TestRepository

    @Binds @Singleton
    abstract fun bindUserRepository(impl: UserRepositoryImpl): UserRepository

    @Binds @Singleton
    abstract fun bindNotificationRepository(impl: NotificationRepositoryImpl): NotificationRepository
}
