package com.jobprep.pk.data.remote.dto

import kotlinx.serialization.Serializable

/**
 * Wire-format DTOs for the remote content API. Kept intentionally close to the
 * Room entities but decoupled from them, so the backend team can evolve the API
 * independently of on-device storage.
 */
@Serializable
data class JobDto(
    val id: String,
    val organization: String,
    val title: String,
    val bpsOrGrade: String,
    val qualification: String,
    val ageLimitMin: Int,
    val ageLimitMax: Int,
    val vacancies: Int,
    val experienceRequired: String,
    val province: String,
    val postedDate: Long,
    val deadline: Long,
    val advertisementNumber: String,
    val details: String,
    val applyLink: String,
    val isFeatured: Boolean,
    val isActive: Boolean
)

@Serializable
data class SubjectDto(
    val id: String,
    val name: String,
    val iconKey: String,
    val colorHex: String,
    val jobCategory: String? = null
)

@Serializable
data class McqDto(
    val id: String,
    val subjectId: String,
    val jobCategory: String? = null,
    val questionText: String,
    val optionA: String,
    val optionB: String,
    val optionC: String,
    val optionD: String,
    val correctOption: String,
    val explanation: String,
    val difficulty: String
)

@Serializable
data class TestBlueprintDto(
    val id: String,
    val title: String,
    val description: String,
    val subjectIds: List<String>,
    val jobCategory: String? = null,
    val questionCount: Int,
    val durationMinutes: Int,
    val isPopular: Boolean
)

@Serializable
data class NotificationDto(
    val id: String,
    val title: String,
    val body: String,
    val type: String,
    val relatedId: String? = null,
    val createdAt: Long
)

@Serializable
data class ContentSyncResponseDto(
    val jobs: List<JobDto> = emptyList(),
    val subjects: List<SubjectDto> = emptyList(),
    val mcqs: List<McqDto> = emptyList(),
    val testBlueprints: List<TestBlueprintDto> = emptyList(),
    val notifications: List<NotificationDto> = emptyList(),
    val serverTimestamp: Long = 0L
)
