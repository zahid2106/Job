package com.jobprep.pk.presentation.admin

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.hilt.navigation.compose.hiltViewModel
import com.jobprep.pk.domain.model.Subject
import com.jobprep.pk.presentation.common.UiState
import com.jobprep.pk.presentation.components.*
import com.jobprep.pk.presentation.theme.Spacing

@Composable
fun AdminSubjectsScreen(
    onBack: () -> Unit,
    onSubjectClick: (String) -> Unit,
    viewModel: AdminSubjectsViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }
    var pendingDelete by remember { mutableStateOf<Subject?>(null) }

    Scaffold(
        topBar = { AppTopBar(title = "Subjects & MCQs", onBack = onBack) },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAddDialog = true }) { Icon(Icons.Filled.Add, contentDescription = "Add subject") }
        }
    ) { padding ->
        when (val s = state) {
            is UiState.Loading -> LoadingState(modifier = Modifier.padding(padding))
            is UiState.Error -> ErrorState(modifier = Modifier.padding(padding), message = s.message)
            is UiState.Empty -> EmptyState(
                modifier = Modifier.padding(padding), title = "No subjects yet",
                message = "Add a subject to start building your MCQ bank.", actionLabel = "Add Subject",
                onAction = { showAddDialog = true }
            )
            is UiState.Success -> LazyColumn(
                modifier = Modifier.padding(padding),
                contentPadding = PaddingValues(Spacing.lg),
                verticalArrangement = Arrangement.spacedBy(Spacing.sm)
            ) {
                items(s.data, key = { it.id }) { subject ->
                    AdminSubjectRow(subject = subject, onClick = { onSubjectClick(subject.id) }, onDelete = { pendingDelete = subject })
                }
                item { Spacer(Modifier.height(Spacing.xxxl)) }
            }
        }
    }

    if (showAddDialog) {
        AddSubjectDialog(onDismiss = { showAddDialog = false }, onConfirm = { name -> viewModel.addSubject(name, null); showAddDialog = false })
    }

    pendingDelete?.let { subject ->
        ConfirmDialog(
            title = "Delete \"${subject.name}\"?",
            message = "This will remove the subject. Existing questions in this subject will remain but become uncategorized.",
            confirmLabel = "Delete",
            isDestructive = true,
            onConfirm = { viewModel.deleteSubject(subject.id); pendingDelete = null },
            onDismiss = { pendingDelete = null }
        )
    }
}

@Composable
private fun AdminSubjectRow(subject: Subject, onClick: () -> Unit, onDelete: () -> Unit) {
    OutlinedCard(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.padding(Spacing.md), verticalAlignment = Alignment.CenterVertically) {
            Icon(subjectIconFor(subject.iconKey), contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(Spacing.md))
            Column(modifier = Modifier.weight(1f)) {
                Text(subject.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text("${subject.questionCount} questions", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error) }
        }
    }
}

@Composable
private fun AddSubjectDialog(onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Subject") },
        text = { AppTextField(value = name, onValueChange = { name = it }, label = "Subject name") },
        confirmButton = { TextButton(onClick = { onConfirm(name) }, enabled = name.isNotBlank()) { Text("Add") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
