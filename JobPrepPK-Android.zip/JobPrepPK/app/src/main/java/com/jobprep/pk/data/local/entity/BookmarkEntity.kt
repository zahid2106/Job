package com.jobprep.pk.data.local.entity

import androidx.room.Entity

@Entity(tableName = "bookmarks", primaryKeys = ["userId", "mcqId"])
data class BookmarkEntity(
    val userId: String,
    val mcqId: String,
    val createdAt: Long
)
