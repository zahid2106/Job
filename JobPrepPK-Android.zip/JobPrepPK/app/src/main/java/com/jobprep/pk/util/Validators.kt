package com.jobprep.pk.util

object Validators {
    private val EMAIL_REGEX = Regex("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")

    fun isValidEmail(email: String): Boolean = EMAIL_REGEX.matches(email.trim())

    fun isValidPassword(password: String): Boolean = password.length >= 6

    fun isValidName(name: String): Boolean = name.trim().length in 2..60

    fun passwordStrengthMessage(password: String): String? {
        if (password.length < 6) return "Password must be at least 6 characters."
        if (!password.any { it.isDigit() }) return "Password should include at least one number."
        return null
    }

    fun validateJobForm(
        title: String,
        organization: String,
        bps: String,
        qualification: String,
        vacancies: String,
        deadlineMillis: Long?
    ): List<String> {
        val errors = mutableListOf<String>()
        if (title.isBlank()) errors += "Job title is required."
        if (organization.isBlank()) errors += "Organization is required."
        if (bps.isBlank()) errors += "BPS / Grade is required."
        if (qualification.isBlank()) errors += "Qualification is required."
        val vac = vacancies.toIntOrNull()
        if (vac == null || vac <= 0) errors += "Vacancies must be a positive number."
        if (deadlineMillis == null) errors += "Application deadline is required."
        else if (deadlineMillis < System.currentTimeMillis() - 24L * 60 * 60 * 1000) {
            errors += "Deadline cannot be in the past."
        }
        return errors
    }
}
