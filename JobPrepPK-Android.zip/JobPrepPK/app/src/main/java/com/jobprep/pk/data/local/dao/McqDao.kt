package com.jobprep.pk.data.local.dao

import androidx.room.*
import com.jobprep.pk.data.local.entity.McqEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface McqDao {
    @Query("SELECT COUNT(*) FROM mcqs WHERE subjectId = :subjectId")
    suspend fun countForSubject(subjectId: String): Int

    @Query("""
        SELECT * FROM mcqs WHERE
        (:jobCategory IS NULL OR jobCategory = :jobCategory OR jobCategory IS NULL) AND
        subjectId IN (:subjectIds)
        ORDER BY RANDOM() LIMIT :count
    """)
    suspend fun getRandom(subjectIds: List<String>, jobCategory: String?, count: Int): List<McqEntity>

    @Query("SELECT * FROM mcqs WHERE subjectId = :subjectId")
    suspend fun getAllForSubject(subjectId: String): List<McqEntity>

    @Query("SELECT * FROM mcqs WHERE id IN (:ids)")
    suspend fun getByIds(ids: List<String>): List<McqEntity>

    @Query("SELECT * FROM mcqs WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): McqEntity?

    @Upsert
    suspend fun upsert(mcq: McqEntity)

    @Upsert
    suspend fun upsertAll(mcqs: List<McqEntity>)

    @Query("DELETE FROM mcqs WHERE id = :id")
    suspend fun delete(id: String)

    @Query("UPDATE mcqs SET reportCount = reportCount + 1 WHERE id = :id")
    suspend fun incrementReportCount(id: String)

    @Query("SELECT * FROM mcqs WHERE reportCount > 0 ORDER BY reportCount DESC")
    fun observeReported(): Flow<List<McqEntity>>

    @Query("UPDATE mcqs SET reportCount = 0 WHERE id = :id")
    suspend fun clearReportCount(id: String)

    @Query("SELECT COUNT(*) FROM mcqs")
    suspend fun count(): Int
}
