package com.jobprep.pk.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "test_answers")
data class TestAnswerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val attemptId: String,
    val mcqId: String,
    val selectedOption: String?, // A/B/C/D or null if skipped
    val isMarkedForReview: Boolean,
    val orderIndex: Int,
    val shuffledOptionsOrder: String // e.g. "C,A,D,B" -> order of OptionKey shown to user
)
