package com.jobprep.pk.presentation.test

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.jobprep.pk.domain.model.TestAnswer
import com.jobprep.pk.presentation.common.UiState
import com.jobprep.pk.presentation.components.*
import com.jobprep.pk.presentation.theme.Spacing

@Composable
fun AnswerReviewScreen(
    onBack: () -> Unit,
    viewModel: ResultViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()

    Scaffold(topBar = { AppTopBar(title = "Answer Review", onBack = onBack) }) { padding ->
        when (val s = state) {
            is UiState.Loading -> LoadingState(modifier = Modifier.padding(padding))
            is UiState.Error -> ErrorState(modifier = Modifier.padding(padding), message = s.message)
            is UiState.Empty -> EmptyState(modifier = Modifier.padding(padding), title = "Not found", message = "This result is unavailable.")
            is UiState.Success -> LazyColumn(
                modifier = Modifier.padding(padding),
                contentPadding = PaddingValues(Spacing.lg),
                verticalArrangement = Arrangement.spacedBy(Spacing.md)
            ) {
                itemsIndexed(s.data.answers) { index, answer ->
                    ReviewQuestionCard(index = index, answer = answer)
                }
            }
        }
    }
}

@Composable
private fun ReviewQuestionCard(index: Int, answer: TestAnswer) {
    val statusColor = when {
        answer.isSkipped -> MaterialTheme.colorScheme.onSurfaceVariant
        answer.isCorrect -> MaterialTheme.colorScheme.primary
        else -> MaterialTheme.colorScheme.error
    }
    val statusLabel = when {
        answer.isSkipped -> "Skipped"
        answer.isCorrect -> "Correct"
        else -> "Incorrect"
    }

    OutlinedCard(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(Spacing.md)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Q${index + 1}", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.width(Spacing.sm))
                Chip(statusLabel, statusColor)
                if (answer.isMarkedForReview) {
                    Spacer(Modifier.width(Spacing.xs))
                    Icon(Icons.Filled.Bookmark, contentDescription = "Marked for review", modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.tertiary)
                }
                Spacer(Modifier.weight(1f))
                Chip(answer.mcq.subjectName, MaterialTheme.colorScheme.primary)
            }
            Spacer(Modifier.height(Spacing.sm))
            Text(answer.mcq.questionText, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(Spacing.sm))

            answer.shuffledOptions.forEach { option ->
                val isCorrectOption = option.key == answer.mcq.correctOption
                val isSelectedOption = option.key == answer.selectedOption
                val textColor = when {
                    isCorrectOption -> MaterialTheme.colorScheme.primary
                    isSelectedOption && !isCorrectOption -> MaterialTheme.colorScheme.error
                    else -> MaterialTheme.colorScheme.onSurface
                }
                Text(
                    "${option.key.name}. ${option.text}" + when {
                        isCorrectOption -> "  ✓"
                        isSelectedOption -> "  ✗"
                        else -> ""
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = textColor,
                    fontWeight = if (isCorrectOption || isSelectedOption) FontWeight.SemiBold else FontWeight.Normal,
                    modifier = Modifier.padding(vertical = 2.dp)
                )
            }

            Spacer(Modifier.height(Spacing.sm))
            Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(8.dp)) {
                Text(
                    answer.mcq.explanation,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(Spacing.sm)
                )
            }
        }
    }
}
