package com.jobprep.pk.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "test_attempts")
data class TestAttemptEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val blueprintId: String?,
    val title: String,
    val mode: String, // PRACTICE / MOCK
    val startedAt: Long,
    val submittedAt: Long,
    val durationSeconds: Int,
    val totalQuestions: Int,
    val correctCount: Int,
    val wrongCount: Int,
    val skippedCount: Int,
    val score: Int,
    val percentage: Float
)
