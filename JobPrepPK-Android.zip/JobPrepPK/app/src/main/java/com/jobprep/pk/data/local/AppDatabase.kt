package com.jobprep.pk.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.jobprep.pk.data.local.dao.*
import com.jobprep.pk.data.local.entity.*

@Database(
    entities = [
        UserEntity::class,
        JobEntity::class,
        SubjectEntity::class,
        McqEntity::class,
        BookmarkEntity::class,
        ReportEntity::class,
        TestBlueprintEntity::class,
        TestAttemptEntity::class,
        TestAnswerEntity::class,
        NotificationEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun jobDao(): JobDao
    abstract fun subjectDao(): SubjectDao
    abstract fun mcqDao(): McqDao
    abstract fun bookmarkDao(): BookmarkDao
    abstract fun reportDao(): ReportDao
    abstract fun testBlueprintDao(): TestBlueprintDao
    abstract fun testAttemptDao(): TestAttemptDao
    abstract fun userDao(): UserDao
    abstract fun notificationDao(): NotificationDao

    companion object {
        const val DATABASE_NAME = "jobprep_pk.db"
    }
}
