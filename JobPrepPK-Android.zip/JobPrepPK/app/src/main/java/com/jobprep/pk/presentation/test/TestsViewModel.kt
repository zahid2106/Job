package com.jobprep.pk.presentation.test

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jobprep.pk.domain.model.TestBlueprint
import com.jobprep.pk.domain.repository.TestRepository
import com.jobprep.pk.presentation.common.UiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

@HiltViewModel
class TestsViewModel @Inject constructor(
    testRepository: TestRepository
) : ViewModel() {

    val uiState: StateFlow<UiState<List<TestBlueprint>>> = testRepository.observeBlueprints()
        .map { list -> if (list.isEmpty()) UiState.Empty else UiState.Success(list) }
        .catch { emit(UiState.Error(it.message ?: "Failed to load tests")) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UiState.Loading)
}
