package com.jobprep.pk.presentation.profile

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.jobprep.pk.domain.model.SubjectPerformance
import com.jobprep.pk.domain.model.UserProgress
import com.jobprep.pk.presentation.common.UiState
import com.jobprep.pk.presentation.components.*
import com.jobprep.pk.presentation.theme.Spacing

@Composable
fun ProfileScreen(
    isAdmin: Boolean,
    onEditProfile: () -> Unit,
    onHistory: () -> Unit,
    onBookmarks: () -> Unit,
    onSettings: () -> Unit,
    onAdmin: () -> Unit,
    onLoggedOut: () -> Unit,
    viewModel: ProfileViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()
    var showLogoutConfirm by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { viewModel.refresh() }

    Scaffold(topBar = { AppTopBar(title = "Profile") }) { padding ->
        when (val s = state) {
            is UiState.Loading -> LoadingState(modifier = Modifier.padding(padding))
            is UiState.Error -> ErrorState(modifier = Modifier.padding(padding), message = s.message)
            is UiState.Empty -> EmptyState(modifier = Modifier.padding(padding), title = "Not signed in", message = "Please sign in to view your profile.")
            is UiState.Success -> ProfileContent(
                modifier = Modifier.padding(padding),
                data = s.data,
                isAdmin = isAdmin,
                onEditProfile = onEditProfile,
                onHistory = onHistory,
                onBookmarks = onBookmarks,
                onSettings = onSettings,
                onAdmin = onAdmin,
                onLogoutClick = { showLogoutConfirm = true }
            )
        }
    }

    if (showLogoutConfirm) {
        ConfirmDialog(
            title = "Sign out?",
            message = "You'll need to sign in again to access your saved progress.",
            confirmLabel = "Sign Out",
            isDestructive = true,
            onConfirm = { showLogoutConfirm = false; viewModel.logout(); onLoggedOut() },
            onDismiss = { showLogoutConfirm = false }
        )
    }
}

@Composable
private fun ProfileContent(
    modifier: Modifier = Modifier,
    data: ProfileData,
    isAdmin: Boolean,
    onEditProfile: () -> Unit,
    onHistory: () -> Unit,
    onBookmarks: () -> Unit,
    onSettings: () -> Unit,
    onAdmin: () -> Unit,
    onLogoutClick: () -> Unit
) {
    LazyColumn(modifier = modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = Spacing.xxl)) {
        item {
            ProfileHeader(name = data.user.name, email = data.user.email, isAdmin = data.user.isAdmin, onEditProfile = onEditProfile)
        }
        item {
            StatsGrid(progress = data.progress, modifier = Modifier.padding(horizontal = Spacing.lg, vertical = Spacing.md))
        }
        if (data.progress.weakSubjects.isNotEmpty()) {
            item { SectionHeader("Areas to Improve", modifier = Modifier.padding(horizontal = Spacing.lg, vertical = Spacing.sm)) }
            items(data.progress.weakSubjects, key = { it.subjectId }) { perf -> WeakAreaRow(perf, Modifier.padding(horizontal = Spacing.lg, vertical = Spacing.xxs)) }
        }

        item { SectionHeader("Menu", modifier = Modifier.padding(horizontal = Spacing.lg, vertical = Spacing.sm)) }
        item {
            Column(modifier = Modifier.padding(horizontal = Spacing.lg)) {
                MenuRow(Icons.Filled.History, "Test History", onHistory)
                MenuRow(Icons.Filled.Bookmark, "Bookmarked Questions", onBookmarks)
                MenuRow(Icons.Filled.Settings, "Settings", onSettings)
                if (isAdmin) {
                    MenuRow(Icons.Filled.AdminPanelSettings, "Admin Panel", onAdmin)
                }
                MenuRow(Icons.Filled.Logout, "Sign Out", onLogoutClick, isDestructive = true)
            }
        }
    }
}

@Composable
private fun ProfileHeader(name: String, email: String, isAdmin: Boolean, onEditProfile: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(Spacing.lg),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.size(56.dp)) {
            Box(contentAlignment = Alignment.Center) {
                Text(
                    name.firstOrNull()?.uppercase() ?: "?",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
        Spacer(Modifier.width(Spacing.md))
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                if (isAdmin) {
                    Spacer(Modifier.width(Spacing.xs))
                    Chip("Admin", MaterialTheme.colorScheme.tertiary)
                }
            }
            Text(email, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        IconButton(onClick = onEditProfile) {
            Icon(Icons.Filled.Edit, contentDescription = "Edit profile")
        }
    }
}

@Composable
private fun StatsGrid(progress: UserProgress, modifier: Modifier = Modifier) {
    Column(modifier = modifier) {
        Row(horizontalArrangement = Arrangement.spacedBy(Spacing.sm), modifier = Modifier.fillMaxWidth()) {
            StatBox("Tests Attempted", progress.testsAttempted.toString(), Modifier.weight(1f))
            StatBox("Average Score", "${"%.1f".format(progress.averageScore)}%", Modifier.weight(1f))
        }
        Spacer(Modifier.height(Spacing.sm))
        Row(horizontalArrangement = Arrangement.spacedBy(Spacing.sm), modifier = Modifier.fillMaxWidth()) {
            StatBox("Highest Score", "${"%.1f".format(progress.highestScore)}%", Modifier.weight(1f))
            StatBox("Bookmarks", progress.bookmarkedCount.toString(), Modifier.weight(1f))
        }
    }
}

@Composable
private fun StatBox(label: String, value: String, modifier: Modifier = Modifier) {
    OutlinedCard(modifier = modifier) {
        Column(modifier = Modifier.padding(Spacing.md)) {
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
            Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun WeakAreaRow(perf: SubjectPerformance, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.TrendingDown, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(Spacing.sm))
        Text(perf.subjectName, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Text("${"%.0f".format(perf.percentage)}%", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun MenuRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit, isDestructive: Boolean = false) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.small)
            .clickableRow(onClick)
            .padding(vertical = Spacing.sm),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = if (isDestructive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(Spacing.md))
        Text(label, style = MaterialTheme.typography.bodyMedium, color = if (isDestructive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
        Spacer(Modifier.weight(1f))
        if (!isDestructive) {
            Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private fun Modifier.clickableRow(onClick: () -> Unit): Modifier =
    this.then(androidx.compose.foundation.clickable(onClick = onClick))
