package com.jobprep.pk.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "reports")
data class ReportEntity(
    @PrimaryKey val id: String,
    val mcqId: String,
    val userId: String,
    val reason: String,
    val status: String,
    val createdAt: Long
)
