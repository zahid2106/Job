package com.jobprep.pk.presentation.test

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jobprep.pk.domain.model.TestBlueprint
import com.jobprep.pk.domain.repository.TestRepository
import com.jobprep.pk.presentation.common.UiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class TestSetupViewModel @Inject constructor(
    private val testRepository: TestRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val blueprintId: String = checkNotNull(savedStateHandle["blueprintId"])

    private val _uiState = MutableStateFlow<UiState<TestBlueprint>>(UiState.Loading)
    val uiState: StateFlow<UiState<TestBlueprint>> = _uiState

    init {
        viewModelScope.launch {
            val blueprint = testRepository.getBlueprintById(blueprintId)
            _uiState.value = if (blueprint == null) UiState.Error("This test is no longer available.")
                              else UiState.Success(blueprint)
        }
    }
}
