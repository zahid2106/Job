# Room
-keep class com.jobprep.pk.data.local.entity.** { *; }

# Kotlinx Serialization
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class kotlinx.serialization.json.** { *** Companion; }
-keepclasseswithmembers class com.jobprep.pk.data.remote.dto.** { *** Companion; }
-keepclasseswithmembers class com.jobprep.pk.data.remote.dto.**$Companion { kotlinx.serialization.KSerializer serializer(...); }

# Hilt
-keep class dagger.hilt.** { *; }
-keep class javax.inject.** { *; }
