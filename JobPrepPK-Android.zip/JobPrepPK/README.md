# JobPrep PK — Pakistani Government Job Test Preparation App

A production-structured Android application (Kotlin + Jetpack Compose) for preparing for
Pakistani government/competitive job tests — FPSC, PPSC, NTS, PTS, OTS, Police, Army, Navy,
Air Force, Banks, Teaching and other organizations.

---

## 0. Getting an actual installable .apk

The environment that generated this project has no Android SDK and can't reach Google's
Maven repository, so an `.apk` couldn't be compiled where this project was written. Two
genuine ways to get a real, installable APK from these files, ranked by effort:

**Option A — GitHub Actions (no Android Studio install needed, ~5 minutes):**
1. Create a new GitHub repository and push this entire folder to it.
2. GitHub automatically runs `.github/workflows/build-apk.yml` on push (or trigger it
   manually from the repo's **Actions** tab → **Build Debug APK** → **Run workflow**).
   GitHub's runners have a full Android SDK and unrestricted internet access, so the build
   completes there in a few minutes.
3. Open the finished run → **Artifacts** → download **jobprep-pk-debug-apk** → unzip it →
   you have `app-debug.apk`.
4. Transfer that file to an Android phone (email, Drive, USB, etc.) and open it to install.
   You'll need to allow "install unknown apps" for whichever app you use to open it, since
   it's not from the Play Store — this is expected for a debug build.

**Option B — Android Studio (if you already have it installed):**
1. Open this folder as a project in Android Studio.
2. Accept the prompt to regenerate the Gradle wrapper (see §6 below).
3. **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
4. Android Studio shows a notification linking straight to the generated
   `app/build/outputs/apk/debug/app-debug.apk`.

Either path produces the same debug APK — a release/signed build would additionally need a
signing keystore, which is a deliberate manual step (see §7) rather than something to
automate.

---

## 1. What's included

- **Home dashboard** — featured jobs, closing-soon deadlines, popular mock tests, recent
  attempts, progress summary, search entry point.
- **Job announcements** — organization, position, BPS/grade, qualification, age limit,
  vacancies, experience, deadline, advertisement number, full details and an "Apply Now"
  link that opens the official portal.
- **MCQ Bank** — General Knowledge, Pakistan Studies, Current Affairs, Islamiat, English,
  Urdu, Mathematics, Computer Science, General Science, plus job-specific subjects (Police
  Rules & Procedure, Banking & Finance, Teaching & Pedagogy).
- **Practice mode** — unlimited, randomized questions, instant correct/incorrect feedback,
  explanations, bookmarking, and a "report an issue" flow per question.
- **Mock test mode** — configurable question count & duration (or pick a ready-made
  blueprint), shuffled questions/options per attempt, a question navigator grid, mark-for-
  review, live countdown timer, and automatic submission when time runs out.
- **Results & review** — score, percentage, correct/wrong/skipped counts, time taken,
  subject-wise performance bars, and a full per-question answer review with explanations.
- **Profile & progress** — tests attempted, average/highest score, subject performance,
  weak-area detection, bookmarked questions, full test history.
- **Notifications** — new jobs, deadlines, new tests, announcements; unread badge on Home.
- **Admin panel** (role-gated) — job CRUD, subject & MCQ CRUD, **bulk MCQ import** with
  per-row validation, notification composer, and a reported-questions moderation queue.
- **Light & dark themes**, offline banner, loading/empty/error states everywhere, and input
  validation throughout (auth, job form, MCQ form, bulk import).

## 2. Architecture

Clean Architecture, MVVM, single-activity Jetpack Compose UI:

```
presentation/   Compose screens + ViewModels (MVVM), navigation, theme, reusable components
domain/         Pure Kotlin: models, repository interfaces, use cases (no Android deps)
data/
  local/        Room database — entities, DAOs, the offline-first source of truth
  remote/       Retrofit API contract (ContentApiService) + DTOs for syncing content
  repository/   Repository implementations that merge remote + local and expose Flows
  datastore/    DataStore Preferences (session, theme, sync timestamp, notification prefs)
di/             Hilt modules (Database, Network, Repository bindings, UseCase)
util/           SyncWorker, NotificationHelper, NetworkMonitor, validators, extensions
```

**Content is decoupled from the APK.** All screens read from Room via repository Flows.
`ContentApiService` + `SyncWorker` define the seam for pulling new jobs/MCQs/tests/
notifications from a backend every 6 hours (and can be triggered manually) — point
`CONTENT_API_BASE_URL` in `app/build.gradle.kts` at a real deployment (Node/Express,
Firebase Functions, Supabase, etc.) implementing the endpoints in `ContentApiService.kt`
and new content flows in automatically, with **no new APK release required**. Until a
backend exists, the app runs entirely on the realistic sample dataset seeded on first
launch (`SeedDataProvider.kt` / `DatabaseSeeder.kt`), so every feature is testable
immediately.

**Auth** is implemented as a real local system (salted SHA-256 password hashes in Room,
session stored in DataStore) rather than a mock — this keeps the demo fully self-contained,
while `UserRepository`'s interface is what you'd swap for Firebase Auth / a backend JWT flow
in production; nothing above the repository layer would need to change.

## 3. Demo credentials

| Role     | Email                | Password    |
|----------|-----------------------|-------------|
| Learner  | demo@jobprep.pk      | Demo@123    |
| Admin    | admin@jobprep.pk     | Admin@123   |

Sign in as the admin account to reach **Profile → Admin Panel**, or register a new account
to try the learner flow from scratch. Both are shown on the login screen for convenience.

## 4. Sample data

Seeded automatically on first run (`DatabaseSeeder.seedIfEmpty()`), so the app is fully
usable without any network connection:

- 12 realistic job listings across FPSC, PPSC, NTS, PTS, OTS, Police, Army, Navy, Air Force,
  a bank and a provincial education department (one already past its deadline, to exercise
  the "Closed" status).
- 12 subjects and ~55 MCQs with explanations, spanning the required subject list plus three
  job-specific subjects.
- 7 mock test blueprints (e.g. "Police Constable Full Test", "Bank Officer Mock Test").
- 5 sample notifications (mixed read/unread, all four notification types).

## 5. Bulk MCQ import format

In **Admin → Bulk Import MCQs**, paste one question per line, pipe-delimited:

```
subjectId | question text | option A | option B | option C | option D | correct letter | explanation
```

Example:

```
subj_gk | Capital of Pakistan? | Karachi | Islamabad | Lahore | Quetta | B | Islamabad has been the capital since 1967.
```

Each row is validated independently (via the same `ValidateMcqUseCase` used by the single
MCQ editor) before import, and the screen shows exactly which rows passed and why any
failed, so partial imports are safe.

## 6. Opening & building the project

This project was authored as a complete, standard Android Studio project (Gradle Kotlin
DSL, Compose, min SDK 24 / target & compile SDK 34). To build it:

1. Open the project root folder in **Android Studio (Koala/2024.1 or newer)**.
2. The Gradle wrapper's binary jar isn't included in this download (it can only be fetched
   from Gradle's own servers, which this environment couldn't reach) — `gradle/wrapper/
   gradle-wrapper.properties` already pins Gradle 8.7. Android Studio will offer to
   regenerate the wrapper on first open; accept that prompt, or run `gradle wrapper` once
   yourself if you have Gradle installed locally.
3. Let Gradle sync — it will fetch dependencies from Google's and Maven Central's
   repositories (already declared in `settings.gradle.kts`).
4. Run on an emulator or device (`Shift+F10`), or build a release AAB/APK via
   **Build → Generate Signed App Bundle / APK**.

> **Note on this delivery:** the environment used to assemble these files does not have the
> Android SDK, an emulator, or access to Google's Maven repository, so the project could not
> be compiled to a `.apk`/`.aab` here. Every file was hand-written against current, stable
> library APIs (AndroidX, Compose BOM 2024.06, Room 2.6.1, Hilt 2.51.1, Navigation Compose
> 2.7.7, Retrofit 2.11), and the structure follows a real Android Studio project layout, so
> it should build directly once opened in Android Studio with a normal internet connection.
> If Gradle reports a version mismatch for the Android Gradle Plugin against your installed
> Android Studio, update the AGP version in the root `build.gradle.kts` to the one your
> Studio version recommends (Studio will offer to do this automatically).

## 7. What you'd still wire up for a real production launch

- Point `CONTENT_API_BASE_URL` at a real backend implementing `ContentApiService`'s
  endpoints (`/sync`, `/jobs`, `/mcqs`), or swap the repository implementations for
  Firebase/Supabase clients — the domain layer and all UI are already decoupled from this.
  Add real API keys / auth as your backend needs.
  A production admin panel should also require this backend, protected with server-side
  admin authorization — the on-device admin flag is sufficient for this offline demo but
  should not be the only gate once content is shared across real users.
- Wire Firebase Cloud Messaging (or another push provider) into `NotificationHelper`/
  `SyncWorker` for real push delivery; local notifications and in-app notification list are
  already fully implemented.
- Add a signing config and enable Play App Signing for release builds.
- Add app icon artwork (a placeholder vector icon is included at
  `app/src/main/res/drawable/ic_launcher_foreground.xml`).
